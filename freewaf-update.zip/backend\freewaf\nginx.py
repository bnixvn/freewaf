from __future__ import annotations

import base64
import os
import csv
import errno
import gzip
import ipaddress
import json
import re
import shlex
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from .defaults import (
    DEFAULT_BOT_LOGIN_PATH_PATTERNS,
    DEFAULT_BOT_RATE_CHALLENGE,
    LEGACY_WHMCS_LOGIN_PATH_PATTERNS,
    VERIFIED_AI_BOT_PROVIDERS,
    VERIFIED_BOT_PROVIDERS,
    challenge_secret,
)


NATIVE_TARGETS = {"all", "url", "headers", "method", "ip"}
BOT_RULE_IDS = {"builtin-scanner-agent"}
BOT_BLOCK_UA_PATTERN = (
    r"(?:sqlmap|nikto|acunetix|nessus|nuclei|wpscan|masscan|nmap|zgrab|gobuster|"
    r"dirbuster|ffuf|jaeles|zmeu|commix|havij|netsparker|openvas|arachni)"
)
GEO_CIDR_CACHE = {}
_BROTLI_SUPPORT_CACHE: dict[str, bool] = {}
CLIENT_IP_SOURCES = {
    "socket",
    "xff_leftmost",
    "xff_rightmost",
    "xff_second_rightmost",
    "xff_third_rightmost",
    "header",
    "proxy_protocol",
}
CLIENT_IP_SOURCE_ALIASES = {
    "remote_addr": "socket",
    "socket_connection": "socket",
    "x_forwarded_for": "xff_leftmost",
    "xff": "xff_leftmost",
    "rightmost_xff": "xff_rightmost",
    "second_rightmost_xff": "xff_second_rightmost",
    "third_rightmost_xff": "xff_third_rightmost",
    "http_header": "header",
    "proxy": "proxy_protocol",
}
HTTP_HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,126}$")
NGINX_SIZE_RE = re.compile(r"^[1-9][0-9]*[kKmMgG]$")
MODSECURITY_IP_LIST_DIR_NAME = "modsecurity-ip-lists"


def client_ip_settings(state: dict | None) -> dict:
    settings = (state or {}).get("settings", {}) if isinstance(state, dict) else {}
    source = settings.get("clientIp") or settings.get("client_ip") or {}
    source = source if isinstance(source, dict) else {}
    raw_mode = re.sub(r"[\s-]+", "_", str(source.get("source") or "socket").strip().lower())
    mode = CLIENT_IP_SOURCE_ALIASES.get(raw_mode, raw_mode)
    if mode not in CLIENT_IP_SOURCES:
        mode = "socket"
    header_name = str(source.get("headerName") or source.get("header_name") or "X-Forwarded-For").strip()
    if not HTTP_HEADER_NAME_RE.match(header_name):
        header_name = "X-Forwarded-For"
    return {"source": mode, "headerName": header_name}


def http_header_variable(header_name: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9_-]", "", str(header_name or "X-Forwarded-For"))
    normalized = normalized.replace("-", "_").lower()
    return f"$http_{normalized or 'x_forwarded_for'}"


def selected_client_ip_variable(state: dict | None) -> str:
    settings = client_ip_settings(state)
    source = settings["source"]
    if source == "xff_leftmost":
        return "$sfl_xff_leftmost"
    if source == "xff_rightmost":
        return "$sfl_xff_rightmost"
    if source == "xff_second_rightmost":
        return "$sfl_xff_second_rightmost"
    if source == "xff_third_rightmost":
        return "$sfl_xff_third_rightmost"
    if source == "header":
        return http_header_variable(settings["headerName"])
    if source == "proxy_protocol":
        return "$proxy_protocol_addr"
    return "$remote_addr"


def client_ip_uses_proxy_protocol(state: dict | None) -> bool:
    return client_ip_settings(state)["source"] == "proxy_protocol"


def nginx_output_file(root_dir: Path) -> Path:
    configured = Path(os.environ.get("NGINX_OUTPUT_FILE", "./nginx/generated/freewaf.conf"))
    return configured if configured.is_absolute() else root_dir / configured


def nginx_site_config_dir(root_dir: Path) -> Path:
    configured = os.environ.get("NGINX_SITE_CONF_DIR", "").strip()
    if configured:
        path = Path(configured)
        return path if path.is_absolute() else root_dir / path
    return nginx_output_file(root_dir).parent / "sites"


def nginx_modsecurity_ip_list_dir(root_dir: Path) -> Path:
    configured = os.environ.get("NGINX_MODSECURITY_IP_LIST_DIR", "").strip()
    if configured:
        path = Path(configured)
        return path if path.is_absolute() else root_dir / path
    return nginx_output_file(root_dir).parent / MODSECURITY_IP_LIST_DIR_NAME


def nginx_access_log_file(root_dir: Path) -> Path:
    configured = Path(os.environ.get("NGINX_ACCESS_LOG", "./logs/freewaf_access.log"))
    return configured if configured.is_absolute() else root_dir / configured


def nginx_access_log_directive() -> str:
    configured = os.environ.get("NGINX_ACCESS_LOG", "./logs/freewaf_access.log")
    return configured.replace("\\", "/")


def nginx_site_log_dir(root_dir: Path) -> Path:
    configured = Path(os.environ.get("NGINX_SITE_LOG_DIR", "./logs/freewaf"))
    return configured if configured.is_absolute() else root_dir / configured


def nginx_site_log_dir_directive() -> str:
    return os.environ.get("NGINX_SITE_LOG_DIR", "./logs/freewaf").replace("\\", "/").rstrip("/")


def nginx_site_access_log_directive(site: dict) -> str:
    return f"{nginx_site_log_dir_directive()}/accesslog_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def nginx_site_error_log_directive(site: dict) -> str:
    return f"{nginx_site_log_dir_directive()}/errorlog_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def env_int(name: str, fallback: int, minimum: int = 1) -> int:
    try:
        value = int(os.environ.get(name, str(fallback)))
    except (TypeError, ValueError):
        value = fallback
    return max(minimum, value)


def nginx_limit_zone_size() -> str:
    value = os.environ.get("NGINX_LIMIT_ZONE_SIZE", "1m").strip()
    return value.lower() if NGINX_SIZE_RE.match(value) else "1m"


def nginx_hash_tuning_directives() -> list[str]:
    return [
        f"server_names_hash_max_size {env_int('NGINX_SERVER_NAMES_HASH_MAX_SIZE', 1024)};",
        f"server_names_hash_bucket_size {env_int('NGINX_SERVER_NAMES_HASH_BUCKET_SIZE', 128)};",
        f"variables_hash_max_size {env_int('NGINX_VARIABLES_HASH_MAX_SIZE', 1024)};",
        f"variables_hash_bucket_size {env_int('NGINX_VARIABLES_HASH_BUCKET_SIZE', 128)};",
        "",
    ]


def generate_nginx_config(state: dict) -> str:
    blocks = generate_nginx_common_blocks(state)
    site_configs = render_domain_config_files(state)
    if not site_configs:
        blocks.append("# No enabled sites.")
    else:
        blocks.extend(site_configs.values())
    return "\n\n".join(blocks) + "\n"


def generate_nginx_common_blocks(state: dict) -> list[str]:
    enabled_sites = [site for site in state.get("sites", []) if site.get("enabled")]
    enabled_access_rules = [rule for rule in state.get("accessRules", []) if rule.get("enabled")]
    selected_client_ip = selected_client_ip_variable(state)
    blocks = [
        "# Generated by FreeWAF. Do not edit by hand.",
        "# Include this file inside the nginx http {} context.",
        "",
        "map $request_uri $sfl_verdict {",
        "    default allow;",
        "}",
        "",
        "map $request_uri $sfl_reason {",
        "    default \"Allowed\";",
        "}",
        "",
        *render_client_ip_maps(selected_client_ip),
        "log_format freewaf escape=json '{\"time\":\"$time_iso8601\",\"remote_addr\":\"$sfl_client_ip\",\"host\":\"$host\",\"method\":\"$request_method\",\"uri\":\"$request_uri\",\"status\":$status,\"bytes\":$body_bytes_sent,\"request_time\":$request_time,\"upstream_status\":\"$upstream_status\",\"verdict\":\"$sfl_verdict\",\"reason\":\"$sfl_reason\",\"user_agent\":\"$http_user_agent\",\"referer\":\"$http_referer\"}';",
        "",
        "map $http_upgrade $sfl_connection_upgrade {",
        "    default upgrade;",
        "    '' close;",
        "}",
        "",
        *nginx_hash_tuning_directives(),
    ]

    shared_builtin_maps = render_shared_builtin_rule_maps(state)
    if shared_builtin_maps:
        blocks.extend(shared_builtin_maps)

    verified_bot_maps = render_verified_bot_maps(state, enabled_sites)
    if verified_bot_maps:
        blocks.extend(verified_bot_maps)

    if any(site_bot_protection(site).get("antiBotChallenge") for site in enabled_sites):
        blocks.extend(render_bot_detection_maps())

    if any_uses_challenge(enabled_sites):
        blocks.extend(render_challenge_maps())

    bot_zones = render_bot_limit_zones(enabled_sites)
    if bot_zones:
        blocks.extend(bot_zones)

    rate_limit = state.get("settings", {}).get("rateLimit", {})
    uses_global_rate = any(
        site_features(site).get("httpFlood") and not active_acl_access_limit(site)
        for site in enabled_sites
    )
    if rate_limit.get("enabled") and uses_global_rate:
        blocks.extend(render_global_rate_limit_zones(rate_limit, any_verified_bot_rate_bypass(enabled_sites)))

    acl_zones = render_acl_limit_zones(enabled_sites)
    if acl_zones:
        blocks.extend(acl_zones)

    if (rate_limit.get("enabled") and uses_global_rate) or acl_zones or bot_zones:
        blocks.extend(["limit_req_status 429;", ""])

    geo_maps = render_geo_block_maps(enabled_sites)
    if geo_maps:
        blocks.extend(geo_maps)

    access_maps = render_access_maps(state, enabled_access_rules)
    if access_maps:
        blocks.extend(access_maps)
        blocks.append("")

    return blocks


def render_client_ip_maps(selected_variable: str) -> list[str]:
    return [
        "map $http_x_forwarded_for $sfl_xff_leftmost {",
        "    default $remote_addr;",
        "    ~^\\s*(?<sfl_xff_left>[^,\\s]+) $sfl_xff_left;",
        "}",
        "",
        "map $http_x_forwarded_for $sfl_xff_rightmost {",
        "    default $remote_addr;",
        "    ~(?<sfl_xff_right>[^,\\s]+)\\s*$ $sfl_xff_right;",
        "}",
        "",
        "map $http_x_forwarded_for $sfl_xff_second_rightmost {",
        "    default $remote_addr;",
        "    ~(?<sfl_xff_second>[^,\\s]+)\\s*,\\s*[^,\\s]+\\s*$ $sfl_xff_second;",
        "}",
        "",
        "map $http_x_forwarded_for $sfl_xff_third_rightmost {",
        "    default $remote_addr;",
        "    ~(?<sfl_xff_third>[^,\\s]+)\\s*,\\s*[^,\\s]+\\s*,\\s*[^,\\s]+\\s*$ $sfl_xff_third;",
        "}",
        "",
        f"map {selected_variable} $sfl_client_ip {{",
        "    default $remote_addr;",
        "    ~(?<sfl_client_ip_source>.+) $sfl_client_ip_source;",
        "}",
        "",
    ]


def render_domain_config_files(state: dict, modsecurity_ip_list_dir: Path | None = None) -> dict[str, str]:
    enabled_sites = [site for site in state.get("sites", []) if site.get("enabled")]
    certificates = {certificate["id"]: certificate for certificate in state.get("certificates", [])}
    configs = {}
    for site in enabled_sites:
        hostname = site_hostnames(site)[0] if site_hostnames(site) else None
        filename = site_config_filename(site)
        configs[filename] = render_site_server(site, state, certificates, hostname, modsecurity_ip_list_dir)
    return configs


def render_modsecurity_ip_list_files(state: dict, output_dir: Path) -> dict[str, str]:
    enabled_sites = [site for site in state.get("sites", []) if site.get("enabled")]
    groups = {group.get("id"): group for group in state.get("ipGroups", []) if group.get("enabled")}
    files: dict[str, str] = {}

    provider_ids = {
        provider["id"]
        for provider in [*VERIFIED_BOT_PROVIDERS.values(), *VERIFIED_AI_BOT_PROVIDERS.values()]
        if provider.get("id") in groups
    }
    for provider_id in provider_ids:
        items = ip_group_items(groups.get(provider_id))
        if items:
            files[modsecurity_provider_ip_list_path(output_dir, provider_id).name] = "\n".join(items) + "\n"

    for site in enabled_sites:
        items = collect_site_access_allow_ips(state, site)
        if items:
            files[modsecurity_site_allow_ip_list_path(output_dir, site).name] = "\n".join(items) + "\n"

    return files


def write_modsecurity_ip_list_files(output_dir: Path, files: dict[str, str]) -> None:
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging_dir = Path(tempfile.mkdtemp(prefix="modsecurity-ip-lists.", dir=str(output_dir.parent)))
    previous_dir = output_dir.with_name(output_dir.name + ".old")
    try:
        for filename, content in files.items():
            _write_text_atomic(staging_dir / filename, content)
        if previous_dir.exists():
            shutil.rmtree(previous_dir, ignore_errors=True)
        if output_dir.exists():
            os.replace(output_dir, previous_dir)
        os.replace(staging_dir, output_dir)
        shutil.rmtree(previous_dir, ignore_errors=True)
    except Exception:
        shutil.rmtree(staging_dir, ignore_errors=True)
        if previous_dir.exists() and not output_dir.exists():
            try:
                os.replace(previous_dir, output_dir)
            except OSError:
                pass
        raise


def modsecurity_ip_list_dir(site: dict) -> Path | None:
    value = site.get("_modsecurityIpListDir")
    return value if isinstance(value, Path) else None


def modsecurity_provider_ip_list_path(output_dir: Path | None, provider_id: str) -> Path | None:
    if not output_dir:
        return None
    safe_id = safe_identifier(provider_id or "provider").lower()
    return output_dir / f"{safe_id}.txt"


def modsecurity_site_allow_ip_list_path(output_dir: Path | None, site: dict) -> Path | None:
    if not output_dir:
        return None
    site_id = safe_identifier(site.get("id") or site.get("name") or "site").lower()
    return output_dir / f"{site_id}.allow.txt"


def site_render_modsecurity_ip_list_dir(site: dict) -> Path | None:
    value = site.get("_modsecurityIpListDir")
    return value if isinstance(value, Path) else None


def write_nginx_config(root_dir: Path, state: dict) -> Path:
    """Atomically write the FreeWAF Nginx config bundle.

    Writes individual site files into a temporary staging directory beside the
    real ``sites/`` directory and only swaps the directory in once every file is
    fully on disk. Concurrent calls are serialised through a per-output lock
    file so two ``apply`` requests can never race a partial swap. The main
    output file is replaced via ``os.replace`` for atomicity as well.
    """

    output_file = nginx_output_file(root_dir)
    site_config_dir = nginx_site_config_dir(root_dir)
    modsecurity_ip_list_dir = nginx_modsecurity_ip_list_dir(root_dir)
    site_configs = render_domain_config_files(state, modsecurity_ip_list_dir)
    modsecurity_ip_lists = render_modsecurity_ip_list_files(state, modsecurity_ip_list_dir)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    site_config_dir.mkdir(parents=True, exist_ok=True)
    modsecurity_ip_list_dir.mkdir(parents=True, exist_ok=True)
    nginx_site_log_dir(root_dir).mkdir(parents=True, exist_ok=True)

    blocks = generate_nginx_common_blocks(state)
    if not site_configs:
        blocks.append("# No enabled sites.")
    blocks.append(f"include {nginx_path(str(site_config_dir / '*.conf'))};")
    output_payload = "\n\n".join(blocks) + "\n"

    lock_file = output_file.with_suffix(output_file.suffix + ".lock")
    with _file_lock(lock_file):
        # Stage every site config inside a sibling temp dir so the live
        # ``sites/`` directory keeps serving the previous good state until the
        # very last moment. ``mkdtemp`` guarantees a unique name.
        staging_dir = Path(tempfile.mkdtemp(prefix="sites.", dir=str(site_config_dir.parent)))
        previous_dir = site_config_dir.with_name(site_config_dir.name + ".old")
        try:
            for filename, content in site_configs.items():
                _write_text_atomic(staging_dir / filename, content)
            write_modsecurity_ip_list_files(modsecurity_ip_list_dir, modsecurity_ip_lists)

            # Swap directories: current sites/ -> sites.old/, staging -> sites/
            if previous_dir.exists():
                shutil.rmtree(previous_dir, ignore_errors=True)
            if site_config_dir.exists():
                os.replace(site_config_dir, previous_dir)
            os.replace(staging_dir, site_config_dir)
            shutil.rmtree(previous_dir, ignore_errors=True)
        except Exception:
            # Roll back: discard staging, restore previous sites if it exists.
            shutil.rmtree(staging_dir, ignore_errors=True)
            if previous_dir.exists() and not site_config_dir.exists():
                try:
                    os.replace(previous_dir, site_config_dir)
                except OSError:
                    pass
            raise

        _write_text_atomic(output_file, output_payload)

    return output_file


def _write_text_atomic(target: Path, content: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(tmp_path, target)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


class _file_lock:
    """Cross-platform best-effort exclusive file lock.

    Uses ``fcntl.flock`` on POSIX and ``msvcrt.locking`` on Windows. Falls back
    to a sentinel ``.locked`` file if neither is available so callers always
    serialise even on exotic filesystems. The lock is released regardless of
    how the with-block exits.
    """

    def __init__(self, path: Path, timeout: float = 30.0):
        self.path = Path(path)
        self.timeout = timeout
        self._handle = None
        self._mode = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = open(self.path, "a+")
        deadline = time.monotonic() + self.timeout
        try:
            import fcntl  # type: ignore[attr-defined]

            self._mode = "fcntl"
            while True:
                try:
                    fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError as error:
                    if error.errno not in (errno.EAGAIN, errno.EACCES):
                        raise
                    if time.monotonic() >= deadline:
                        raise TimeoutError(f"Timed out acquiring lock {self.path}") from error
                    time.sleep(0.1)
            return self
        except ImportError:
            pass

        try:
            import msvcrt  # type: ignore[import-not-found]

            self._mode = "msvcrt"
            while True:
                try:
                    msvcrt.locking(self._handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError(f"Timed out acquiring lock {self.path}")
                    time.sleep(0.1)
            return self
        except ImportError:
            pass

        # Fallback: spin on a sentinel file; not perfect but better than nothing.
        self._mode = "sentinel"
        sentinel = self.path.with_suffix(self.path.suffix + ".sentinel")
        while True:
            try:
                fd = os.open(str(sentinel), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                self._sentinel = sentinel
                return self
            except FileExistsError:
                if time.monotonic() >= deadline:
                    raise TimeoutError(f"Timed out acquiring lock {self.path}")
                time.sleep(0.1)

    def __exit__(self, exc_type, exc, tb):
        try:
            if self._mode == "fcntl":
                import fcntl  # type: ignore[attr-defined]

                fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
            elif self._mode == "msvcrt":
                import msvcrt  # type: ignore[import-not-found]

                try:
                    self._handle.seek(0)
                    msvcrt.locking(self._handle.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
            elif self._mode == "sentinel":
                try:
                    os.unlink(self._sentinel)
                except OSError:
                    pass
        finally:
            if self._handle is not None:
                try:
                    self._handle.close()
                except OSError:
                    pass
        return False


def run_nginx_command(command: str | None) -> dict:
    if not command:
        return {"configured": False, "ok": False, "stdout": "", "stderr": "No command configured"}

    completed = subprocess.run(
        shlex.split(command),
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )
    return {
        "configured": True,
        "ok": completed.returncode == 0,
        "returnCode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def nginx_runtime(root_dir: Path) -> dict:
    return {
        "outputFile": str(nginx_output_file(root_dir)),
        "siteConfigDir": str(nginx_site_config_dir(root_dir)),
        "accessLog": str(nginx_access_log_file(root_dir)),
        "siteLogDir": str(nginx_site_log_dir(root_dir)),
        "certDir": str(nginx_cert_dir(root_dir)),
        "testCommand": os.environ.get("NGINX_TEST_CMD", "nginx -t"),
        "reloadCommand": os.environ.get("NGINX_RELOAD_CMD", "nginx -s reload"),
    }


def nginx_cert_dir(root_dir: Path) -> Path:
    configured = Path(os.environ.get("NGINX_CERT_DIR", "./nginx/certs"))
    return configured if configured.is_absolute() else root_dir / configured


_LOG_TAIL_CACHE: dict[str, dict] = {}
_LOG_TAIL_LOCK = threading.Lock()
_LOG_INCREMENTAL_SCAN_CACHE: dict[str, dict[str, dict]] = {}
_LOG_INCREMENTAL_SCAN_LOCK = threading.Lock()
# Keep the UI tail cache small. Dashboard counters use the incremental scanner
# below, so retaining tens of thousands of parsed rows per file only burns RAM.
_LOG_TAIL_DEFAULT_MIN_ENTRIES = 1000
_SITE_ACCESS_LOG_PATTERN = re.compile(r"^accesslog_site_[A-Za-z0-9_-]+(?:-\d{8})?$")


def _log_tail_min_entries() -> int:
    raw = os.environ.get("FREEWAF_LOG_TAIL_MIN_ENTRIES", "").strip()
    try:
        value = int(raw) if raw else _LOG_TAIL_DEFAULT_MIN_ENTRIES
    except ValueError:
        value = _LOG_TAIL_DEFAULT_MIN_ENTRIES
    return max(1, value)


def _log_tail_max_entries() -> int:
    raw = os.environ.get("FREEWAF_LOG_TAIL_MAX_ENTRIES", "").strip()
    try:
        value = int(raw) if raw else 10_000
    except ValueError:
        value = 10_000
    return max(_log_tail_min_entries(), value)


def _log_tail_max_bytes() -> int:
    raw = os.environ.get("FREEWAF_LOG_TAIL_MAX_BYTES", "").strip()
    try:
        value = int(raw) if raw else 16 * 1024 * 1024
    except ValueError:
        value = 16 * 1024 * 1024
    return max(1024 * 1024, value)


def is_active_site_access_log(path: Path) -> bool:
    return bool(_SITE_ACCESS_LOG_PATTERN.match(path.name))


def _log_file_signature(log_file: Path) -> tuple:
    try:
        stat = log_file.stat()
    except OSError:
        return ()
    return (getattr(stat, "st_ino", 0), stat.st_size, getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))


def _convert_raw_log_entry(log_file: Path, raw: dict, sequence: int) -> dict:
    if not isinstance(raw, dict):
        return None
    verdict = str(raw.get("verdict") or "allow")
    status = parse_int(raw.get("status"))
    upstream_status = parse_int(raw.get("upstream_status"))
    if verdict == "allow" and status == 461 and upstream_status is None:
        verdict = "challenge"
    if verdict == "allow" and status in {403, 429, 460} and upstream_status is None:
        verdict = "block"
    reason = str(raw.get("reason") or ("Blocked by Nginx WAF" if verdict == "block" else "Allowed"))
    if verdict == "block" and reason == "Allowed":
        reason = "Blocked by ModSecurity or Nginx edge policy"
    if verdict == "challenge" and reason == "Allowed":
        reason = "Browser challenge required"
    return {
        "id": f"nginx-{safe_identifier(log_file.name)}-{sequence}",
        "at": str(raw.get("time") or ""),
        "siteId": None,
        "siteName": str(raw.get("host") or "Nginx"),
        "host": str(raw.get("host") or ""),
        "method": str(raw.get("method") or ""),
        "path": str(raw.get("uri") or ""),
        "ip": str(raw.get("remote_addr") or ""),
        "verdict": verdict,
        "statusCode": status,
        "upstreamStatus": upstream_status,
        "durationMs": int(float(raw.get("request_time") or 0) * 1000),
        "reason": reason,
        "matchedRules": [{"name": reason, "severity": "medium", "action": verdict}] if verdict != "allow" else [],
        "userAgent": str(raw.get("user_agent") or ""),
        "referer": str(raw.get("referer") or ""),
        "requestSize": 0,
    }


def _read_log_tail(log_file: Path, limit: int) -> list[dict]:
    """Return the most recent ``limit`` parsed entries for a single file using
    an inode/size aware tail cache so subsequent calls only read newly
    appended bytes."""
    requested_limit = int(limit)
    if requested_limit <= 0:
        return []
    key = str(log_file)
    signature = _log_file_signature(log_file)
    if not signature:
        return []
    inode, size, _mtime = signature
    hard_max = _log_tail_max_entries()
    # Always keep at least the caller's requested window in cache, otherwise
    # subsequent stat calls (which scan up to STATS_LOG_SCAN_LIMIT) would see
    # truncated counters under sustained traffic.
    cap = max(int(limit), _log_tail_min_entries())
    cap = min(cap, hard_max)

    with _LOG_TAIL_LOCK:
        cached = _LOG_TAIL_CACHE.get(key)
        cached_inode = cached.get("inode") if cached else None
        cached_size = cached.get("size") if cached else 0
        cached_seq = cached.get("seq") if cached else 0
        cached_entries = list(cached.get("entries") or []) if cached else []
        cached_partial = cached.get("partial") if cached else b""
        cached_trimmed = bool(cached.get("trimmed")) if cached else False

    rotated = cached is None or cached_inode != inode or size < cached_size
    needs_wider_tail = (
        not rotated
        and size == cached_size
        and cached_trimmed
        and len(cached_entries) < min(requested_limit, hard_max)
    )
    start_offset = 0 if rotated or needs_wider_tail else cached_size
    entries = [] if rotated or needs_wider_tail else cached_entries
    sequence = 0 if rotated or needs_wider_tail else cached_seq
    partial = b"" if rotated or needs_wider_tail else cached_partial
    trimmed = False if rotated or needs_wider_tail else cached_trimmed

    if (rotated or needs_wider_tail) and size > _log_tail_max_bytes():
        # Skip ahead to the last chunk; we only need the tail anyway.
        start_offset = size - _log_tail_max_bytes()

    if size > start_offset:
        try:
            with log_file.open("rb") as handle:
                if start_offset:
                    handle.seek(start_offset)
                buffer = partial + handle.read(size - start_offset)
        except OSError:
            buffer = partial

        # Keep an unfinished trailing line for the next call.
        if not buffer.endswith(b"\n"):
            newline = buffer.rfind(b"\n")
            if newline >= 0:
                partial = buffer[newline + 1 :]
                buffer = buffer[: newline + 1]
            else:
                # Whole buffer is one unterminated line; defer until completion.
                partial = buffer
                buffer = b""
        else:
            partial = b""

        for raw_line in buffer.splitlines():
            line = raw_line.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(raw, dict):
                continue
            sequence += 1
            converted = _convert_raw_log_entry(log_file, raw, sequence)
            if converted is not None:
                entries.append(converted)

        # Trim to cap so cache stays bounded.
        if len(entries) > cap:
            entries = entries[-cap:]
            trimmed = True

    with _LOG_TAIL_LOCK:
        _LOG_TAIL_CACHE[key] = {
            "inode": inode,
            "size": size,
            "seq": sequence,
            "entries": entries,
            "partial": partial,
            "trimmed": trimmed,
        }

    if not entries:
        return []
    return list(entries[-requested_limit:])


def parse_nginx_logs(root_dir: Path, limit: int = 500) -> list[dict]:
    entries: list[dict] = []
    for log_file in nginx_log_files(root_dir):
        if not log_file.exists() or not log_file.is_file():
            continue
        entries.extend(_read_log_tail(log_file, limit))

    return sorted(entries, key=lambda entry: entry.get("at") or "", reverse=True)[:limit]


def nginx_log_files(root_dir: Path) -> list[Path]:
    log_files = [nginx_access_log_file(root_dir)]
    site_log_dir = nginx_site_log_dir(root_dir)
    if site_log_dir.exists():
        log_files.extend(sorted(p for p in site_log_dir.glob("accesslog_*") if is_active_site_access_log(p)))
    return log_files


def scan_nginx_log_entries(root_dir: Path, cache_name: str, on_entry, on_reset=None) -> dict:
    """Incrementally scan every FreeWAF access log and call ``on_entry``.

    This is separate from the UI tail cache: dashboard counters need a
    long-retention accumulator, while log tables only need recent rows.
    """
    chunk_size = 8 * 1024 * 1024
    log_files = [path for path in nginx_log_files(root_dir) if path.exists() and path.is_file()]
    active_keys = {str(path) for path in log_files}

    with _LOG_INCREMENTAL_SCAN_LOCK:
        cache = _LOG_INCREMENTAL_SCAN_CACHE.setdefault(cache_name, {})
        for stale_key in [key for key in cache if key not in active_keys]:
            cache.pop(stale_key, None)
            if on_reset:
                on_reset(stale_key)

        for log_file in log_files:
            key = str(log_file)
            signature = _log_file_signature(log_file)
            if not signature:
                continue
            inode, size, _mtime = signature
            cached = cache.get(key) or {}
            cached_inode = cached.get("inode")
            cached_size = int(cached.get("size") or 0)
            sequence = int(cached.get("seq") or 0)
            partial = cached.get("partial") or b""
            rotated = cached_inode != inode or size < cached_size
            start_offset = 0 if rotated else cached_size
            if rotated:
                sequence = 0
                partial = b""
                if on_reset:
                    on_reset(key)
            if size <= start_offset:
                cache[key] = {"inode": inode, "size": size, "seq": sequence, "partial": partial}
                continue

            try:
                with log_file.open("rb") as handle:
                    if start_offset:
                        handle.seek(start_offset)
                    while True:
                        chunk = handle.read(chunk_size)
                        if not chunk:
                            break
                        buffer = partial + chunk
                        if not buffer.endswith(b"\n"):
                            newline = buffer.rfind(b"\n")
                            if newline >= 0:
                                partial = buffer[newline + 1 :]
                                buffer = buffer[: newline + 1]
                            else:
                                partial = buffer
                                buffer = b""
                        else:
                            partial = b""

                        for raw_line in buffer.splitlines():
                            line = raw_line.decode("utf-8", errors="replace").strip()
                            if not line:
                                continue
                            try:
                                raw = json.loads(line)
                            except json.JSONDecodeError:
                                continue
                            if not isinstance(raw, dict):
                                continue
                            sequence += 1
                            converted = _convert_raw_log_entry(log_file, raw, sequence)
                            if converted is not None:
                                on_entry(key, converted)
            except OSError:
                continue

            cache[key] = {"inode": inode, "size": size, "seq": sequence, "partial": partial}

        return {
            key: {
                "inode": value.get("inode"),
                "size": value.get("size"),
                "seq": value.get("seq"),
                "partial": base64.b64encode(value.get("partial") or b"").decode("ascii"),
            }
            for key, value in cache.items()
        }


def seed_nginx_log_scan_cache(cache_name: str, state: dict) -> None:
    with _LOG_INCREMENTAL_SCAN_LOCK:
        _LOG_INCREMENTAL_SCAN_CACHE[cache_name] = {
            key: {
                "inode": value.get("inode"),
                "size": int(value.get("size") or 0),
                "seq": int(value.get("seq") or 0),
                "partial": base64.b64decode(value.get("partial") or ""),
            }
            for key, value in (state or {}).items()
            if isinstance(value, dict)
        }


def clear_nginx_logs(root_dir: Path) -> None:
    for log_file in nginx_log_files(root_dir):
        if log_file.exists() and log_file.is_file():
            log_file.write_text("", encoding="utf-8")
    with _LOG_TAIL_LOCK:
        _LOG_TAIL_CACHE.clear()
    with _LOG_INCREMENTAL_SCAN_LOCK:
        _LOG_INCREMENTAL_SCAN_CACHE.clear()


def render_access_maps(state: dict, access_rules: list[dict]) -> list[str]:
    groups = {group["id"]: group for group in state.get("ipGroups", []) if group.get("enabled")}
    blocks = []
    for index, rule in enumerate(access_rules, start=1):
        condition_groups = rule.get("conditionGroups") if isinstance(rule.get("conditionGroups"), list) else []
        if condition_groups:
            for group_index, condition_group in enumerate(condition_groups, start=1):
                for condition_index, condition in enumerate(condition_group.get("conditions") or [], start=1):
                    items = collect_condition_ip_items(condition, groups)
                    if items:
                        blocks.append(render_geo_map(access_condition_geo_var(index, group_index, condition_index), items))
            continue

        items = collect_access_ips(rule, groups)
        if not items:
            continue
        blocks.append(render_geo_map(f"sfl_access_ip_{index}", items))
    return blocks


def render_bot_detection_maps() -> list[str]:
    return [
        "map $http_user_agent $sfl_bad_bot_ua {",
        "    default 0;",
        f"    ~*{BOT_BLOCK_UA_PATTERN} 1;",
        "}",
        "",
        "map $http_referer $sfl_bad_referer {",
        "    default 0;",
        f"    ~*{BOT_BLOCK_UA_PATTERN} 1;",
        "}",
        "",
        "map $request_method $sfl_unsafe_method {",
        "    default 0;",
        "    ~*^(?:TRACE|TRACK|CONNECT)$ 1;",
        "}",
        "",
        # Bypass bot challenge for authenticated WordPress users.
        # The wordpress_logged_in_ cookie proves the user already passed
        # the login flow, so re-challenging wp-admin/ requests is
        # unnecessary and causes the Customizer / Gutenberg to stall.
        "map $http_cookie $sfl_wp_logged_in_bypass {",
        "    default 0;",
        r"    ~*wordpress_logged_in_ 1;",
        "}",
        "",
    ]


def render_verified_bot_maps(state: dict, sites: list[dict]) -> list[str]:
    uses_search = any(site_verified_search_bots(site).get("enabled") for site in sites)
    uses_ai = any(site_verified_ai_bots(site).get("enabled") for site in sites)
    if not uses_search and not uses_ai:
        return []

    groups = {group.get("id"): group for group in state.get("ipGroups", []) if group.get("enabled")}
    blocks = []
    if uses_search:
        provider_vars = []
        for provider_name, provider in VERIFIED_BOT_PROVIDERS.items():
            verified_var = verified_provider_bot_var(provider_name)
            provider_vars.append(f"${verified_var}")
            blocks.extend(render_verified_provider_map(groups, provider_name, provider))

        blocks.extend(render_verified_combined_map("sfl_verified_search_bot", provider_vars))

    if uses_ai:
        for provider_name, provider in VERIFIED_AI_BOT_PROVIDERS.items():
            blocks.extend(render_verified_provider_map(groups, provider_name, provider, prefix="ai_"))

        for site in sites:
            config = site_verified_ai_bots(site)
            if not config.get("enabled"):
                continue
            provider_vars = [
                f"${verified_provider_bot_var(provider_name, prefix='ai_')}"
                for provider_name in config.get("allowedProviders", [])
                if provider_name in VERIFIED_AI_BOT_PROVIDERS
            ]
            blocks.extend(render_verified_combined_map(verified_ai_site_var(site), provider_vars))

    return blocks


def render_verified_provider_map(groups: dict[str, dict], provider_name: str, provider: dict, prefix: str = "") -> list[str]:
    ip_var = verified_provider_ip_var(provider_name, prefix)
    verified_var = verified_provider_bot_var(provider_name, prefix)
    return [
        render_geo_map(ip_var, ip_group_items(groups.get(provider["id"]))),
        f'map "${ip_var}:$http_user_agent" ${verified_var} {{',
        "    default 0;",
        f"    ~*^1:.*{provider['userAgentPattern']} 1;",
        "}",
        "",
    ]


def render_verified_combined_map(output_var: str, provider_vars: list[str]) -> list[str]:
    if not provider_vars:
        return [
            f"map $request_uri ${output_var} {{",
            "    default 0;",
            "}",
            "",
        ]
    return [
        f'map "{"|".join(provider_vars)}" ${output_var} {{',
        "    default 0;",
        "    ~1 1;",
        "}",
        "",
    ]


def verified_provider_bot_var(provider_name: str, prefix: str = "") -> str:
    return f"sfl_verified_{prefix}{safe_identifier(provider_name).lower()}_bot"


def verified_provider_ip_var(provider_name: str, prefix: str = "") -> str:
    return f"sfl_verified_{prefix}{safe_identifier(provider_name).lower()}_ip"


def render_challenge_maps() -> list[str]:
    return [
        "map \"$request_method:$uri\" $sfl_under_attack_bypass {",
        "    default 0;",
        "    ~*^(?:GET|HEAD):/(?:robots\\.txt|sitemap(?:_index)?\\.xml)$ 1;",
        "    ~*^(?:GET|HEAD):/.*\\.(?:css|js|mjs|map|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|eot|mp4|webm|mp3|wav|pdf|txt|xml)$ 1;",
        "}",
        "",
    ]


def render_wordpress_rate_limit_bypass_maps() -> list[str]:
    return [
        'map "$request_method:$uri" $sfl_wordpress_static_rate_bypass {',
        "    default 0;",
        r"    ~*^(?:GET|HEAD):/(?:wp-content/(?:uploads|themes|plugins|cache)/|wp-includes/(?:css|js|images|fonts)/|wp-admin/(?:css|js|images)/) 1;",
        "}",
        "map $uri $sfl_wordpress_editor_rate_bypass {",
        "    default 0;",
        r"    ~*^/wp-admin/(?:admin-ajax|async-upload|load-(?:scripts|styles)|post(?:-new)?|site-editor|widgets|customize|edit|media-new|upload|admin)\.php$ 1;",
        r"    ~*^/wp-json(?:/|$) 1;",
        "}",
        "map $args $sfl_wordpress_rest_route_rate_bypass {",
        "    default 0;",
        r"    ~*(?:^|&)rest_route=/ 1;",
        "}",
        "map $http_cookie $sfl_wordpress_logged_in_rate_bypass {",
        "    default 0;",
        r"    ~*wordpress_logged_in_ 1;",
        "}",
        'map "$sfl_wordpress_static_rate_bypass:$sfl_wordpress_editor_rate_bypass:$sfl_wordpress_rest_route_rate_bypass:$sfl_wordpress_logged_in_rate_bypass" $sfl_wordpress_rate_bypass {',
        "    default 0;",
        r"    ~^1: 1;",
        r"    ~^0:1:[^:]+:1$ 1;",
        r"    ~^0:[^:]+:1:1$ 1;",
        "}",
        "",
    ]


def render_global_rate_limit_zones(rate_limit: dict, verified_bot_bypass: bool = False) -> list[str]:
    rate = nginx_rate(rate_limit)
    lines = render_wordpress_rate_limit_bypass_maps()
    bypass_source = "$sfl_wordpress_rate_bypass"
    bypass_rules = ['    1 "";']
    if verified_bot_bypass:
        bypass_source = '"$sfl_verified_rate_bypass:$sfl_wordpress_rate_bypass"'
        bypass_rules = ['    ~^1: "";', '    ~^[^:]+:1$ "";']
    lines.extend(
        [
            f"map {bypass_source} $sfl_global_rate_key {{",
            "    default $sfl_client_ip;",
            *bypass_rules,
            "}",
            f"map {bypass_source} $sfl_global_rate_fingerprint_key {{",
            '    default "$sfl_client_ip|$request_method|$http_user_agent";',
            *bypass_rules,
            "}",
            "",
        ]
    )
    return [
        *lines,
        f"limit_req_zone $sfl_global_rate_key zone=freewaf_rate:{nginx_limit_zone_size()} rate={rate};",
        f"limit_req_zone $sfl_global_rate_fingerprint_key zone=freewaf_rate_fingerprint:{nginx_limit_zone_size()} rate={rate};",
    ]


def render_bot_limit_zones(sites: list[dict]) -> list[str]:
    zones = []
    for site in sites:
        protection = site_bot_protection(site)
        if not protection.get("antiReplay"):
            continue
        key = '"$sfl_client_ip|$request_method|$request_uri|$http_user_agent"'
        if site_verified_rate_bypass(site):
            key_name = bot_replay_key_name(site)
            zones.extend(
                [
                    f'map "$sfl_verified_rate_bypass:$sfl_client_ip:$request_method:$request_uri:$http_user_agent" ${key_name} {{',
                    '    ~^1: "";',
                    '    default "$sfl_client_ip|$request_method|$request_uri|$http_user_agent";',
                    "}",
                    "",
                ]
            )
            key = f"${key_name}"
        zones.append(f"limit_req_zone {key} zone={bot_replay_zone_name(site)}:{nginx_limit_zone_size()} rate=1r/s;")
    return zones


def shared_builtin_rules(state: dict) -> list[dict]:
    return [rule for rule in state.get("rules", []) if is_shared_builtin_rule(rule)]


def is_shared_builtin_rule(rule: dict) -> bool:
    return bool(
        rule.get("enabled")
        and rule.get("builtin")
        and rule.get("siteId") == "*"
        and rule.get("action") == "block"
        and rule.get("matcher") == "regex"
        and rule.get("target") in NATIVE_TARGETS
        and rule.get("target") != "body"
        and rule.get("id") not in BOT_RULE_IDS
        and str(rule.get("pattern") or "").strip()
    )


def shared_builtin_source_var(source_variable: str) -> str:
    return f"sfl_builtin_{safe_identifier(source_variable.lstrip('$')).lower()}"


def render_shared_builtin_rule_maps(state: dict) -> list[str]:
    rules = shared_builtin_rules(state)
    if not rules:
        return []

    variable_rules: dict[str, list[tuple[int, dict]]] = {}
    for index, rule in enumerate(rules, start=1):
        for source_variable in target_variables(str(rule.get("target") or "all")):
            variable_rules.setdefault(source_variable, []).append((index, rule))

    lines = ["# Shared builtin WAF rules are compiled once in the http context."]
    result_variables = []
    for source_variable, indexed_rules in variable_rules.items():
        result_variable = shared_builtin_source_var(source_variable)
        result_variables.append(f"${result_variable}")
        lines.extend([f"map {source_variable} ${result_variable} {{", "    default 0;"])
        seen_patterns: set[str] = set()
        for index, rule in reversed(indexed_rules):
            pattern = nginx_regex(rule.get("pattern") or "")
            raw = pattern[1:-1]
            if raw in seen_patterns:
                continue
            seen_patterns.add(raw)
            lines.append(f'    "~*{raw}" {index};')
        lines.extend(["}", ""])

    combined_source = ":".join(result_variables)
    lines.extend([f'map "{combined_source}" $sfl_builtin_rule_id {{', "    default 0;"])
    for index in range(len(rules), 0, -1):
        lines.append(f"    ~(?:^|:){index}(?::|$) {index};")
    lines.extend(["}", "", "map $sfl_builtin_rule_id $sfl_builtin_rule_reason {", '    default "Builtin WAF rule matched";'])
    for index, rule in enumerate(rules, start=1):
        reason = nginx_string(rule.get("name") or rule.get("id") or "Builtin WAF rule matched")
        lines.append(f'    {index} "{reason}";')
    lines.extend(["}", ""])
    return lines


def render_geo_map(variable_name: str, items: list[str]) -> str:
    lines = [
        f"geo $sfl_client_ip ${variable_name} {{",
        "    default 0;",
    ]
    for item in items:
        lines.append(f"    {item} 1;")
    lines.append("}")
    return "\n".join(lines)


def render_geo_block_maps(sites: list[dict]) -> list[str]:
    blocks = []
    for site in sites:
        config = site_geo_block(site)
        if not config.get("enabled"):
            continue
        variable = geo_block_var_name(site)
        countries = config.get("countries") or []
        cidrs = geo_block_cidrs(countries)
        lines = [
            f"geo $sfl_client_ip ${variable} {{",
            "    default 0;",
        ]
        if cidrs:
            lines.append(f"    # Geo Block: {', '.join(countries)}")
            for cidr in cidrs:
                lines.append(f"    {cidr} 1;")
        else:
            lines.append("    # Geo Block has no CIDR data. Check GEOIP_DB_FILE.")
        lines.append("}")
        blocks.extend(["\n".join(lines), ""])
    return blocks


def geo_block_cidrs(countries: list[str]) -> list[str]:
    country_set = frozenset(str(country or "").strip().upper() for country in countries if str(country or "").strip())
    if not country_set:
        return []
    db_file = geoip_db_file()
    if not db_file.exists() or not db_file.is_file():
        return []
    try:
        mtime = db_file.stat().st_mtime
    except OSError:
        return []
    cache_key = (str(db_file), mtime, tuple(sorted(country_set)))
    cached = GEO_CIDR_CACHE.get(cache_key)
    if cached is not None:
        return cached

    cidrs = []
    try:
        with gzip.open(db_file, "rt", encoding="utf-8", newline="") as source:
            for row in csv.reader(source):
                if len(row) < 3:
                    continue
                code = str(row[2] or "").strip().upper()
                if code not in country_set:
                    continue
                try:
                    start_address = ipaddress.ip_address(row[0].strip())
                    end_address = ipaddress.ip_address(row[1].strip())
                except ValueError:
                    continue
                if start_address.version != end_address.version:
                    continue
                cidrs.extend(str(network) for network in ipaddress.summarize_address_range(start_address, end_address))
    except (OSError, gzip.BadGzipFile, csv.Error):
        cidrs = []

    GEO_CIDR_CACHE.clear()
    GEO_CIDR_CACHE[cache_key] = cidrs
    return cidrs


def geoip_db_file() -> Path:
    return Path(os.environ.get("GEOIP_DB_FILE", "/var/lib/freewaf/geoip/dbip-country-lite.csv.gz"))


def site_hostnames(site: dict) -> list[str]:
    hostnames = site.get("hostnames") if isinstance(site.get("hostnames"), list) else []
    values = [str(hostname).strip() for hostname in hostnames if str(hostname or "").strip()]
    return values or ["_"]


def site_config_filename(site: dict) -> str:
    site_id = safe_identifier(site.get("id") or site.get("name") or "site")
    return f"{site_id}.conf"


def render_site_server(
    site: dict,
    state: dict,
    certificates: dict[str, dict],
    hostname: str | None = None,
    modsecurity_ip_list_dir: Path | None = None,
) -> str:
    hostnames = site_hostnames(site)
    defaults = application_defaults(state)
    proxy = site_proxy(site, defaults.get("proxy"))
    modsecurity = site_modsecurity(site, defaults.get("modSecurity"))
    render_site = {
        **site,
        "hostnames": hostnames,
        "proxy": proxy,
        "modSecurity": modsecurity,
        "_modsecurityIpListDir": modsecurity_ip_list_dir,
    }
    server_name = " ".join(escape_server_name(name) for name in hostnames)
    app_type = application_type(site)
    upstreams = site_upstreams(site)
    upstream_scheme = urlparse(upstreams[0]).scheme if upstreams else "http"
    upstream_name = backend_name(site)
    tls = site.get("tls") or {}
    certificate = certificates.get(tls.get("certificateId"))
    has_tls = bool(tls.get("enabled") and certificate)
    ports = site_ports(site)
    http_ports = [port for port, is_ssl in ports if not is_ssl]
    https_ports = [port for port, is_ssl in ports if is_ssl]
    blocks = [render_upstream(upstream_name, upstreams)] if app_type == "reverse_proxy" and upstreams else []

    redirect_code = int(proxy.get("redirectStatusCode") or site.get("redirectStatusCode") or 301)
    first_https_port = https_ports[0] if https_ports else int(site.get("listen") or 443)
    if has_tls and proxy.get("forceHttps") and redirect_code:
        for port in http_ports or [int(tls.get("httpListen") or 80)]:
            blocks.append(render_redirect_server(render_site, state, server_name, port, first_https_port, proxy, redirect_code))
    else:
        for port in http_ports:
            blocks.append(render_proxy_server(render_site, state, certificates, upstream_name, upstream_scheme, port, False, server_name, proxy))

    if https_ports:
        if has_tls:
            for port in https_ports:
                blocks.append(render_proxy_server(render_site, state, certificates, upstream_name, upstream_scheme, port, True, server_name, proxy))
        else:
            blocks.append(
                "\n".join(
                    [
                        f"# Site {nginx_comment(site.get('name'))} has HTTPS ports configured,",
                        "# but TLS is disabled or no valid certificate is selected.",
                    ]
                )
            )

    if not blocks:
        blocks.append(render_proxy_server(render_site, state, certificates, upstream_name, upstream_scheme, int(site.get("listen") or 8080), False, server_name, proxy))

    return "\n\n".join(blocks)


def render_upstream(name: str, upstreams: list[str]) -> str:
    lines = [f"upstream {name} {{"]
    for upstream in upstreams:
        parsed = urlparse(upstream)
        lines.append(f"    server {nginx_path(parsed.netloc)};")
    lines.extend(["    keepalive 16;", "    keepalive_timeout 30;", "}"])
    return "\n".join(lines)


def render_redirect_server(site: dict, state: dict, server_name: str, port: int, https_port: int, proxy: dict, redirect_code: int) -> str:
    listen_flags = ["proxy_protocol"] if client_ip_uses_proxy_protocol(state) else []
    if proxy.get("defaultServer"):
        listen_flags.append("default_server")
    listen_suffix = f" {' '.join(listen_flags)}" if listen_flags else ""
    lines = [
        "server {",
        f"    listen 0.0.0.0:{port}{listen_suffix};",
        *render_ipv6_listen(port, False, proxy, state),
        f"    server_name {server_name};",
        "",
        "    # Proxy timeouts - 5 minutes",
        "    proxy_connect_timeout 300;",
        "    proxy_read_timeout 300;",
        "    proxy_send_timeout 300;",
        "    client_body_timeout 300;",
        "    client_header_timeout 300;",
        "    client_max_body_size 100m;",
        "",
        "    set $sfl_block 0;",
        "    set $sfl_allow 0;",
        "    set $sfl_challenge 0;",
        "    set $sfl_verdict allow;",
        "    set $sfl_reason \"Allowed\";",
        "    set $sfl_verified_rate_bypass 0;",
        "",
        *render_challenge_validation(site),
        *render_verified_rate_bypass_setters(site),
        "",
        *render_log_directives(site, proxy),
        "    error_page 460 = @freewaf_block;",
        "    error_page 461 = @freewaf_challenge;",
        *render_rate_limit_error_page(site),
        "",
        *render_blocked_ips_directives(state),
        *render_modsecurity_directives(site),
        *render_site_waf_directives(site, state),
        "",
        *render_acme_challenge_location(),
        "",
        *render_safeline_locations(site),
        "",
        *render_internal_waf_locations(site, state),
        "",
        "    location / {",
        "        if ($sfl_block = 1) {",
        "            return 460;",
        "        }",
        "        if ($sfl_challenge = 1) {",
        "            return 461;",
        "        }",
        *render_http_flood_modsecurity_rules(site, state),
        *render_rate_limit(state, site),
        *render_bot_replay_limit(site),
        f"        return {redirect_code} https://$host:{https_port}$request_uri;",
        "    }",
        "}",
    ]
    return "\n".join(lines)


def render_proxy_server(
    site: dict,
    state: dict,
    certificates: dict[str, dict],
    upstream_name: str,
    upstream_scheme: str,
    port: int,
    is_ssl: bool,
    server_name: str,
    proxy: dict,
) -> str:
    tls = site.get("tls") or {}
    certificate = certificates.get(tls.get("certificateId"))
    listen_flags = []
    if is_ssl:
        listen_flags.append("ssl")
        if proxy.get("http2"):
            listen_flags.append("http2")
    if proxy.get("defaultServer"):
        listen_flags.append("default_server")
    if client_ip_uses_proxy_protocol(state):
        listen_flags.append("proxy_protocol")
    listen_suffix = f" {' '.join(listen_flags)}" if listen_flags else ""

    lines = [
        "server {",
        f"    listen 0.0.0.0:{port}{listen_suffix};",
        *render_ipv6_listen(port, is_ssl, proxy, state),
        f"    server_name {server_name};",
        "",
        "    set $sfl_block 0;",
        "    set $sfl_allow 0;",
        "    set $sfl_challenge 0;",
        "    set $sfl_verdict allow;",
        "    set $sfl_reason \"Allowed\";",
        "    set $sfl_verified_rate_bypass 0;",
        "",
        *render_challenge_validation(site),
        *render_verified_rate_bypass_setters(site),
        "",
        *render_log_directives(site, proxy),
        "    error_page 460 = @freewaf_block;",
        "    error_page 461 = @freewaf_challenge;",
        *render_rate_limit_error_page(site),
        "    error_page 502 =502 /.safeline/bad_gateway_page;",
        "    error_page 504 =504 /.safeline/gateway_timeout_page;",
        "",
    ]
    if is_ssl and certificate:
        lines.extend(
            [
                f"    ssl_certificate {certificate_file_path(certificate['certFile'])};",
                f"    ssl_certificate_key {certificate_file_path(certificate['keyFile'])};",
                "    ssl_protocols TLSv1.2 TLSv1.3;",
                "    ssl_session_cache shared:SSL:10m;",
                "    error_page 497 =302 https://$host:$server_port$request_uri;",
                "",
            ]
        )

    # Proxy timeouts - 5 minutes to avoid WordPress admin request timeouts
    lines.extend([
        "    proxy_connect_timeout 300;",
        "    proxy_read_timeout 300;",
        "    proxy_send_timeout 300;",
        "    client_body_timeout 300;",
        "    client_header_timeout 300;",
        "    client_max_body_size 100m;",
        "",
    ])

    lines.extend(render_blocked_ips_directives(state))

    if proxy.get("strictHost"):
        lines.extend(render_strict_host(site))

    lines.extend(render_modsecurity_directives(site))
    lines.extend(render_compression_directives(proxy))

    lines.extend(render_site_waf_directives(site, state))
    lines.extend(
        [
            "",
            *render_acme_challenge_location(),
            "",
            *render_safeline_locations(site),
            "",
            *render_internal_waf_locations(site, state),
            "",
            *render_wordpress_cache_min_fallback_location(site),
            *render_wordpress_admin_timeout_location(site, state, upstream_name, upstream_scheme, proxy, is_ssl),
            "    location / {",
            "        if ($sfl_block = 1) {",
            "            return 460;",
            "        }",
            "        if ($sfl_challenge = 1) {",
            "            return 461;",
            "        }",
            *render_application_location(site, state, upstream_name, upstream_scheme, proxy, is_ssl),
            "    }",
            "}",
        ]
    )

    return "\n".join(lines)


def render_wordpress_cache_min_fallback_location(site: dict) -> list[str]:
    if application_type(site) != "reverse_proxy":
        return []
    return [
        "    location ~ ^/wp-content/cache/min/1/(.+)$ {",
        "        rewrite ^/wp-content/cache/min/1/(.+)$ /$1 last;",
        "    }",
        "",
    ]

def render_wordpress_admin_timeout_location(
    site: dict,
    state: dict,
    upstream_name: str,
    upstream_scheme: str,
    proxy: dict,
    is_ssl: bool,
) -> list[str]:
    """Dedicated location for wp-admin / wp-login / admin-ajax / wp-json.

    Sets ``proxy_read_timeout`` to 300 s so heavy WordPress operations
    (plugin updates, WooCommerce batch jobs, import/export, Customizer
    saves) do not trigger 504 Gateway Timeout.
    """
    if application_type(site) != "reverse_proxy":
        return []

    headers: list[str] = [
        "        proxy_http_version 1.1;",
        "        proxy_set_header Upgrade $http_upgrade;",
        "        proxy_set_header Connection $sfl_connection_upgrade;",
        "        proxy_set_header X-Real-IP $sfl_client_ip;",
    ]
    if proxy.get("modifyHostHeader"):
        headers.append(f"        proxy_set_header Host {proxy.get('hostHeader') or '$http_host'};")
    if proxy.get("forwardedHeaders"):
        headers.extend(
            [
                f"        proxy_set_header X-Forwarded-For {xff_value(proxy)};",
                f"        proxy_set_header X-Forwarded-Proto {proxy.get('xForwardedProto') or '$scheme'};",
                f"        proxy_set_header X-Forwarded-Host {proxy.get('xForwardedHost') or '$http_host'};",
            ]
        )

    return [
        "",
        "    # WordPress admin / login / AJAX / REST API — longer timeout",
        "    # for heavy operations (plugin updates, WooCommerce, imports).",
        "    location ~ ^/(?:wp-admin|wp-login\\.php|wp-json)(?:/|$) {",
        *headers,
        "        proxy_set_header X-FreeWAF $sfl_verdict;",
        *render_proxy_ssl(upstream_scheme, proxy),
        "        proxy_buffering on;",
        "        proxy_buffer_size 32k;",
        "        proxy_buffers 8 32k;",
        "        proxy_busy_buffers_size 64k;",
        "        proxy_connect_timeout 60s;",
        "        proxy_read_timeout 300s;",
        "        proxy_send_timeout 120s;",
        f"        proxy_pass {upstream_scheme}://{upstream_name};",
        "    }",
        "",
        "    # admin-ajax.php — long-running background tasks (heartbeat, cron).", 
        "    location = /wp-admin/admin-ajax.php {",
        *headers,
        "        proxy_set_header X-FreeWAF $sfl_verdict;",
        *render_proxy_ssl(upstream_scheme, proxy),
        "        proxy_buffering on;",
        "        proxy_buffer_size 16k;",
        "        proxy_buffers 4 32k;",
        "        proxy_busy_buffers_size 64k;",
        "        proxy_connect_timeout 60s;",
        "        proxy_read_timeout 300s;",
        "        proxy_send_timeout 120s;",
        f"        proxy_pass {upstream_scheme}://{upstream_name};",
        "    }",
        "",
    ]


def render_blocked_ips_directives(state: dict) -> list[str]:
    """Generate nginx deny directives for IPs blocked via ipset."""
    blocked_ips = state.get("blockedIps", []) if isinstance(state.get("blockedIps"), list) else []
    if not blocked_ips:
        return []
    lines = ["    # Blocked IPs (managed by FreeWAF ipset)"]
    for blocked_ip in blocked_ips:
        ip = str(blocked_ip).strip()
        if ip:
            lines.append(f"    deny {ip};")
    lines.append("")
    return lines

def render_acme_challenge_location() -> list[str]:
    webroot = nginx_path(os.environ.get("CERTBOT_WEBROOT", "/var/www/html")).rstrip("/") or "/var/www/html"
    return [
        "    location ^~ /.well-known/acme-challenge/ {",
        *render_challenge_location_modsecurity_bypass(),
        "        default_type text/plain;",
        f"        root {webroot};",
        "        try_files $uri =404;",
        "    }",
    ]


def render_site_waf_directives(site: dict, state: dict) -> list[str]:
    rules = [
        rule
        for rule in state.get("rules", [])
        if rule.get("enabled")
        and rule.get("action") != "allow"
        and (rule.get("siteId") == "*" or rule.get("siteId") == site.get("id"))
        and should_emit_rule_for_site(rule, site)
        and not is_shared_builtin_rule(rule)
    ]
    allow_rules = [
        rule
        for rule in state.get("rules", [])
        if rule.get("enabled")
        and rule.get("action") == "allow"
        and (rule.get("siteId") == "*" or rule.get("siteId") == site.get("id"))
    ]
    access_rules = [
        (index, rule)
        for index, rule in enumerate([rule for rule in state.get("accessRules", []) if rule.get("enabled")], start=1)
        if rule.get("siteId") in {"*", site.get("id")}
    ]

    lines = []
    rule_index = 0
    for access_index, access_rule in [item for item in access_rules if item[1].get("action") == "allow"]:
        rule_index += 1
        lines.extend(render_access_rule_if(access_rule, access_index, "allow", rule_index, state))

    for access_index, access_rule in [item for item in access_rules if item[1].get("action") != "allow"]:
        rule_index += 1
        effect = "monitor" if site.get("mode") == "monitor" or access_rule.get("action") == "monitor" else "block"
        lines.extend(render_access_rule_if(access_rule, access_index, effect, rule_index, state))

    for rule in allow_rules:
        rule_index += 1
        lines.extend(render_rule_if(rule, "allow", rule_index))

    lines.extend(render_shared_builtin_rule_directives(site, state))

    for rule in rules:
        rule_index += 1
        if site.get("mode") == "monitor" or rule.get("action") == "monitor":
            lines.extend(render_rule_if(rule, "monitor", rule_index))
        else:
            lines.extend(render_rule_if(rule, "block", rule_index))

    lines.extend(render_geo_block(site))
    lines.extend(render_bot_protection(site))
    lines.extend(render_under_attack_protection(site))
    lines.extend(render_acl_notes(site))
    return lines


def render_shared_builtin_rule_directives(site: dict, state: dict) -> list[str]:
    if not shared_builtin_rules(state):
        return []
    verdict = "monitor" if site.get("mode") == "monitor" else "block"
    block_value = "0" if verdict == "monitor" else "1"
    return [
        "    set $sfl_shared_builtin_rule $sfl_builtin_rule_id;",
        "    if ($sfl_allow = 1) {",
        "        set $sfl_shared_builtin_rule 0;",
        "    }",
        "    if ($sfl_shared_builtin_rule != 0) {",
        f"        set $sfl_block {block_value};",
        f"        set $sfl_verdict {verdict};",
        "        set $sfl_reason $sfl_builtin_rule_reason;",
        "    }",
    ]


def render_internal_waf_locations(site: dict, state: dict) -> list[str]:
    lines = [
        "    location @freewaf_block {",
        "        internal;",
        "        add_header X-FreeWAF-Verdict block always;",
        "        default_type text/html;",
        f"        return 403 '{block_page(site)}';",
        "    }",
        "",
        "    location @freewaf_rate_limited {",
        "        internal;",
        "        set $sfl_verdict block;",
        "        set $sfl_reason \"HTTP flood rate limit\";",
        "        add_header X-FreeWAF-Verdict block always;",
        "        default_type text/html;",
        f"        return 429 '{rate_limit_page(site)}';",
        "    }",
    ]
    if not site_uses_challenge(site):
        return lines

    upstream = challenge_backend_url(state)
    secret = nginx_string(challenge_secret())
    common_proxy_headers = [
        f"        proxy_set_header X-FreeWAF-Challenge-Secret \"{secret}\";",
        f"        proxy_set_header X-FreeWAF-Challenge-Site \"{nginx_string(site.get('id') or '')}\";",
        "        proxy_set_header X-FreeWAF-Challenge-Host $host;",
        "        proxy_set_header X-Real-IP $sfl_client_ip;",
        "        proxy_set_header X-Forwarded-Proto $scheme;",
        "        proxy_set_header User-Agent $http_user_agent;",
        "        proxy_pass_request_body on;",
    ]
    tls_proxy = ["        proxy_ssl_verify off;"] if upstream.startswith("https://") else []
    lines.extend(
        [
            "",
            "    location @freewaf_challenge {",
            "        internal;",
            "        set $sfl_verdict challenge;",
            "        set $sfl_reason \"Browser challenge required\";",
            "        add_header X-FreeWAF-Verdict challenge always;",
            "        add_header Cache-Control \"no-store\" always;",
            *render_challenge_location_modsecurity_bypass(),
            "        proxy_set_header X-FreeWAF-Challenge-Render 1;",
            *common_proxy_headers,
            *tls_proxy,
            f"        proxy_pass {upstream};",
            "    }",
            "",
            "    location = /.freewaf/challenge/verify {",
            *render_challenge_location_modsecurity_bypass(),
            "        proxy_set_header X-FreeWAF-Challenge-Render 0;",
            *common_proxy_headers,
            *tls_proxy,
            f"        proxy_pass {upstream};",
            "    }",
        ]
    )
    return lines


def render_challenge_location_modsecurity_bypass() -> list[str]:
    if os.environ.get("NGINX_HAS_MODSECURITY", "false").lower() == "true":
        return ["        modsecurity off;"]
    return []


def challenge_backend_url(state: dict) -> str:
    panel = state.get("settings", {}).get("panel", {})
    scheme = "https" if panel.get("httpsEnabled") else "http"
    port = max(1, min(parse_int(os.environ.get("ADMIN_PORT")) or 7001, 65535))
    return f"{scheme}://127.0.0.1:{port}"


def render_challenge_validation(site: dict) -> list[str]:
    if not site_uses_challenge(site):
        return []
    secret = nginx_string(challenge_secret())
    return [
        "    secure_link \"$cookie_freewaf_challenge,$cookie_freewaf_challenge_expires\";",
        f"    secure_link_md5 \"$secure_link_expires|$host|$sfl_client_ip|$http_user_agent|{secret}\";",
        "    set $sfl_challenge_passed 0;",
        "    if ($secure_link = \"1\") {",
        "        set $sfl_challenge_passed 1;",
        "    }",
    ]


def render_verified_rate_bypass_setters(site: dict) -> list[str]:
    lines = []
    if site_verified_search_bots(site).get("bypassRateLimit"):
        lines.extend(
            [
                "    if ($sfl_verified_search_bot = 1) {",
                "        set $sfl_verified_rate_bypass 1;",
                "    }",
            ]
        )
    if site_verified_ai_bots(site).get("bypassRateLimit"):
        lines.extend(
            [
                f"    if (${verified_ai_site_var(site)} = 1) {{",
                "        set $sfl_verified_rate_bypass 1;",
                "    }",
            ]
        )
    return lines


def application_type(site: dict) -> str:
    value = str(site.get("applicationType") or "reverse_proxy").lower().replace("-", "_")
    return value if value in {"reverse_proxy", "static_files", "redirect"} else "reverse_proxy"


def render_application_location(site: dict, state: dict, upstream_name: str, upstream_scheme: str, proxy: dict, is_ssl: bool) -> list[str]:
    app_type = application_type(site)
    if app_type == "redirect":
        redirect = site.get("redirect") if isinstance(site.get("redirect"), dict) else {}
        address = nginx_path(redirect.get("address") or "http://127.0.0.1")
        status = int(redirect.get("statusCode") or proxy.get("redirectStatusCode") or 301)
        return [
            *render_http_flood_modsecurity_rules(site, state),
            *render_bot_rate_modsecurity_rules(site, state),
            *render_hsts_header(proxy, is_ssl),
            *render_dynamic_protection_headers(site),
            *render_bot_replay_limit(site),
            f"        return {status} {address}$request_uri;",
        ]

    if app_type == "static_files":
        root = static_root(site)
        return [
            *render_http_flood_modsecurity_rules(site, state),
            *render_bot_rate_modsecurity_rules(site, state),
            *render_hsts_header(proxy, is_ssl),
            *render_dynamic_protection_headers(site),
            *render_bot_replay_limit(site),
            f"        root {nginx_path(root)};",
            "        try_files $uri $uri/ =404;",
        ]

    lines = [
        *render_http_flood_modsecurity_rules(site, state),
        *render_bot_rate_modsecurity_rules(site, state),
        "        proxy_http_version 1.1;",
        "        proxy_set_header Upgrade $http_upgrade;",
        "        proxy_set_header Connection $sfl_connection_upgrade;",
        "        proxy_set_header X-Real-IP $sfl_client_ip;",
    ]
    if proxy.get("modifyHostHeader"):
        lines.append(f"        proxy_set_header Host {proxy.get('hostHeader') or '$http_host'};")
    if proxy.get("forwardedHeaders"):
        lines.extend(
            [
                f"        proxy_set_header X-Forwarded-For {xff_value(proxy)};",
                f"        proxy_set_header X-Forwarded-Proto {proxy.get('xForwardedProto') or '$scheme'};",
                f"        proxy_set_header X-Forwarded-Host {proxy.get('xForwardedHost') or '$http_host'};",
            ]
        )
    lines.extend(
        [
            "        proxy_set_header X-FreeWAF $sfl_verdict;",
            *render_hsts_header(proxy, is_ssl),
            *render_dynamic_protection_headers(site),
            *render_proxy_ssl(upstream_scheme, proxy),
            # Proxy buffering: moderate buffers for general traffic.
            # wp-admin/wp-json get larger buffers via dedicated locations.
            "        proxy_buffering on;",
            "        proxy_buffer_size 8k;",
            "        proxy_buffers 4 16k;",
            "        proxy_busy_buffers_size 32k;",
            # Timeouts for general traffic. wp-admin/wp-json get longer
            # timeouts via dedicated locations.
            "        proxy_connect_timeout 60s;",
            "        proxy_read_timeout 300s;",
            "        proxy_send_timeout 120s;",
            *render_rate_limit(state, site),
            *render_bot_replay_limit(site),
            f"        proxy_pass {upstream_scheme}://{upstream_name};",
        ]
    )
    return lines


def static_root(site: dict) -> str:
    static = site.get("static") if isinstance(site.get("static"), dict) else {}
    if static.get("root"):
        return str(static["root"])
    base = os.environ.get("NGINX_STATIC_ROOT", "./public/static").replace("\\", "/").rstrip("/")
    return f"{base}/{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def site_upstreams(site: dict) -> list[str]:
    if application_type(site) != "reverse_proxy":
        return []
    upstreams = site.get("upstreams") if isinstance(site.get("upstreams"), list) else []
    values = [str(item) for item in upstreams if str(item or "").strip()]
    return values or [str(site.get("origin") or "http://127.0.0.1:9090")]


def backend_name(site: dict, hostname: str | None = None) -> str:
    return f"backend_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def site_ports(site: dict) -> list[tuple[int, bool]]:
    raw_ports = site.get("ports") if isinstance(site.get("ports"), list) else []
    parsed = [parse_site_port(value) for value in raw_ports]
    parsed = [value for value in parsed if value]
    if parsed:
        return list(dict.fromkeys(parsed))
    tls = site.get("tls") or {}
    if tls.get("enabled"):
        if tls.get("redirectHttp"):
            return [(int(tls.get("httpListen") or 80), False), (int(site.get("listen") or 443), True)]
        return [(int(site.get("listen") or 443), True)]
    return [(int(site.get("listen") or 8080), False)]


def parse_site_port(value) -> tuple[int, bool] | None:
    item = str(value or "").strip().lower()
    if not item:
        return None
    is_ssl = item.endswith("_ssl")
    raw_port = item[:-4] if is_ssl else item
    if not re.match(r"^\d+$", raw_port):
        return None
    port = int(raw_port)
    if port < 1 or port > 65535:
        return None
    return port, is_ssl


def application_defaults(state: dict) -> dict:
    settings = state.get("settings") if isinstance(state.get("settings"), dict) else {}
    defaults = settings.get("applicationDefaults") if isinstance(settings.get("applicationDefaults"), dict) else {}
    return {
        "proxy": defaults.get("proxy") if isinstance(defaults.get("proxy"), dict) else {},
        "modSecurity": defaults.get("modSecurity") if isinstance(defaults.get("modSecurity"), dict) else {},
    }


def site_proxy(site: dict, defaults: dict | None = None) -> dict:
    tls = site.get("tls") if isinstance(site.get("tls"), dict) else {}
    site_proxy_config = site.get("proxy") if isinstance(site.get("proxy"), dict) else {}
    defaults = defaults if isinstance(defaults, dict) else {}
    proxy = {**site_proxy_config, **defaults}
    return {
        "forceHttps": bool(proxy.get("forceHttps", tls.get("redirectHttp", False))),
        "redirectStatusCode": int(proxy.get("redirectStatusCode") or site.get("redirectStatusCode") or 301),
        "hsts": bool(proxy.get("hsts", bool(tls.get("enabled")))),
        "hstsMaxAge": str(proxy.get("hstsMaxAge") or "15768000"),
        "gzip": proxy.get("gzip") is not False,
        "brotli": bool(proxy.get("brotli")),
        "http2": proxy.get("http2", tls.get("http2", True)) is not False,
        "ipv6": bool(proxy.get("ipv6")),
        "resetXff": proxy.get("resetXff") is not False,
        "defaultServer": bool(proxy.get("defaultServer")),
        "strictHost": bool(proxy.get("strictHost")),
        "accessLog": proxy.get("accessLog") is not False,
        "modifyHostHeader": proxy.get("modifyHostHeader") is not False,
        "forwardedHeaders": proxy.get("forwardedHeaders") is not False,
        "hostHeader": nginx_value(proxy.get("hostHeader") or "$http_host"),
        "xForwardedProto": nginx_value(proxy.get("xForwardedProto") or "$scheme"),
        "xForwardedHost": nginx_value(proxy.get("xForwardedHost") or "$http_host"),
        "proxySslServerName": proxy.get("proxySslServerName") is not False,
    }


def site_modsecurity(site: dict, defaults: dict | None = None) -> dict:
    config = site.get("modSecurity") if isinstance(site.get("modSecurity"), dict) else {}
    defaults = defaults if isinstance(defaults, dict) else {}
    merged = {**defaults, **config}
    mode = str(merged.get("mode") or "on").lower()
    ruleset = str(merged.get("ruleset") or "cms").lower()
    return {
        "enabled": bool(merged.get("enabled")),
        "mode": mode if mode in {"on", "detection_only"} else "on",
        "ruleset": ruleset if ruleset in {"cms", "comodo", "owasp"} else "cms",
        "requestBodyLimit": min(max(int(merged.get("requestBodyLimit") or 13107200), 131072), 1073741824),
    }


def render_modsecurity_directives(site: dict) -> list[str]:
    # Temporarily disable all ModSecurity rules
    if os.environ.get("FREEWAF_MODSECURITY_DISABLED", "false").lower() == "true":
        return []
    config = site.get("modSecurity") if isinstance(site.get("modSecurity"), dict) else {}
    if not config.get("enabled"):
        return []
    if os.environ.get("NGINX_HAS_MODSECURITY", "false").lower() != "true":
        return [
            "    # ModSecurity is enabled for this application, but NGINX_HAS_MODSECURITY is not true.",
            "",
        ]

    ruleset = str(config.get("ruleset") or "cms").lower()
    if ruleset == "cms":
        rules_file = os.environ.get("NGINX_MODSECURITY_CMS_RULES_FILE", "/etc/freewaf/modsecurity/cms-only.conf")
    elif ruleset == "owasp":
        rules_file = os.environ.get("NGINX_MODSECURITY_OWASP_RULES_FILE", "/etc/freewaf/modsecurity/owasp-crs.conf")
    else:
        rules_file = os.environ.get("NGINX_MODSECURITY_COMODO_RULES_FILE", "/etc/freewaf/modsecurity/comodo.conf")
    rules_file = rules_file.strip()
    if not rules_file:
        return [
            f"    # ModSecurity {nginx_comment(ruleset)} rules file is not configured.",
            "",
        ]

    engine = "DetectionOnly" if config.get("mode") == "detection_only" or site.get("mode") == "monitor" else "On"
    body_limit = min(max(int(config.get("requestBodyLimit") or 13107200), 131072), 1073741824)
    lines = [
        "    modsecurity on;",
        f"    # FreeWAF ModSecurity ruleset: {nginx_comment(ruleset)}",
        f"    modsecurity_rules_file {nginx_path(rules_file)};",
        f"    modsecurity_rules 'SecRuleEngine {engine}';",
        f"    modsecurity_rules 'SecRequestBodyLimit {body_limit}';",
        "",
    ]
    return lines


def bot_rate_challenge_required(site: dict) -> bool:
    protection = site_bot_protection(site)
    rate = protection.get("rateChallenge") or {}
    return bool(protection.get("antiBotChallenge") and rate.get("enabled"))


def http_flood_cooldown_required(site: dict) -> bool:
    limit = active_acl_access_limit(site)
    if not limit or not site_features(site).get("httpFlood"):
        return False
    if acl_limit_action(limit) not in {"block", "challenge_v1"}:
        return False
    count = max(1, int(limit.get("count") or 200))
    block_count = int(limit.get("blockCount") or 0)
    return block_count > count


def render_bot_rate_modsecurity_rules(site: dict, state: dict | None = None, indent: str = "        ") -> list[str]:
    if os.environ.get("FREEWAF_MODSECURITY_DISABLED", "false").lower() == "true":
        return []
    config = site.get("modSecurity") if isinstance(site.get("modSecurity"), dict) else {}
    protection = site_bot_protection(site)
    rate = protection.get("rateChallenge") or {}
    if (
        not config.get("enabled")
        or not protection.get("antiBotChallenge")
        or not rate.get("enabled")
        or os.environ.get("NGINX_HAS_MODSECURITY", "false").lower() != "true"
    ):
        return []

    window_seconds = bot_rate_window_seconds(rate)
    challenge_count = max(1, int(rate.get("challengeCount") or DEFAULT_BOT_RATE_CHALLENGE["challengeCount"]))
    block_count = max(challenge_count + 1, int(rate.get("blockCount") or DEFAULT_BOT_RATE_CHALLENGE["blockCount"]))
    block_seconds = bot_rate_block_minutes(rate) * 60
    site_key = safe_identifier(site.get("id") or site.get("name") or "site").lower()
    window_var = f"freewaf_{site_key}_bot_window"
    count_var = f"freewaf_{site_key}_bot_count"
    blocked_var = f"freewaf_{site_key}_bot_blocked"
    ua_hash_var = f"freewaf_{site_key}_bot_ua_hash"
    accept_hash_var = f"freewaf_{site_key}_bot_accept_hash"
    language_hash_var = f"freewaf_{site_key}_bot_language_hash"
    client_hints_hash_var = f"freewaf_{site_key}_bot_client_hints_hash"
    fingerprint_key = (
        f"freewaf_{site_key}_bot_%{{REMOTE_ADDR}}_%{{tx.{ua_hash_var}}}_"
        f"%{{tx.{accept_hash_var}}}_%{{tx.{language_hash_var}}}_%{{tx.{client_hints_hash_var}}}"
    )
    marker = f"FREEWAF_BOT_RATE_DONE_{safe_identifier(site.get('id') or site.get('name') or 'site').upper()}"
    base = modsecurity_rule_id_base(site)
    rules = [
        *render_access_allow_modsecurity_skip_rules(state or {}, site, marker, base + 100),
        *render_verified_bot_modsecurity_skip_rules(state or {}, site, marker, base + 120, require_rate_bypass=True),
        (
            f'SecAction "id:{base + 1},phase:1,nolog,pass,'
            f'setvar:tx.{ua_hash_var}=none,setvar:tx.{accept_hash_var}=none,'
            f'setvar:tx.{language_hash_var}=none,setvar:tx.{client_hints_hash_var}=none,'
            f'setvar:tx.{window_var}=%{{TIME_YEAR}}-%{{TIME_MON}}-%{{TIME_DAY}}-%{{TIME_HOUR}}-%{{TIME_MIN}}"'
        ),
        render_modsecurity_header_hash_rule("REQUEST_HEADERS:User-Agent", ua_hash_var, base + 20),
        render_modsecurity_header_hash_rule("REQUEST_HEADERS:Accept", accept_hash_var, base + 21),
        render_modsecurity_header_hash_rule("REQUEST_HEADERS:Accept-Language", language_hash_var, base + 22),
        render_modsecurity_header_hash_rule("REQUEST_HEADERS:Sec-CH-UA", client_hints_hash_var, base + 23),
        f'SecAction "id:{base + 29},phase:1,nolog,pass,initcol:global={fingerprint_key}"',
        *render_modsecurity_second_bucket_rules(window_seconds, window_var, base + 30),
        (
            f'SecRule GLOBAL:{blocked_var} "@eq 1" '
            f'"id:{base + 79},phase:1,deny,status:460,log,msg:FreeWAFBotRateCooldown"'
        ),
        (
            f'SecRule GLOBAL:{window_var} "!@streq %{{tx.{window_var}}}" "id:{base + 80},phase:1,nolog,pass,'
            f'setvar:global.{count_var}=0,setvar:global.{window_var}=%{{tx.{window_var}}}"'
        ),
        f'SecAction "id:{base + 81},phase:1,nolog,pass,setvar:global.{count_var}=+1"',
        (
            f'SecRule GLOBAL:{count_var} "@gt {block_count}" '
            f'"id:{base + 82},phase:1,deny,status:460,log,msg:FreeWAFBotRateBlock,'
            f'setvar:global.{blocked_var}=1,expirevar:global.{blocked_var}={block_seconds}"'
        ),
        (
            f'SecRule REQUEST_COOKIES:freewaf_challenge "@rx .+" '
            f'"id:{base + 83},phase:1,nolog,pass,skipAfter:{marker}"'
        ),
        (
            f'SecRule GLOBAL:{count_var} "@gt {challenge_count}" '
            f'"id:{base + 84},phase:1,deny,status:461,nolog,msg:FreeWAFBotRateChallenge"'
        ),
        f"SecMarker {marker}",
    ]
    return [f"{indent}modsecurity_rules '{rule}';" for rule in rules]


def render_modsecurity_header_hash_rule(target: str, tx_var: str, rule_id: int) -> str:
    return (
        f'SecRule {target} "@rx .+" '
        f'"id:{rule_id},phase:1,nolog,pass,t:none,t:sha1,t:hexEncode,setvar:tx.{tx_var}=%{{MATCHED_VAR}}"'
    )


def render_modsecurity_second_bucket_rules(window_seconds: int, window_var: str, first_rule_id: int) -> list[str]:
    if window_seconds >= 60:
        return []
    rules = []
    for bucket, start in enumerate(range(0, 60, window_seconds)):
        end = min(start + window_seconds - 1, 59)
        regex = modsecurity_second_range_regex(start, end)
        rules.append(
            f'SecRule TIME_SEC "{regex}" "id:{first_rule_id + bucket},phase:1,nolog,pass,'
            f'setvar:tx.{window_var}=%{{tx.{window_var}}}-{bucket}"'
        )
    return rules


def modsecurity_second_range_regex(start: int, end: int) -> str:
    values = []
    for second in range(start, end + 1):
        if second < 10:
            values.append(f"0?{second}")
        else:
            values.append(str(second))
    return "^(?:" + "|".join(values) + ")$"


def bot_rate_window_seconds(rate: dict) -> int:
    value = int(rate.get("windowSeconds") or DEFAULT_BOT_RATE_CHALLENGE["windowSeconds"])
    return value if value in {5, 10, 15, 20, 30, 60} else DEFAULT_BOT_RATE_CHALLENGE["windowSeconds"]


def bot_rate_block_minutes(rate: dict) -> int:
    value = int(rate.get("blockMinutes") or rate.get("blockMin") or DEFAULT_BOT_RATE_CHALLENGE["blockMinutes"])
    return value if value in {10, 30, 60} else DEFAULT_BOT_RATE_CHALLENGE["blockMinutes"]


def render_http_flood_modsecurity_rules(site: dict, state: dict | None = None, indent: str = "        ") -> list[str]:
    if os.environ.get("FREEWAF_MODSECURITY_DISABLED", "false").lower() == "true":
        return []
    config = site.get("modSecurity") if isinstance(site.get("modSecurity"), dict) else {}
    if (
        not config.get("enabled")
        or not http_flood_cooldown_required(site)
        or os.environ.get("NGINX_HAS_MODSECURITY", "false").lower() != "true"
    ):
        return []

    limit = active_acl_access_limit(site) or {}
    window_seconds = max(1, int(limit.get("period") or 10))
    count = max(1, int(limit.get("count") or 200))
    block_count = max(count + 1, int(limit.get("blockCount") or 500))
    block_seconds = max(1, int(limit.get("blockMin") or 60)) * 60
    site_key = safe_identifier(site.get("id") or site.get("name") or "site").lower()
    window_var = f"freewaf_{site_key}_flood_window"
    count_var = f"freewaf_{site_key}_flood_count"
    blocked_var = f"freewaf_{site_key}_flood_blocked"
    base = modsecurity_rule_id_base(site) + 200
    marker = f"FREEWAF_HTTP_FLOOD_DONE_{safe_identifier(site.get('id') or site.get('name') or 'site').upper()}"
    rules = [
        *render_access_allow_modsecurity_skip_rules(state or {}, site, marker, base + 60),
        *render_verified_bot_modsecurity_skip_rules(state or {}, site, marker, base + 80, require_rate_bypass=True),
        (
            f'SecAction "id:{base + 1},phase:1,nolog,pass,initcol:ip=%{{REMOTE_ADDR}},'
            f'setvar:tx.{window_var}=%{{TIME_YEAR}}-%{{TIME_MON}}-%{{TIME_DAY}}-%{{TIME_HOUR}}-%{{TIME_MIN}}"'
        ),
        *render_modsecurity_second_bucket_rules(window_seconds, window_var, base + 10),
        (
            f'SecRule IP:{blocked_var} "@eq 1" '
            f'"id:{base + 69},phase:1,deny,status:460,log,msg:FreeWAFHttpFloodCooldown"'
        ),
        (
            f'SecRule IP:{window_var} "!@streq %{{tx.{window_var}}}" "id:{base + 70},phase:1,nolog,pass,'
            f'setvar:ip.{count_var}=0,setvar:ip.{window_var}=%{{tx.{window_var}}}"'
        ),
        f'SecAction "id:{base + 71},phase:1,nolog,pass,setvar:ip.{count_var}=+1"',
        (
            f'SecRule IP:{count_var} "@gt {block_count}" '
            f'"id:{base + 72},phase:1,deny,status:460,log,msg:FreeWAFHttpFloodBlock,'
            f'setvar:ip.{blocked_var}=1,expirevar:ip.{blocked_var}={block_seconds}"'
        ),
        f"SecMarker {marker}",
    ]
    return [f"{indent}modsecurity_rules '{rule}';" for rule in rules]


def render_verified_bot_modsecurity_skip_rules(
    state: dict,
    site: dict,
    marker: str,
    first_rule_id: int,
    require_rate_bypass: bool = False,
) -> list[str]:
    providers = {}
    if site_verified_search_bots(site).get("bypassRateLimit"):
        providers.update(VERIFIED_BOT_PROVIDERS)
    ai_config = site_verified_ai_bots(site)
    if ai_config.get("bypassRateLimit"):
        providers.update(VERIFIED_AI_BOT_PROVIDERS)
    if not providers:
        return []
    if require_rate_bypass and not site_verified_rate_bypass(site):
        return []

    groups = {group.get("id"): group for group in state.get("ipGroups", []) if group.get("enabled")}
    output_dir = modsecurity_ip_list_dir(site)
    rules = []
    rule_id = first_rule_id
    for provider in providers.values():
        items = ip_group_items(groups.get(provider["id"]))
        if not items:
            continue
        ip_file = modsecurity_provider_ip_list_path(output_dir, provider["id"])
        if ip_file is not None:
            rules.append(
                "\n".join(
                    [
                        f'SecRule REMOTE_ADDR "@ipMatchFromFile {nginx_path(str(ip_file))}" '
                        f'"id:{rule_id},phase:1,nolog,pass,chain,skipAfter:{marker}"',
                        f'    SecRule REQUEST_HEADERS:User-Agent "@rx (?i:{provider["userAgentPattern"]})" "t:none"',
                    ]
                )
            )
            rule_id += 1
        else:
            for chunk in chunks(items, 80):
                rules.append(
                    "\n".join(
                        [
                            f'SecRule REMOTE_ADDR "@ipMatch {",".join(chunk)}" '
                            f'"id:{rule_id},phase:1,nolog,pass,chain,skipAfter:{marker}"',
                            f'    SecRule REQUEST_HEADERS:User-Agent "@rx (?i:{provider["userAgentPattern"]})" "t:none"',
                        ]
                    )
                )
                rule_id += 1
    return rules


def collect_site_access_allow_ips(state: dict, site: dict) -> list[str]:
    """Aggregate IP/CIDR items from access rules that unconditionally allow this site.

    Only rules whose conditions consist solely of ``source_ip`` matchers (cidr / in_ip_group)
    are eligible — otherwise the IP alone is not a sufficient reason to bypass the
    ModSecurity bot-rate / http-flood challenge at phase:1.
    """
    if not state or not site:
        return []
    groups = {group.get("id"): group for group in state.get("ipGroups", []) if group.get("enabled")}
    site_id = site.get("id")
    site_name = site.get("name")
    result: list[str] = []
    for rule in state.get("accessRules", []) or []:
        if not isinstance(rule, dict):
            continue
        if rule.get("enabled") is False:
            continue
        if rule.get("action") != "allow":
            continue
        if rule.get("continueDetect"):
            continue
        scope = rule.get("siteId")
        if scope not in (None, "*", "all", site_id, site_name):
            continue

        condition_groups = rule.get("conditionGroups") if isinstance(rule.get("conditionGroups"), list) else None
        if condition_groups:
            rule_items: list[str] = []
            ip_only = True
            for group in condition_groups:
                conditions = group.get("conditions") if isinstance(group, dict) else None
                if not conditions:
                    continue
                for condition in conditions:
                    if not isinstance(condition, dict):
                        continue
                    target = str(condition.get("target") or "")
                    operator = str(condition.get("operator") or "")
                    if target != "source_ip" or operator in {"not_cidr", "not_in_ip_group"}:
                        ip_only = False
                        break
                    rule_items.extend(collect_condition_ip_items(condition, groups))
                if not ip_only:
                    break
            if ip_only and rule_items:
                result.extend(rule_items)
        else:
            legacy = collect_access_ips(rule, groups)
            if legacy:
                result.extend(legacy)

    cleaned = [item.strip() for item in result if isinstance(item, str) and item.strip()]
    return list(dict.fromkeys(cleaned))


def render_access_allow_modsecurity_skip_rules(
    state: dict | None,
    site: dict,
    marker: str,
    first_rule_id: int,
) -> list[str]:
    """Skip ModSecurity rate rules for IPs explicitly allow-listed by access rules."""
    items = collect_site_access_allow_ips(state or {}, site)
    if not items:
        return []
    output_dir = modsecurity_ip_list_dir(site)
    ip_file = modsecurity_site_allow_ip_list_path(output_dir, site)
    if ip_file is not None:
        return [
            f'SecRule REMOTE_ADDR "@ipMatchFromFile {nginx_path(str(ip_file))}" '
            f'"id:{first_rule_id},phase:1,nolog,pass,skipAfter:{marker}"'
        ]
    rules: list[str] = []
    rule_id = first_rule_id
    for chunk in chunks(items, 80):
        rules.append(
            f'SecRule REMOTE_ADDR "@ipMatch {",".join(chunk)}" '
            f'"id:{rule_id},phase:1,nolog,pass,skipAfter:{marker}"'
        )
        rule_id += 1
    return rules


def modsecurity_rule_id_base(site: dict) -> int:
    value = safe_identifier(site.get("id") or site.get("name") or "site")
    digest = sum((index + 1) * ord(char) for index, char in enumerate(value)) % 100000
    return 8_600_000 + (digest * 1000)


def render_ipv6_listen(port: int, is_ssl: bool, proxy: dict, state: dict | None = None) -> list[str]:
    if not proxy.get("ipv6"):
        return []
    flags = ["ssl"] if is_ssl else []
    if is_ssl and proxy.get("http2"):
        flags.append("http2")
    if proxy.get("defaultServer"):
        flags.append("default_server")
    if client_ip_uses_proxy_protocol(state):
        flags.append("proxy_protocol")
    suffix = f" {' '.join(flags)}" if flags else ""
    return [f"    listen [::]:{port}{suffix};"]


def render_log_directives(site: dict, proxy: dict) -> list[str]:
    lines = []
    if proxy.get("accessLog"):
        lines.append(f"    access_log {nginx_site_access_log_directive(site)} freewaf;")
    else:
        lines.append("    access_log off;")
    lines.append(f"    error_log {nginx_site_error_log_directive(site)};")
    return lines


def render_strict_host(site: dict) -> list[str]:
    regex = server_names_regex(site.get("hostnames") or [])
    if not regex:
        return []
    return [
        f"    if ($host !~* {nginx_regex(regex)}) {{",
        "        return 404;",
        "    }",
        "",
    ]


def server_names_regex(hostnames: list[str]) -> str:
    patterns = []
    for hostname in hostnames:
        item = str(hostname or "").strip().lower()
        if not item or item in {"*", "_"}:
            continue
        if item.startswith("*."):
            patterns.append(r"(?:.+\.)?" + re.escape(item[2:]))
        else:
            patterns.append(re.escape(item))
    return f"^(?:{'|'.join(patterns)})$" if patterns else ""


def render_compression_directives(proxy: dict) -> list[str]:
    lines = [f"    gzip {'on' if proxy.get('gzip') else 'off'};"]
    if proxy.get("brotli"):
        if nginx_has_brotli():
            lines.append("    brotli on;")
        else:
            lines.append("    # Brotli is enabled in this application, but this Nginx build did not report Brotli support.")
    lines.append("")
    return lines


def nginx_has_brotli() -> bool:
    flag = os.environ.get("NGINX_HAS_BROTLI", "false").strip().lower()
    if flag in {"", "0", "false", "no", "off"}:
        return False
    if flag in {"force", "forced", "always"}:
        return True

    nginx_bin = nginx_binary()
    cached = _BROTLI_SUPPORT_CACHE.get(nginx_bin)
    if cached is not None:
        return cached

    try:
        completed = subprocess.run(
            [nginx_bin, "-V"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        _BROTLI_SUPPORT_CACHE[nginx_bin] = False
        return False

    output = f"{completed.stdout}\n{completed.stderr}".lower()
    supported = "brotli" in output
    _BROTLI_SUPPORT_CACHE[nginx_bin] = supported
    return supported


def nginx_binary() -> str:
    configured = os.environ.get("NGINX_BINARY", "").strip()
    if configured:
        return configured
    command = os.environ.get("NGINX_TEST_CMD", "nginx -t")
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = []
    return parts[0] if parts else "nginx"


def render_acl_notes(site: dict) -> list[str]:
    acl = site.get("acl") if isinstance(site.get("acl"), dict) else {}
    if not acl.get("enabled"):
        return []
    notes = []
    attack = acl.get("attackLimit") if isinstance(acl.get("attackLimit"), dict) else {}
    error = acl.get("errorLimit") if isinstance(acl.get("errorLimit"), dict) else {}
    if attack.get("enabled"):
        notes.extend(
            [
                f"    # Basic Attack Limit: {int(attack.get('count') or 10)} attacks / {int(attack.get('period') or 60)}s -> {attack.get('action') or 'block'}.",
                "    # Native Nginx cannot count detector-classified attacks without a detector module.",
            ]
        )
    if error.get("enabled"):
        notes.extend(
            [
                f"    # Basic Error Limit: {int(error.get('count') or 10)} responses / {int(error.get('period') or 10)}s for status {', '.join(error.get('statusCodes') or ['403', '404'])}.",
                "    # SafeLine CE enforces this via management/detector state; FreeWAF records the policy for parity.",
            ]
        )
    return [*notes, ""] if notes else []


def render_safeline_locations(site: dict) -> list[str]:
    challenge_url = os.environ.get("NGINX_CHAOS_CHALLENGE_URL", "").strip()
    static_dir = os.environ.get("NGINX_FREEWAF_STATIC_DIR", "").strip()
    lines = [
        "    location = /.safeline/forbidden_page {",
        "        internal;",
        "        default_type text/html;",
        f"        return 403 '{block_page(site)}';",
        "    }",
        "    location = /.safeline/acl_page {",
        "        internal;",
        "        default_type text/html;",
        f"        return 429 '{error_page_html('Request limited', 'FreeWAF rate limit was triggered.')}';",
        "    }",
        "    location = /.safeline/bad_gateway_page {",
        "        internal;",
        "        default_type text/html;",
        f"        return 502 '{error_page_html('Bad gateway', 'The protected upstream did not return a valid response.')}';",
        "    }",
        "    location = /.safeline/gateway_timeout_page {",
        "        internal;",
        "        default_type text/html;",
        f"        return 504 '{error_page_html('Gateway timeout', 'The protected upstream timed out.')}';",
        "    }",
        "    location ^~ /.safeline/offline_page {",
        "        internal;",
        "        add_header cache-control no-cache;",
        "        default_type text/html;",
        f"        return 503 '{error_page_html('Application offline', 'This application is temporarily unavailable.')}';",
        "    }",
        "    location ^~ /.safeline/challenge/v2/ {",
    ]
    if challenge_url:
        lines.extend(
            [
                f"        proxy_pass {nginx_path(challenge_url)};",
                "        proxy_set_header Host $host;",
            ]
        )
    else:
        lines.append("        return 204;")
    lines.extend(["    }", "    location ^~ /.safeline/static {"])
    if static_dir:
        lines.extend(["        charset utf-8;", f"        alias {nginx_path(static_dir)};"])
    else:
        lines.append("        return 404;")
    lines.append("    }")
    return lines


def xff_value(proxy: dict) -> str:
    return "$sfl_client_ip" if proxy.get("resetXff") else "$proxy_add_x_forwarded_for"


def render_hsts_header(proxy: dict, is_ssl: bool) -> list[str]:
    if not is_ssl or not proxy.get("hsts"):
        return []
    max_age = re.sub(r"[^0-9]", "", str(proxy.get("hstsMaxAge") or "15768000")) or "15768000"
    return [f"        add_header Strict-Transport-Security \"max-age={max_age};\" always;"]


def render_dynamic_protection_headers(site: dict) -> list[str]:
    dynamic = site_bot_protection(site).get("dynamicProtection") or {}
    if not dynamic.get("enabled"):
        return []
    enabled_parts = [
        name
        for name, enabled in (
            ("html", dynamic.get("html")),
            ("js", dynamic.get("js")),
            ("watermark", dynamic.get("watermark")),
        )
        if enabled
    ]
    value = ",".join(enabled_parts) or "on"
    return [
        f"        add_header X-FreeWAF-Dynamic-Protection \"{value}\" always;",
        "        add_header Cache-Control \"no-transform\" always;",
    ]


def render_bot_replay_limit(site: dict) -> list[str]:
    if not site_bot_protection(site).get("antiReplay"):
        return []
    return [f"        limit_req zone={bot_replay_zone_name(site)} burst=1 nodelay;"]


def render_proxy_ssl(upstream_scheme: str, proxy: dict) -> list[str]:
    if upstream_scheme != "https" or not proxy.get("proxySslServerName"):
        return []
    return [
        "        proxy_ssl_server_name on;",
        "        proxy_ssl_name $host;",
    ]


def render_acl_limit_zones(sites: list[dict]) -> list[str]:
    zones = []
    for site in sites:
        limit = active_acl_access_limit(site)
        if not limit:
            continue
        if acl_limit_uses_mapped_key(site, limit):
            zones.extend(render_acl_limit_key_maps(site, limit))
        zones.append(
            f"limit_req_zone {acl_limit_key(site, limit)} zone={acl_zone_name(site)}:{nginx_limit_zone_size()} rate={nginx_acl_rate(limit)};"
        )
        if site_features(site).get("httpFlood"):
            zones.append(
                f"limit_req_zone {acl_fingerprint_limit_key(site, limit)} zone={acl_fingerprint_zone_name(site)}:{nginx_limit_zone_size()} rate={nginx_acl_rate(limit)};"
            )
    return zones


def render_acl_limit_key_maps(site: dict, limit: dict) -> list[str]:
    challenge = acl_limit_action(limit) == "challenge_v1"
    verified_bypass = site_verified_rate_bypass(site)
    if challenge and verified_bypass:
        return [
            f'map "$sfl_verified_rate_bypass:$cookie_freewaf_challenge" ${acl_key_name(site)} {{',
            "    default $sfl_client_ip;",
            '    ~^1: "";',
            '    "0:passed" "";',
            "}",
            "",
            f'map "$sfl_verified_rate_bypass:$cookie_freewaf_challenge" ${acl_fingerprint_key_name(site)} {{',
            '    default "$sfl_client_ip|$request_method|$http_user_agent";',
            '    ~^1: "";',
            '    "0:passed" "";',
            "}",
            "",
        ]
    if challenge:
        return [
            f"map $cookie_freewaf_challenge ${acl_key_name(site)} {{",
            "    default $sfl_client_ip;",
            "    passed \"\";",
            "}",
            "",
            f"map $cookie_freewaf_challenge ${acl_fingerprint_key_name(site)} {{",
            "    default \"$sfl_client_ip|$request_method|$http_user_agent\";",
            "    passed \"\";",
            "}",
            "",
        ]
    if verified_bypass:
        return [
            f"map $sfl_verified_rate_bypass ${acl_key_name(site)} {{",
            "    default $sfl_client_ip;",
            '    1 "";',
            "}",
            "",
            f"map $sfl_verified_rate_bypass ${acl_fingerprint_key_name(site)} {{",
            '    default "$sfl_client_ip|$request_method|$http_user_agent";',
            '    1 "";',
            "}",
            "",
        ]
    return []


def active_acl_access_limit(site: dict) -> dict | None:
    acl = site.get("acl") if isinstance(site.get("acl"), dict) else {}
    limit = acl.get("accessLimit") if isinstance(acl.get("accessLimit"), dict) else {}
    if not acl.get("enabled") or not limit.get("enabled") or acl_rate_limit_mode(site) == "global":
        return None
    return limit


def acl_rate_limit_mode(site: dict) -> str:
    acl = site.get("acl") if isinstance(site.get("acl"), dict) else {}
    mode = str(acl.get("rateLimitMode") or "custom").lower()
    return mode if mode in {"global", "custom"} else "custom"


def acl_waiting_room(site: dict) -> bool:
    acl = site.get("acl") if isinstance(site.get("acl"), dict) else {}
    return bool(acl.get("waitingRoom"))


def acl_zone_name(site: dict) -> str:
    return f"sfl_acl_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def acl_fingerprint_zone_name(site: dict) -> str:
    return f"{acl_zone_name(site)}_fp"


def acl_key_name(site: dict) -> str:
    return f"sfl_acl_key_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def acl_fingerprint_key_name(site: dict) -> str:
    return f"{acl_key_name(site)}_fp"


def acl_limit_key(site: dict, limit: dict) -> str:
    if acl_limit_uses_mapped_key(site, limit):
        return f"${acl_key_name(site)}"
    return "$sfl_client_ip"


def acl_fingerprint_limit_key(site: dict, limit: dict) -> str:
    if acl_limit_uses_mapped_key(site, limit):
        return f"${acl_fingerprint_key_name(site)}"
    return "\"$sfl_client_ip|$request_method|$http_user_agent\""


def acl_limit_uses_mapped_key(site: dict, limit: dict) -> bool:
    return acl_limit_action(limit) == "challenge_v1" or site_verified_rate_bypass(site)


def acl_limit_action(limit: dict | None) -> str:
    action = str((limit or {}).get("action") or "block").lower()
    return action if action in {"allow", "block", "challenge_v1", "monitor"} else "block"


def any_uses_challenge(sites: list[dict]) -> bool:
    return any(site_uses_challenge(site) for site in sites)


def site_uses_challenge(site: dict) -> bool:
    return bool(
        site_bot_protection(site).get("antiBotChallenge")
        or acl_limit_action(active_acl_access_limit(site)) == "challenge_v1"
        or site_under_attack(site).get("enabled")
    )


def nginx_acl_rate(limit: dict) -> str:
    count = max(1, int(limit.get("count") or 200))
    period = max(1, int(limit.get("period") or 10))
    per_minute = max(1, round(count * 60 / period))
    if per_minute < 60:
        return f"{per_minute}r/m"
    return f"{max(1, round(count / period))}r/s"


def site_features(site: dict) -> dict:
    features = site.get("features") if isinstance(site.get("features"), dict) else {}
    return {
        "httpFlood": features.get("httpFlood") is not False,
        "botProtection": features.get("botProtection") is not False,
        "geoBlock": bool(features.get("geoBlock")),
    }


def site_geo_block(site: dict) -> dict:
    features = site_features(site)
    source = site.get("geoBlock") if isinstance(site.get("geoBlock"), dict) else {}
    countries = []
    for item in source.get("countries") or []:
        code = str(item or "").strip().upper()
        if re.match(r"^[A-Z]{2}$", code) and code not in countries:
            countries.append(code)
    action = str(source.get("action") or "block").lower()
    if action not in {"block", "monitor"}:
        action = "block"
    enabled = features["geoBlock"] and source.get("enabled") is not False and bool(countries)
    return {"enabled": enabled, "countries": countries, "action": action}


def geo_block_var_name(site: dict) -> str:
    return f"sfl_geo_block_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def site_bot_protection(site: dict) -> dict:
    features = site_features(site)
    source = site.get("botProtection") if isinstance(site.get("botProtection"), dict) else {}
    dynamic = source.get("dynamicProtection") if isinstance(source.get("dynamicProtection"), dict) else {}
    anti_replay = source.get("antiReplay") if isinstance(source.get("antiReplay"), dict) else {}
    verified = source.get("verifiedSearchBots") if isinstance(source.get("verifiedSearchBots"), dict) else {}
    verified_ai = source.get("verifiedAIBots") if isinstance(source.get("verifiedAIBots"), dict) else {}
    enabled = features["botProtection"] and source.get("enabled") is not False
    anti_bot = enabled and source.get("antiBotChallenge") is not False
    login = source.get("loginChallenge") if isinstance(source.get("loginChallenge"), dict) else {}
    rate = source.get("rateChallenge") if isinstance(source.get("rateChallenge"), dict) else {}
    login_patterns = [
        pattern
        for pattern in [str(item).strip() for item in (login.get("pathPatterns") or DEFAULT_BOT_LOGIN_PATH_PATTERNS) if str(item).strip()]
        if pattern not in LEGACY_WHMCS_LOGIN_PATH_PATTERNS
    ]
    challenge_count = max(1, parse_int(rate.get("challengeCount")) or DEFAULT_BOT_RATE_CHALLENGE["challengeCount"])
    block_count = max(challenge_count + 1, parse_int(rate.get("blockCount")) or DEFAULT_BOT_RATE_CHALLENGE["blockCount"])
    block_minutes = parse_int(rate.get("blockMinutes") or rate.get("blockMin")) or DEFAULT_BOT_RATE_CHALLENGE["blockMinutes"]
    if block_minutes not in {10, 30, 60}:
        block_minutes = DEFAULT_BOT_RATE_CHALLENGE["blockMinutes"]
    dynamic_enabled = enabled and bool(dynamic.get("enabled"))
    allowed_ai_providers = [
        provider_name
        for provider_name in (verified_ai.get("allowedProviders") or [])
        if provider_name in VERIFIED_AI_BOT_PROVIDERS
    ]
    if verified_ai.get("enabled") and "allowedProviders" not in verified_ai:
        allowed_ai_providers = list(VERIFIED_AI_BOT_PROVIDERS)
    return {
        "enabled": enabled,
        "antiBotChallenge": anti_bot,
        "verifiedSearchBots": {
            "enabled": anti_bot and verified.get("enabled") is not False,
            "bypassChallenge": verified.get("bypassChallenge") is not False,
            "bypassRateLimit": verified.get("bypassRateLimit") is not False,
        },
        "verifiedAIBots": {
            "enabled": anti_bot and bool(verified_ai.get("enabled")) and bool(allowed_ai_providers),
            "allowedProviders": allowed_ai_providers,
            "bypassChallenge": verified_ai.get("bypassChallenge") is not False,
            "bypassRateLimit": verified_ai.get("bypassRateLimit") is not False,
        },
        "loginChallenge": {
            "enabled": anti_bot and login.get("enabled") is not False and bool(login_patterns),
            "pathPatterns": login_patterns[:64],
        },
        "rateChallenge": {
            "enabled": anti_bot and bool(rate.get("enabled", DEFAULT_BOT_RATE_CHALLENGE["enabled"])),
            "windowSeconds": bot_rate_window_seconds(rate),
            "challengeCount": challenge_count,
            "blockCount": block_count,
            "blockMinutes": block_minutes,
        },
        "dynamicProtection": {
            "enabled": dynamic_enabled,
            "html": dynamic_enabled and bool(dynamic.get("html")),
            "js": dynamic_enabled and bool(dynamic.get("js")),
            "watermark": dynamic_enabled and bool(dynamic.get("watermark")),
        },
        "antiReplay": enabled and bool(anti_replay.get("enabled")),
    }


def site_under_attack(site: dict) -> dict:
    source = site.get("underAttack") if isinstance(site.get("underAttack"), dict) else {}
    return {"enabled": bool(source.get("enabled"))}


def site_verified_search_bots(site: dict) -> dict:
    protection = site_bot_protection(site)
    config = protection.get("verifiedSearchBots") if isinstance(protection.get("verifiedSearchBots"), dict) else {}
    return {
        "enabled": bool(config.get("enabled")),
        "bypassChallenge": bool(config.get("enabled") and config.get("bypassChallenge")),
        "bypassRateLimit": bool(config.get("enabled") and config.get("bypassRateLimit")),
    }


def site_verified_ai_bots(site: dict) -> dict:
    protection = site_bot_protection(site)
    config = protection.get("verifiedAIBots") if isinstance(protection.get("verifiedAIBots"), dict) else {}
    allowed_providers = [item for item in config.get("allowedProviders", []) if item in VERIFIED_AI_BOT_PROVIDERS]
    enabled = bool(config.get("enabled") and allowed_providers)
    return {
        "enabled": enabled,
        "allowedProviders": allowed_providers,
        "bypassChallenge": bool(enabled and config.get("bypassChallenge")),
        "bypassRateLimit": bool(enabled and config.get("bypassRateLimit")),
    }


def site_verified_rate_bypass(site: dict) -> bool:
    return bool(site_verified_search_bots(site).get("bypassRateLimit") or site_verified_ai_bots(site).get("bypassRateLimit"))


def any_verified_bot_rate_bypass(sites: list[dict]) -> bool:
    return any(site_verified_rate_bypass(site) for site in sites)


def verified_ai_site_var(site: dict) -> str:
    return f"sfl_verified_ai_bot_{safe_identifier(site.get('id') or site.get('name') or 'site').lower()}"


def bot_replay_zone_name(site: dict) -> str:
    return f"sfl_replay_{safe_identifier(site.get('id') or site.get('name') or 'site')}"


def bot_replay_key_name(site: dict) -> str:
    return f"{bot_replay_zone_name(site)}_key"


def should_emit_rule_for_site(rule: dict, site: dict) -> bool:
    features = site_features(site)
    if rule.get("id") in BOT_RULE_IDS:
        return features["botProtection"]
    return True


def render_bot_protection(site: dict) -> list[str]:
    protection = site_bot_protection(site)
    if not protection.get("antiBotChallenge"):
        return []

    effect = "monitor" if site.get("mode") == "monitor" else "block"
    login = protection.get("loginChallenge") or {}
    login_patterns = login.get("pathPatterns") or []
    login_regex = any_regex(login_patterns) if login.get("enabled") and login_patterns else ""
    lines = [
        "    set $sfl_bot_block 0;",
        "    set $sfl_bot_challenge 0;",
        "    if ($sfl_bad_bot_ua = 1) {",
        "        set $sfl_bot_block 1;",
        "    }",
        "    if ($sfl_bad_referer = 1) {",
        "        set $sfl_bot_block 1;",
        "    }",
        "    if ($sfl_unsafe_method = 1) {",
        "        set $sfl_bot_block 1;",
        "    }",
    ]
    if login_regex:
        lines.extend(
            [
                f"    if ($request_uri ~* {nginx_regex(login_regex)}) {{",
                "        set $sfl_bot_challenge 1;",
                "    }",
            ]
        )
    lines.extend(
        [
            "    if ($sfl_challenge_passed = 1) {",
            "        set $sfl_bot_challenge 0;",
            "    }",
            # Authenticated WordPress users should never be challenged on
            # wp-admin / wp-login — the session cookie is proof enough.
            "    if ($sfl_wp_logged_in_bypass = 1) {",
            "        set $sfl_bot_challenge 0;",
            "    }",
            *(
                [
                    "    if ($sfl_verified_search_bot = 1) {",
                    "        set $sfl_bot_challenge 0;",
                    "    }",
                ]
                if site_verified_search_bots(site).get("bypassChallenge")
                else []
            ),
            *(
                [
                    f"    if (${verified_ai_site_var(site)} = 1) {{",
                    "        set $sfl_bot_challenge 0;",
                    "    }",
                ]
                if site_verified_ai_bots(site).get("bypassChallenge")
                else []
            ),
            "    if ($sfl_allow = 1) {",
            "        set $sfl_bot_block 0;",
            "        set $sfl_bot_challenge 0;",
            "    }",
            "    if ($sfl_block = 1) {",
            "        set $sfl_bot_block 0;",
            "        set $sfl_bot_challenge 0;",
            "    }",
        ]
    )

    if effect == "monitor":
        lines.extend(
            [
                "    if ($sfl_bot_block = 1) {",
                "        set $sfl_verdict monitor;",
                "        set $sfl_reason \"Bot protection matched scanner headers\";",
                "    }",
                "    if ($sfl_bot_challenge = 1) {",
                "        set $sfl_verdict monitor;",
                "        set $sfl_reason \"Bot protection protected login path\";",
                "    }",
                "",
            ]
        )
        return lines

    lines.extend(
        [
            "    if ($sfl_bot_block = 1) {",
            "        set $sfl_block 1;",
            "        set $sfl_verdict block;",
            "        set $sfl_reason \"Bot protection matched scanner headers\";",
            "    }",
            "    if ($sfl_bot_challenge = 1) {",
            "        set $sfl_challenge 1;",
            "        set $sfl_verdict challenge;",
            "        set $sfl_reason \"Bot protection protected login path\";",
            "    }",
            "",
        ]
    )
    return lines


def render_under_attack_protection(site: dict) -> list[str]:
    if not site_under_attack(site).get("enabled"):
        return []
    return [
        "    set $sfl_under_attack_challenge 1;",
        "    if ($sfl_under_attack_bypass = 1) {",
        "        set $sfl_under_attack_challenge 0;",
        "    }",
        "    if ($sfl_challenge_passed = 1) {",
        "        set $sfl_under_attack_challenge 0;",
        "    }",
        # Authenticated WordPress users bypass Under Attack challenge too.
        "    if ($sfl_wp_logged_in_bypass = 1) {",
        "        set $sfl_under_attack_challenge 0;",
        "    }",
        *(
            [
                "    if ($sfl_verified_search_bot = 1) {",
                "        set $sfl_under_attack_challenge 0;",
                "    }",
            ]
            if site_verified_search_bots(site).get("bypassChallenge")
            else []
        ),
        *(
            [
                f"    if (${verified_ai_site_var(site)} = 1) {{",
                "        set $sfl_under_attack_challenge 0;",
                "    }",
            ]
            if site_verified_ai_bots(site).get("bypassChallenge")
            else []
        ),
        "    if ($sfl_allow = 1) {",
        "        set $sfl_under_attack_challenge 0;",
        "    }",
        "    if ($sfl_block = 1) {",
        "        set $sfl_under_attack_challenge 0;",
        "    }",
        "    if ($sfl_under_attack_challenge = 1) {",
        "        set $sfl_challenge 1;",
        "        set $sfl_verdict challenge;",
        "        set $sfl_reason \"Under Attack Mode browser challenge\";",
        "    }",
        "",
    ]


def render_geo_block(site: dict) -> list[str]:
    config = site_geo_block(site)
    if not config.get("enabled"):
        return []

    effect = "monitor" if site.get("mode") == "monitor" or config.get("action") == "monitor" else "block"
    match_var = "$sfl_geo_block_hit"
    reason = nginx_string(f"Geo block matched country: {', '.join(config.get('countries') or [])}")
    lines = [
        f"    set {match_var} 0;",
        f"    if (${geo_block_var_name(site)} = 1) {{",
        f"        set {match_var} 1;",
        "    }",
        "    if ($sfl_allow = 1) {",
        f"        set {match_var} 0;",
        "    }",
        "    if ($sfl_block = 1) {",
        f"        set {match_var} 0;",
        "    }",
    ]

    if effect == "monitor":
        lines.extend(
            [
                f"    if ({match_var} = 1) {{",
                "        set $sfl_verdict monitor;",
                f"        set $sfl_reason \"{reason}\";",
                "    }",
                "",
            ]
        )
        return lines

    lines.extend(
        [
            f"    if ({match_var} = 1) {{",
            "        set $sfl_block 1;",
            "        set $sfl_verdict block;",
            f"        set $sfl_reason \"{reason}\";",
            "    }",
            "",
        ]
    )
    return lines


def render_access_rule_if(rule: dict, access_index: int, effect: str, rule_index: int, state: dict) -> list[str]:
    match_var = f"$sfl_rule_{rule_index}"
    reason = nginx_string(rule.get("name") or rule.get("id") or "Access rule matched")
    condition_groups = access_condition_groups(rule, access_index, state)

    if not condition_groups:
        return [
            f"    # Access rule {nginx_comment(rule.get('name'))} has no active Nginx-native conditions.",
            "",
        ]

    lines = [f"    set {match_var} 0;"]
    for group_index, conditions in enumerate(condition_groups, start=1):
        token_name = f"sfl_access_{rule_index}_{group_index}"
        token_var = f"${token_name}"
        group_var = f"$sfl_access_{rule_index}_group_{group_index}"
        expected = "1" * len(conditions)
        lines.extend(
            [
                f"    set {token_var} \"\";",
                f"    set {group_var} 0;",
            ]
        )
        for condition in conditions:
            lines.extend(
                [
                    f"    if ({condition}) {{",
                    f"        set {token_var} \"${{{token_name}}}1\";",
                    "    }",
                ]
            )
        lines.extend(
            [
                f"    if ({token_var} = \"{expected}\") {{",
                f"        set {group_var} 1;",
                "    }",
                f"    if ({group_var} = 1) {{",
                f"        set {match_var} 1;",
                "    }",
            ]
        )

    if effect == "allow":
        if rule.get("continueDetect"):
            lines.extend(
                [
                    f"    if ({match_var} = 1) {{",
                    "        set $sfl_verdict allow;",
                    f"        set $sfl_reason \"Allowed by {reason}\";",
                    "    }",
                ]
            )
            return lines

        lines.extend(
            [
                f"    if ({match_var} = 1) {{",
                "        set $sfl_allow 1;",
                "        set $sfl_block 0;",
                "        set $sfl_verdict allow;",
                f"        set $sfl_reason \"Allowed by {reason}\";",
                "    }",
            ]
        )
        return lines

    verdict = "monitor" if effect == "monitor" else "block"
    block_value = "0" if effect == "monitor" else "1"
    lines.extend(
        [
            "    if ($sfl_allow = 1) {",
            f"        set {match_var} 0;",
            "    }",
            f"    if ({match_var} = 1) {{",
            f"        set $sfl_block {block_value};",
            f"        set $sfl_verdict {verdict};",
            f"        set $sfl_reason \"{reason}\";",
            "    }",
        ]
    )
    return lines


def access_condition_groups(rule: dict, access_index: int, state: dict) -> list[list[str]]:
    condition_groups = rule.get("conditionGroups") if isinstance(rule.get("conditionGroups"), list) else []
    if condition_groups:
        groups = {group["id"]: group for group in state.get("ipGroups", []) if group.get("enabled")}
        rendered_groups = []
        for group_index, condition_group in enumerate(condition_groups, start=1):
            rendered_conditions = []
            for condition_index, condition in enumerate(condition_group.get("conditions") or [], start=1):
                rendered = access_condition_expression(condition, access_index, group_index, condition_index, groups)
                if rendered:
                    rendered_conditions.append(rendered)
            if rendered_conditions:
                rendered_groups.append(rendered_conditions)
        return rendered_groups

    legacy_conditions = legacy_access_conditions(rule, access_index, state)
    return [legacy_conditions] if legacy_conditions else []


def legacy_access_conditions(rule: dict, access_index: int, state: dict) -> list[str]:
    groups = {group["id"]: group for group in state.get("ipGroups", []) if group.get("enabled")}
    conditions = []
    if collect_access_ips(rule, groups):
        conditions.append(f"$sfl_access_ip_{access_index} = 1")
    if rule.get("methods"):
        conditions.append(f"$request_method ~* {nginx_regex(exact_any_regex(rule['methods']))}")
    if rule.get("uriPatterns"):
        conditions.append(f"$request_uri ~* {nginx_regex(any_regex(rule['uriPatterns']))}")
    if rule.get("hostPatterns"):
        conditions.append(f"$host ~* {nginx_regex(any_regex(rule['hostPatterns']))}")
    if rule.get("userAgentPatterns"):
        conditions.append(f"$http_user_agent ~* {nginx_regex(any_regex(rule['userAgentPatterns']))}")
    return conditions


def access_condition_expression(condition: dict, access_index: int, group_index: int, condition_index: int, groups: dict[str, dict]) -> str | None:
    target = str(condition.get("target") or "source_ip")
    operator = str(condition.get("operator") or "equals")
    content = str(condition.get("content") or "")

    if target == "source_ip":
        if operator in {"cidr", "not_cidr", "in_ip_group", "not_in_ip_group"}:
            items = collect_condition_ip_items(condition, groups)
            if not items:
                return None
            expected = "0" if operator in {"not_cidr", "not_in_ip_group"} else "1"
            return f"${access_condition_geo_var(access_index, group_index, condition_index)} = {expected}"
        regex = exact_regex(content)
        negate = "!" if operator == "not_equals" else ""
        return f"$sfl_client_ip {negate}~* {nginx_regex(regex)}"

    variable = access_condition_variable(target)
    if not variable:
        return None

    if operator == "equals":
        return f"{variable} ~* {nginx_regex(exact_regex(content))}"
    if operator == "not_equals":
        return f"{variable} !~* {nginx_regex(exact_regex(content))}"
    if operator == "contains":
        return f"{variable} ~* {nginx_regex(re.escape(content))}"
    if operator == "not_contains":
        return f"{variable} !~* {nginx_regex(re.escape(content))}"
    if operator == "regex":
        return f"{variable} ~* {nginx_regex(content)}"
    if operator == "not_regex":
        return f"{variable} !~* {nginx_regex(content)}"
    return None


def access_condition_variable(target: str) -> str | None:
    if target == "source_ip":
        return "$sfl_client_ip"
    if target == "uri":
        return "$request_uri"
    if target == "host":
        return "$host"
    if target == "user_agent":
        return "$http_user_agent"
    if target == "method":
        return "$request_method"
    return None


def access_condition_geo_var(access_index: int, group_index: int, condition_index: int) -> str:
    return f"sfl_access_ip_{access_index}_{group_index}_{condition_index}"


def collect_condition_ip_items(condition: dict, groups: dict[str, dict]) -> list[str]:
    target = str(condition.get("target") or "")
    operator = str(condition.get("operator") or "")
    content = str(condition.get("content") or "")
    if target != "source_ip":
        return []
    if operator in {"cidr", "not_cidr"}:
        return [content] if content else []
    if operator in {"in_ip_group", "not_in_ip_group"}:
        return ip_group_items(groups.get(content, {}))
    return []


def collect_access_ips(rule: dict, groups: dict[str, dict]) -> list[str]:
    items = list(rule.get("ips") or [])
    for group_id in rule.get("ipGroupIds") or []:
        items.extend(ip_group_items(groups.get(group_id, {})))
    return list(dict.fromkeys(items))


def ip_group_items(group: dict | None) -> list[str]:
    if not group:
        return []
    items = list(group.get("items") or [])
    item_file = str(group.get("itemsFile") or "").strip()
    if item_file:
        path = Path(item_file)
        if path.exists() and path.is_file():
            file_items = [line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
            items.extend(file_items)
    return list(dict.fromkeys(items))


def render_rule_if(rule: dict, effect: str, index: int) -> list[str]:
    target = str(rule.get("target") or "all")
    if target == "body":
        return [
            f"    # Rule {nginx_comment(rule.get('name'))} targets request body.",
            "    # Native Nginx cannot inspect request bodies here; use ModSecurity, Lua, or njs for body rules.",
            "",
        ]

    variables = target_variables(target)
    pattern = nginx_regex(rule.get("pattern") or "")
    reason = nginx_string(rule.get("name") or rule.get("id") or "Rule matched")
    match_var = f"$sfl_rule_{index}"
    lines = [f"    set {match_var} 0;"]
    for variable in variables:
        lines.extend(
            [
                f"    if ({variable} ~* {pattern}) {{",
                f"        set {match_var} 1;",
                "    }",
            ]
        )

    if effect == "allow":
        lines.extend(
            [
                f"    if ({match_var} = 1) {{",
                "        set $sfl_allow 1;",
                "        set $sfl_block 0;",
                "        set $sfl_verdict allow;",
                f"        set $sfl_reason \"Allowed by {reason}\";",
                "    }",
            ]
        )
        return lines

    verdict = "monitor" if effect == "monitor" else "block"
    block_value = "0" if effect == "monitor" else "1"
    lines.extend(
        [
            "    if ($sfl_allow = 1) {",
            f"        set {match_var} 0;",
            "    }",
            f"    if ({match_var} = 1) {{",
            f"        set $sfl_block {block_value};",
            f"        set $sfl_verdict {verdict};",
            f"        set $sfl_reason \"{reason}\";",
            "    }",
        ]
    )
    return lines


def target_variables(target: str) -> list[str]:
    if target == "url":
        return ["$request_uri"]
    if target == "method":
        return ["$request_method"]
    if target == "ip":
        return ["$sfl_client_ip"]
    if target == "headers":
        return [
            "$http_user_agent",
            "$http_referer",
            "$http_content_type",
            "$http_cookie",
            "$http_range",
            "$http_accept_language",
            "$http_x_forwarded_for",
            "$http_x_requested_with",
        ]
    return ["$request_method", "$request_uri", *target_variables("headers"), "$sfl_client_ip"]


def render_rate_limit(state: dict, site: dict) -> list[str]:
    waiting_room = acl_waiting_room(site)
    acl_limit = active_acl_access_limit(site)
    if acl_limit:
        burst = max(1, int(acl_limit.get("count") or 200))
        lines = [render_limit_req_directive(acl_zone_name(site), burst, waiting_room)]
        if site_features(site).get("httpFlood"):
            lines.append(render_limit_req_directive(acl_fingerprint_zone_name(site), burst, waiting_room))
        if acl_limit_action(acl_limit) == "monitor":
            lines.append("        limit_req_dry_run on;")
        return lines

    rate_limit = state.get("settings", {}).get("rateLimit", {})
    if not rate_limit.get("enabled") or not site_features(site).get("httpFlood"):
        return []
    burst = max(1, int(rate_limit.get("max") or 120))
    return [
        render_limit_req_directive("freewaf_rate", burst, waiting_room),
        render_limit_req_directive("freewaf_rate_fingerprint", burst, waiting_room),
    ]


def render_limit_req_directive(zone: str, burst: int, waiting_room: bool) -> str:
    suffix = "" if waiting_room else " nodelay"
    return f"        limit_req zone={zone} burst={burst}{suffix};"


def render_rate_limit_error_page(site: dict) -> list[str]:
    acl_limit = active_acl_access_limit(site)
    if acl_limit_action(acl_limit) == "challenge_v1":
        return ["    error_page 429 = @freewaf_challenge;"]
    return ["    error_page 429 = @freewaf_rate_limited;"]


def nginx_rate(rate_limit: dict) -> str:
    maximum = max(1, int(rate_limit.get("max") or 120))
    window_ms = max(1000, int(rate_limit.get("windowMs") or 60000))
    per_minute = max(1, round(maximum * 60000 / window_ms))
    return f"{per_minute}r/m"


def escape_server_name(value: str) -> str:
    safe = str(value or "_").replace(";", "").replace("{", "").replace("}", "").strip()
    if safe == "*":
        return "_"
    return safe or "_"


def nginx_regex(value: str) -> str:
    escaped = str(value).replace("\n", " ").replace("\r", " ")
    escaped = escape_nginx_regex_backslashes(escaped.replace('\\"', '"'))
    escaped = escaped.replace('"', '\\"')
    return f'"{escaped}"'


def escape_nginx_regex_backslashes(value: str) -> str:
    valid_alpha_escapes = set("AaBbCcDdEeFfGgHhKkNnOoPpQqRrSsTtVvWwXxZz")
    literal_backslash = "__FREEWAF_LITERAL_BACKSLASH__"
    output = []
    index = 0
    while index < len(value):
        char = value[index]
        next_char = value[index + 1] if index + 1 < len(value) else ""
        if char == "\\" and next_char == "\\":
            output.append(literal_backslash)
            index += 2
            continue
        if char == "\\" and next_char.isalpha() and next_char not in valid_alpha_escapes:
            output.append(literal_backslash)
            output.append(next_char)
            index += 2
            continue
        output.append(char)
        index += 1
    return "".join(output).replace(literal_backslash, r"\\\\")


def any_regex(values: list[str]) -> str:
    return "(?:" + "|".join(str(value).replace("\n", " ").replace("\r", " ") for value in values if str(value).strip()) + ")"


def exact_regex(value: str) -> str:
    return "^" + re.escape(str(value or "")) + "$"


def exact_any_regex(values: list[str]) -> str:
    escaped = [str(value).replace("\\", "\\\\").replace(".", "\\.") for value in values if str(value).strip()]
    return "^(?:" + "|".join(escaped) + ")$"


def nginx_path(value: str) -> str:
    return str(value).replace("\\", "/").replace(";", "").replace("{", "").replace("}", "")


def certificate_file_path(value: str) -> str:
    raw = nginx_path(value)
    path = Path(raw)
    if path.is_absolute():
        return raw
    if raw.startswith("nginx/certs/"):
        configured = Path(os.environ.get("NGINX_CERT_DIR", "./nginx/certs"))
        return nginx_path(str(configured / path.name))
    return raw


def nginx_value(value: str) -> str:
    return str(value or "").replace("\x00", "").replace(";", "").replace("{", "").replace("}", "").replace("\n", " ")


def nginx_string(value: str) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace(";", "")


def nginx_comment(value: str) -> str:
    return str(value or "").replace("\n", " ").replace("\r", " ")


def safe_identifier(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_]", "_", str(value or "site"))
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe[:48] or "site"


def block_page(site: dict) -> str:
    title = "Request blocked"
    message = f"FreeWAF blocked this request for {site.get('name', 'this site')}."
    return error_page_html(title, message)


def rate_limit_page(site: dict) -> str:
    title = "Request limited"
    message = f"FreeWAF rate-limited this request for {site.get('name', 'this site')}."
    return error_page_html(title, message)


def challenge_page(site: dict) -> str:
    title = "Security check"
    message = f"FreeWAF is verifying this browser for {site.get('name', 'this site')}."
    html = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        f"<title>{title}</title>"
        "<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f5f7f8;color:#17202a;display:grid;min-height:100vh;place-items:center}"
        "main{width:min(560px,calc(100vw - 32px));background:#fff;border:1px solid #d8e0ea;border-radius:8px;padding:28px}"
        "h1{margin:0 0 12px;font-size:24px}p{line-height:1.55;margin:0;color:#526071}</style></head>"
        f"<body><main><h1>{title}</h1><p>{message}</p><noscript><p>JavaScript is required to continue.</p></noscript></main>"
        "<script>(function(){document.cookie=\"freewaf_challenge=passed; Max-Age=1800; Path=/; SameSite=Lax\";window.location.replace(window.location.href);})();</script>"
        "</body></html>"
    )
    return html.replace("\\", "\\\\").replace("'", "\\'")


def error_page_html(title: str, message: str) -> str:
    html = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        f"<title>{title}</title>"
        "<style>body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#f5f7f8;color:#17202a;display:grid;min-height:100vh;place-items:center}"
        "main{width:min(560px,calc(100vw - 32px));background:#fff;border:1px solid #d8e0ea;border-radius:8px;padding:28px}"
        "h1{margin:0 0 12px;font-size:24px}p{line-height:1.55;margin:0;color:#526071}</style></head>"
        f"<body><main><h1>{title}</h1><p>{message}</p></main></body></html>"
    )
    return html.replace("\\", "\\\\").replace("'", "\\'")


def parse_int(value) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def chunks(items: list[str], size: int) -> list[list[str]]:
    width = max(1, size)
    return [items[index : index + width] for index in range(0, len(items), width)]

from __future__ import annotations

import json
import os
import re
import threading
import uuid
import ipaddress
import base64
import csv
import gzip
import hashlib
import hmac
import math
import secrets
import struct
import time
from bisect import bisect_right
from collections import Counter
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from .defaults import (
    BUILTIN_RULES,
    DEFAULT_BOT_LOGIN_PATH_PATTERNS,
    DEFAULT_BOT_RATE_CHALLENGE,
    DEFAULT_SETTINGS,
    LEGACY_WHMCS_LOGIN_PATH_PATTERNS,
    VERIFIED_AI_BOT_PROVIDERS,
    create_default_state,
    managed_verified_bot_providers,
    utc_now,
)


ACTIONS = {"allow", "block", "monitor"}
MATCHERS = {"regex", "contains", "equals"}
MODES = {"block", "monitor"}
TARGETS = {"all", "url", "headers", "body", "method", "ip"}
SEVERITIES = {"low", "medium", "high", "critical"}
ACCESS_ACTIONS = {"allow", "deny", "monitor"}
ACL_ACTIONS = {"allow", "block", "challenge_v1", "monitor"}
ACL_RATE_LIMIT_MODES = {"global", "custom"}
APPLICATION_TYPES = {"reverse_proxy", "static_files", "redirect"}
MODSECURITY_MODES = {"on", "detection_only"}
MODSECURITY_RULESETS = {"cms", "comodo", "owasp"}
ACCESS_CONDITION_TARGETS = {"source_ip", "uri", "host", "user_agent", "method"}
ACCESS_CONDITION_OPERATORS = {
    "equals",
    "not_equals",
    "contains",
    "not_contains",
    "regex",
    "not_regex",
    "cidr",
    "not_cidr",
    "in_ip_group",
    "not_in_ip_group",
}
CLIENT_IP_SOURCES = {
    "socket",
    "xff_leftmost",
    "xff_rightmost",
    "xff_second_rightmost",
    "xff_third_rightmost",
    "header",
    "proxy_protocol",
}
CLIENT_IP_SOURCE_ALIASES = {
    "remote_addr": "socket",
    "socket_connection": "socket",
    "x_forwarded_for": "xff_leftmost",
    "xff": "xff_leftmost",
    "rightmost_xff": "xff_rightmost",
    "second_rightmost_xff": "xff_second_rightmost",
    "third_rightmost_xff": "xff_third_rightmost",
    "http_header": "header",
    "proxy": "proxy_protocol",
}
HTTP_HEADER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,126}$")
BOT_TYPE_PATTERNS = [
    # --- Attack / Scanner tools ---
    ("SQLMap", r"\bsqlmap(?:/|\b)"),
    ("Nikto", r"\bnikto(?:/|\b)"),
    ("Acunetix", r"\bacunetix(?:/|\b)"),
    ("Nessus", r"\bnessus(?:/|\b)"),
    ("Nuclei", r"\bnuclei(?:/|\b)"),
    ("WPScan", r"\bwpscan(?:/|\b)"),
    ("Masscan", r"\bmasscan(?:/|\b)"),
    ("Nmap", r"\bnmap(?:/|\b)"),
    ("ZGrab", r"\bzgrab(?:/|\b)"),
    ("ScanBot", r"\bscanbot(?:/|\b)"),
    ("BetaBot", r"\bbetabot(?:/|\b)"),
    ("Gobuster", r"\bgobuster(?:/|\b)"),
    ("DirBuster", r"\bdirbuster(?:/|\b)"),
    ("Dirsearch", r"\bdirsearch(?:/|\b)"),
    ("FFUF", r"\bffuf(?:/|\b)"),
    ("Feroxbuster", r"\bferoxbuster(?:/|\b)"),
    ("Jaeles", r"\bjaeles(?:/|\b)"),
    ("OpenVAS", r"\bopenvas(?:/|\b)"),
    ("Burp Suite", r"\bburpsuite(?:/|\b)"),
    ("Hydra", r"\bhydra(?:/|\b)"),
    # --- Social / Platform bots ---
    ("Meta External Agent", r"\bmeta-externalagent(?:/|\b)"),
    ("Meta External Fetcher", r"\bmeta-externalfetcher(?:/|\b)"),
    ("Facebook External Hit", r"\bfacebookexternalhit(?:/|\b)"),
    ("Facebot", r"\bfacebot(?:/|\b)"),
    ("Twitterbot", r"\btwitterbot(?:/|\b)"),
    ("LinkedInBot", r"\blinkedinbot(?:/|\b)"),
    ("Pinterestbot", r"\bpinterestbot(?:/|\b)"),
    ("Discordbot", r"\bdiscordbot(?:/|\b)"),
    ("Slackbot", r"\bslackbot(?:-linkexpanding)?(?:/|\b)"),
    ("TelegramBot", r"\btelegrambot(?:/|\b)"),
    ("WhatsApp", r"\bwhatsapp(?:/|\b)"),
    ("TikTokBot", r"\btiktok(?:bot|crawler|spider)(?:/|\b)|\bbytedance(?:bot|crawler|spider)(?:/|\b)"),
    ("LINE Bot", r"\bline(?:bot|crawler)(?:/|\b)"),
    ("WeChat", r"\bwechat(?:bot|crawler|spider)?(?:/|\b)|\bmicromessenger(?:/|\b)"),
    ("VK Robot", r"\bvkshare(?:/|\b)|\bvkrobot(?:/|\b)"),
    ("Snapchat", r"\bsnapchat(?:bot)?(?:/|\b)|\bsnap url preview service(?:/|\b)"),
    ("Redditbot", r"\bredditbot(?:/|\b)"),
    ("Mastodon", r"\bmastodon(?:bot)?(?:/|\b)"),
    # --- Google bots ---
    ("Googlebot", r"\bgooglebot(?:/(?:image|video|news))?(?:/|\b)"),
    ("Google Inspection Tool", r"\bgoogle-inspectiontool(?:/|\b)"),
    ("GoogleOther", r"\bgoogleother(?:-image|-video)?(?:/|\b)"),
    ("Storebot-Google", r"\bstorebot-google(?:/|\b)"),
    ("Google CloudVertexBot", r"\bgoogle-cloudvertexbot(?:/|\b)"),
    ("AdsBot-Google", r"\badsbot-google(?:/|\b)"),
    ("Mediapartners-Google", r"\bmediapartners-google(?:/|\b)"),
    ("FeedFetcher-Google", r"\bfeedfetcher-google(?:/|\b)"),
    ("Google-Safety", r"\bgoogle-safety(?:/|\b)"),
    # --- Search engine bots ---
    ("Bingbot", r"\bbingbot(?:/|\b)|\bmsnbot(?:/|\b)"),
    ("DuckDuckBot", r"\bduckduckbot(?:/|\b)"),
    ("Yahoo Slurp", r"\b(?:yahoo!\s+)?slurp(?:/|\b)"),
    ("Baiduspider", r"\bbaiduspider(?:/|\b)"),
    ("Baidu crawler", r"\bbaidu(?:\s+\w+)?\s+spider(?:/|\b)|\bbaidu(?:/|\b)"),
    ("Sogou Spider", r"\bsogou(?:\s+\w+)?\s+spider(?:/|\b)"),
    ("YandexBot", r"\byandexbot(?:/|\b)|\byandex(?:/[\d.]+)?\s+(?:bot|crawler)(?:/|\b)"),
    ("SeznamBot", r"\bseznambot(?:/|\b)"),
    ("Qwantify", r"\bqwantify(?:/|\b)"),
    ("NaverBot", r"\bnaver(?:bot|crawler|searchadvisor)(?:/|\b)|\byeti(?:/|\b)"),
    ("Daum", r"\bdaum(?:oa)?(?:/|\b)"),
    ("MojeekBot", r"\bmojeekbot(?:/|\b)"),
    ("Ecosia", r"\becosia(?:bot)?(?:/|\b)"),
    ("Bravebot", r"\bbravebot(?:/|\b)"),
    # --- AI / LLM crawlers ---
    ("GPTBot", r"\bgptbot(?:/|\b)"),
    ("ChatGPT-User", r"\bchatgpt-user(?:/|\b)"),
    ("OAI-SearchBot", r"\boai-searchbot(?:/|\b)"),
    ("ClaudeBot", r"\bclaudebot(?:/|\b)"),
    ("Claude-SearchBot", r"\bclaude-searchbot(?:/|\b)"),
    ("Claude-User", r"\bclaude-user(?:/|\b)"),
    ("Anthropic AI", r"\banthropic-ai(?:/|\b)"),
    ("PerplexityBot", r"\bperplexitybot(?:/|\b)"),
    ("Perplexity-User", r"\bperplexity-user(?:/|\b)"),
    ("Applebot", r"\bapplebot(?:-extended)?(?:/|\b)"),
    ("Amazonbot", r"\bamazonbot(?:/|\b)"),
    ("Bytespider", r"\bbytespider(?:/|\b)"),
    ("CCBot", r"\bccbot(?:/|\b)"),
    ("Cohere AI", r"\bcohere(?:-ai)?(?:/|\b)"),
    ("Diffbot", r"\bdiffbot(?:/|\b)"),
    ("ImagesiftBot", r"\bimagesiftbot(?:/|\b)"),
    ("Omgili", r"\bomgili(?:bot)?(?:/|\b)"),
    ("YouBot", r"\byoubot(?:/|\b)"),
    ("Meta Llama", r"\bmeta-llama(?:-scanner)?(?:/|\b)|\bllamabot(?:/|\b)"),
    ("MistralBot", r"\bmistral(?:bot)?(?:/|\b)"),
    # --- SEO / Marketing bots ---
    ("AhrefsBot", r"\bahrefsbot(?:/|\b)"),
    ("SemrushBot", r"\bsemrushbot(?:/|\b)|\bsemrush(?:/|\b)"),
    ("MJ12bot", r"\bmj12bot(?:/|\b)"),
    ("DotBot", r"\bdotbot(?:/|\b)"),
    ("PetalBot", r"\bpetalbot(?:/|\b)"),
    ("DataForSeoBot", r"\bdataforseobot(?:/|\b)"),
    ("Screaming Frog SEO Spider", r"\bscreaming frog seo spider(?:/|\b)"),
    ("BLEXBot", r"\bblexbot(?:/|\b)"),
    ("Linkdex", r"\blinkdex(?:/|\b)"),
    ("seoscanners.net", r"\bseoscanners\.net(?:/|\b)"),
    ("MozDotCom", r"\bmoz\.com(?:/|\b)|\brogerbot(?:/|\b)"),
    ("Serpstat", r"\bserpstat(?:bot)?(?:/|\b)"),
    ("Majestic", r"\bmj12bot(?:/|\b)|\bmajestic(?:/|\b)"),
    ("Cốc Cốc", r"\bcoccocbot(?:/|\b)|\bcoccoc(?:/|\b)"),
    # --- Archival / Research ---
    ("Internet Archive", r"\bia_archiver(?:/|\b)|\barchive\.org(?:/|\b)|\bwayback(?:/|\b)"),
    ("Common Crawl", r"\bcommoncrawl(?:/|\b)|\bccbot(?:/|\b)"),
    # --- Monitoring / Uptime ---
    ("UptimeRobot", r"\buptimerobot(?:/|\b)"),
    ("Pingdom", r"\bpingdom(?:/|\b)"),
    ("Better Uptime", r"\bbetter uptime bot(?:/|\b)|\bbetteruptime(?:/|\b)"),
    ("StatusCake", r"\bstatuscake(?:/|\b)"),
    ("Site24x7", r"\bsite24x7(?:/|\b)"),
    ("New Relic Synthetics", r"\bnewrelicpinger(?:/|\b)|\bnew relic synthetics(?:/|\b)"),
    ("Datadog", r"\bdatadog(?:/|\b)|\bdd-synthetics(?:/|\b)"),
    ("Checkly", r"\bcheckly(?:/|\b)"),
    ("Freshping", r"\bfreshping(?:/|\b)"),
    ("NodePing", r"\bnodeping(?:/|\b)"),
    ("Oh Dear", r"\bohdear(?:/|\b)"),
    ("Cronitor", r"\bcronitor(?:/|\b)"),
    ("HetrixTools", r"\bhetrix(?:bot|tools)(?:/|\b)"),
    # --- Automation / Headless ---
    ("Playwright", r"\bplaywright(?:/|\b)"),
    ("Puppeteer", r"\bpuppeteer(?:/|\b)"),
    ("Selenium", r"\bselenium(?:/|\b)"),
    ("Headless Chrome", r"\bheadlesschrome(?:/|\b)"),
    ("PhantomJS", r"\bphantomjs(?:/|\b)"),
    ("Cypress", r"\bcypress(?:/|\b)"),
    ("Nightwatch", r"\bnightwatch(?:js)?(?:/|\b)"),
    ("WebDriver", r"\bwebdriver(?:/|\b)"),
    # --- HTTP Libraries / Tools ---
    ("Postman Runtime", r"\bpostmanruntime(?:/|\b)"),
    ("Insomnia", r"\binsomnia(?:/|\b)"),
    ("cURL", r"(?:^|[\s;(])(?:curl|libcurl)(?:/|\b)"),
    ("Wget", r"(?:^|[\s;(])wget(?:/|\b)"),
    ("Python Requests", r"\bpython-requests(?:/|\b)"),
    ("Python urllib", r"\bpython-urllib(?:/|\b)"),
    ("Python aiohttp", r"\bpython(?:/[\d.]+)?\s+aiohttp(?:/|\b)|\baiohttp(?:/|\b)"),
    ("Python HTTPX", r"\bpython-httpx(?:/|\b)"),
    ("Go HTTP Client", r"\bgo-http-client(?:/|\b)"),
    ("OkHttp", r"\bokhttp(?:/|\b)"),
    ("Apache HttpClient", r"\bapache-httpclient(?:/|\b)"),
    ("node-fetch", r"\bnode-fetch(?:/|\b)"),
    ("Axios", r"\baxios(?:/|\b)"),
    ("libwww-perl", r"\blibwww-perl(?:/|\b)"),
    ("RestSharp", r"\brestsharp(?:/|\b)"),
    ("Dart HTTP", r"\bdart(?:/[\d.]+)?(?:\s+http)?(?:/|\b)|\bpackage:http(?:/|\b)"),
    ("Ktor", r"\bktor(?:/|\b)"),
    ("Guzzle", r"\bguzzlehttp(?:/|\b)"),
    # --- Feed readers ---
    ("Feedfinder", r"\bfeedfinder(?:/|\b)"),
    ("RSSingBot", r"\brssingbot(?:/|\b)"),
    ("Feedly", r"\bfeedly(?:bot|fetcher)?(?:/|\b)"),
    ("NewsBlur", r"\bnewsblur(?:/|\b)"),
    ("Feedbin", r"\bfeedbin(?:/|\b)"),
    ("Inoreader", r"\binoreader(?:/|\b)"),
    ("Netvibes", r"\bnetvibes(?:/|\b)"),
    # --- Miscellaneous bots ---
    ("Heritrix", r"\bheritrix(?:/|\b)"),
    ("Nutch", r"\bnutch(?:/|\b)"),
    ("Larbin", r"\blarbin(?:/|\b)"),
    ("Exabot", r"\bexabot(?:/|\b)"),
    ("MicrosoftPreview", r"\bmicrosoftpreview(?:/|\b)"),
    ("AdIdxBot", r"\badidxbot(?:/|\b)"),
    ("TinEye", r"\btineye(?:/|\b)"),
    ("TwengaBot", r"\btwengabot(?:/|\b)"),
    ("LTX71", r"\bltx71(?:/|\b)"),
    ("Moreover", r"\bmoreover(?:/|\b)"),
    ("Sitebot", r"\bsitebot(?:/|\b)"),
    ("Indy Library", r"\bindy library(?:/|\b)"),
    ("WebCapture", r"\bwebcapture(?:/|\b)"),
    ("TurnitinBot", r"\bturnitinbot(?:/|\b)"),
    ("PaperLiBot", r"\bpaperlibot(?:/|\b)"),
    ("DomainTools", r"\bdomaintools(?:/|\b)"),
    ("Meltwater", r"\bmeltwater(?:news)?(?:/|\b)"),
    ("Brandwatch", r"\bbrandwatch(?:/|\b)"),
    ("Censys", r"\bcensys(?:inspect)?(?:/|\b)"),
    ("Shodan", r"\bshodan(?:/|\b)"),
    ("ZoomInfo", r"\bzoominfo(?:bot)?(?:/|\b)"),
    ("BuiltWith", r"\bbuiltwith(?:/|\b)"),
    ("Wappalyzer", r"\bwappalyzer(?:/|\b)"),
    ("Netcraft", r"\bnetcraft(?:/|\b)"),
    ("Grapeshot", r"\bgrapeshot(?:/|\b)"),
    ("profound.net", r"\bprofound\.net(?:/|\b)"),
    ("PiplBot", r"\bpiplbot(?:/|\b)"),
    ("LinkWalker", r"\blinkwalker(?:/|\b)"),
    ("BLEXBot", r"\bblexbot(?:/|\b)"),
]
BOT_TYPE_REGEXES = [(name, re.compile(pattern, re.IGNORECASE)) for name, pattern in BOT_TYPE_PATTERNS]
GENERIC_BOT_TOKEN_REGEX = re.compile(
    r"(?<![A-Za-z0-9])([A-Za-z][A-Za-z0-9._-]{1,47}?(?:bot|crawler|spider|scraper|fetcher|extractor|scanner|probe|verifier|validator|checker|monitor|externalagent))(?=[/\s;,)]+|$)",
    re.IGNORECASE,
)
HLL_PRECISION = 8
HLL_REGISTER_COUNT = 1 << HLL_PRECISION
HLL_REGISTER_MASK = HLL_REGISTER_COUNT - 1
HLL_HASH_BITS = 64
HLL_REMAINING_BITS = HLL_HASH_BITS - HLL_PRECISION
USER_CLIENT_OS_PATTERNS = [
    ("Windows", r"windows nt|win64|win32"),
    ("ChromeOS", r"cros\b"),
    ("Android", r"android"),
    ("iOS", r"iphone|ipad|ipod|ipados"),
    ("macOS", r"mac os x|macintosh"),
    ("Linux", r"linux|x11(?!.*cros)"),
    ("BSD", r"freebsd|openbsd|netbsd"),
]
USER_CLIENT_OS_REGEXES = [(name, re.compile(pattern, re.IGNORECASE)) for name, pattern in USER_CLIENT_OS_PATTERNS]
USER_CLIENT_BROWSER_PATTERNS = [
    ("Microsoft Edge", r"\b(?:edg|edge|edga|edgios)/"),
    ("Brave", r"\bbrave(?:-browser)?/"),
    ("Opera", r"\b(?:opr|opera)/"),
    ("Samsung Internet", r"samsungbrowser/"),
    ("Vivaldi", r"\bvivaldi/"),
    ("Arc", r"\barc(?:-browser)?/"),
    ("Yandex Browser", r"\byabrowser/"),
    ("QQ Browser", r"\bqqbrowser/"),
    ("UC Browser", r"\b(?:ucbrowser|ucweb)/"),
    ("DuckDuckGo", r"\bduckduckgo/"),
    ("Chrome", r"\b(?:chrome|crios|chromium)/"),
    ("Firefox", r"\b(?:firefox|fxios)/"),
]
USER_CLIENT_BROWSER_REGEXES = [(name, re.compile(pattern, re.IGNORECASE)) for name, pattern in USER_CLIENT_BROWSER_PATTERNS]
GEOIP_READER_LOCK = threading.Lock()
GEOIP_READER = None
GEOIP_READER_PATH = None
GEOIP_READER_MTIME = None
ACCESS_INSERT_POSITIONS = {"first", "last"}
USER_ROLES = {"admin", "viewer"}
PASSWORD_ITERATIONS = 200_000
BOT_RATE_WINDOW_SECONDS = {5, 10, 15, 20, 30, 60}
BOT_RATE_BLOCK_MINUTES = {10, 30, 60}


class StoreError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


class Store:
    def __init__(self, file_path: str | Path):
        self.file_path = Path(file_path)
        self.state: dict | None = None
        self.lock = threading.RLock()

    def init(self) -> None:
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        if not self.file_path.exists():
            self.state = create_default_state()
            self.persist()
            return

        with self.file_path.open("r", encoding="utf-8") as handle:
            raw_state = json.load(handle)
        self.state = normalize_state(raw_state)

        changed = self.state != raw_state
        now = utc_now()

        # Migration: upgrade accessLimit for WordPress-compatible defaults
        for site in self.state.get("sites", []):
            acl = site.get("acl")
            if not isinstance(acl, dict):
                continue
            access = acl.get("accessLimit")
            if not isinstance(access, dict):
                continue
            if access.get("count") == 200 and access.get("period") == 10:
                access["count"] = 500
                access["blockCount"] = max(access.get("blockCount", 1200), 1200)
                site["updatedAt"] = now
                changed = True

        existing = {rule["id"]: rule for rule in self.state["rules"]}
        for rule in BUILTIN_RULES:
            stored_rule = existing.get(rule["id"])
            if not stored_rule:
                self.state["rules"].append({**deepcopy(rule), "createdAt": now, "updatedAt": now})
                changed = True
                continue
            if not stored_rule.get("builtin"):
                continue

            preserved = {
                "enabled": stored_rule.get("enabled", rule["enabled"]),
                "siteId": stored_rule.get("siteId") or rule["siteId"],
                "createdAt": stored_rule.get("createdAt") or now,
            }
            updated_rule = {**stored_rule, **deepcopy(rule), **preserved}
            if updated_rule != stored_rule:
                updated_rule["updatedAt"] = now
                stored_rule.clear()
                stored_rule.update(updated_rule)
                changed = True

        # Remove builtin rules that are no longer in BUILTIN_RULES (e.g. after
        # upstream cleanup of Safeline compatibility rules).
        builtin_ids = {rule["id"] for rule in BUILTIN_RULES}
        before_count = len(self.state["rules"])
        self.state["rules"] = [
            rule for rule in self.state["rules"]
            if not rule.get("builtin") or rule["id"] in builtin_ids
        ]
        if len(self.state["rules"]) != before_count:
            changed = True

        if not self.state["ipGroups"]:
            self.state["ipGroups"].append(
                {
                    "id": "ipgroup-local",
                    "name": "Local addresses",
                    "description": "Loopback addresses useful for local testing.",
                    "items": ["127.0.0.1/32", "::1/128"],
                    "enabled": True,
                    "createdAt": now,
                    "updatedAt": now,
                }
            )
            changed = True

        existing_groups = {group["id"]: group for group in self.state["ipGroups"]}
        for provider_name, provider in managed_verified_bot_providers().items():
            stored = existing_groups.get(provider["id"])
            managed = {
                "id": provider["id"],
                "name": provider["name"],
                "description": provider["description"],
                "referenceUrl": provider.get("referenceUrl", ""),
                "managed": True,
                "provider": provider_name,
                "enabled": True,
                "createdAt": (stored or {}).get("createdAt") or now,
                "updatedAt": (stored or {}).get("updatedAt") or now,
            }
            if stored:
                updated = {**stored, **managed}
                if provider.get("items") and not stored.get("items") and not stored.get("itemsFile"):
                    updated["items"] = list(provider["items"])
                if updated != stored:
                    stored.clear()
                    stored.update(updated)
                    changed = True
            else:
                self.state["ipGroups"].append(
                    {**managed, "items": list(provider.get("items", [])), "lastSyncedAt": "", "lastSyncStatus": "", "lastSyncMessage": ""}
                )
                changed = True

        for index, group in enumerate(self.state["ipGroups"]):
            prepared = self.prepare_ip_group_storage(group)
            if prepared != group:
                self.state["ipGroups"][index] = prepared
                changed = True

        if changed:
            self.persist()

    def get_state(self) -> dict:
        with self.lock:
            return deepcopy(self._state())

    def get_state_fields(self, *fields: str) -> dict:
        with self.lock:
            state = self._state()
            return {field: deepcopy(state.get(field)) for field in fields}

    def persist(self) -> None:
        with self.lock:
            payload = json.dumps(self._state(), indent=2, ensure_ascii=True)
            tmp_path = self.file_path.with_suffix(f"{self.file_path.suffix}.tmp")
            tmp_path.write_text(payload, encoding="utf-8")
            tmp_path.replace(self.file_path)

    def upsert_site(self, payload: dict, site_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            site = normalize_site_input(payload, site_id or payload.get("id"), now)
            sites = self._state()["sites"]
            index = find_index(sites, site["id"])

            if index >= 0:
                site["createdAt"] = sites[index].get("createdAt", now)
                sites[index] = {**sites[index], **site, "updatedAt": now}
                saved = sites[index]
            else:
                site["createdAt"] = now
                site["updatedAt"] = now
                sites.append(site)
                saved = site

            self.persist()
            return deepcopy(saved)

    def set_all_sites_under_attack(self, enabled: bool) -> dict:
        with self.lock:
            sites = self._state()["sites"]
            updated_count = 0
            now = utc_now()

            for site in sites:
                under_attack = normalize_under_attack_config(site.get("underAttack") or site.get("under_attack"))
                if under_attack["enabled"] == enabled:
                    continue
                site["underAttack"] = {**under_attack, "enabled": enabled}
                site["updatedAt"] = now
                updated_count += 1

            if updated_count:
                self.persist()

            return {
                "enabled": enabled,
                "updatedCount": updated_count,
                "sites": deepcopy(sites),
            }

    def delete_site(self, site_id: str) -> None:
        with self.lock:
            before = len(self._state()["sites"])
            self._state()["sites"] = [site for site in self._state()["sites"] if site["id"] != site_id]
            if len(self._state()["sites"]) == before:
                raise StoreError(404, "Site not found")
            self.persist()

    def upsert_rule(self, payload: dict, rule_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            rules = self._state()["rules"]
            existing = next((rule for rule in rules if rule["id"] == (rule_id or payload.get("id"))), None)
            rule = normalize_rule_input(payload, rule_id or payload.get("id"), now, existing)
            index = find_index(rules, rule["id"])

            if index >= 0:
                rule["createdAt"] = rules[index].get("createdAt", now)
                rules[index] = {**rules[index], **rule, "updatedAt": now}
                saved = rules[index]
            else:
                rule["createdAt"] = now
                rule["updatedAt"] = now
                rules.append(rule)
                saved = rule

            self.persist()
            return deepcopy(saved)

    def delete_rule(self, rule_id: str) -> None:
        with self.lock:
            rule = next((item for item in self._state()["rules"] if item["id"] == rule_id), None)
            if not rule:
                raise StoreError(404, "Rule not found")
            if rule.get("builtin"):
                raise StoreError(400, "Built-in rules can be disabled but not deleted")

            self._state()["rules"] = [item for item in self._state()["rules"] if item["id"] != rule_id]
            self.persist()

    def upsert_certificate(self, payload: dict, certificate_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            certificate = normalize_certificate_input(payload, certificate_id or payload.get("id"), now)
            certificates = self._state()["certificates"]
            index = find_index(certificates, certificate["id"])

            if index >= 0:
                certificate["createdAt"] = certificates[index].get("createdAt", now)
                certificates[index] = {**certificates[index], **certificate, "updatedAt": now}
                saved = certificates[index]
            else:
                certificate["createdAt"] = now
                certificate["updatedAt"] = now
                certificates.append(certificate)
                saved = certificate

            self.persist()
            return deepcopy(saved)

    def delete_certificate(self, certificate_id: str) -> None:
        with self.lock:
            before = len(self._state()["certificates"])
            self._state()["certificates"] = [
                certificate for certificate in self._state()["certificates"] if certificate["id"] != certificate_id
            ]
            if len(self._state()["certificates"]) == before:
                raise StoreError(404, "Certificate not found")

            for site in self._state()["sites"]:
                tls = site.get("tls") or {}
                if tls.get("certificateId") == certificate_id:
                    tls["certificateId"] = ""
                    tls["enabled"] = False
                    site["tls"] = tls

            panel = (self._state().get("settings") or {}).get("panel") or {}
            if panel.get("certificateId") == certificate_id:
                panel["certificateId"] = ""
                panel["httpsEnabled"] = False
                self._state()["settings"]["panel"] = panel

            self.persist()

    def upsert_ip_group(self, payload: dict, group_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            target_id = group_id or payload.get("id")
            groups = self._state()["ipGroups"]
            index = find_index(groups, target_id) if target_id else -1
            existing = groups[index] if index >= 0 else None
            if existing and existing.get("managed"):
                provider = managed_verified_bot_providers().get(str(existing.get("provider") or ""))
                if provider:
                    payload = {
                        **payload,
                        "name": provider["name"],
                        "description": provider["description"],
                        "referenceUrl": provider.get("referenceUrl", ""),
                        "managed": True,
                        "provider": existing.get("provider"),
                        "enabled": True,
                    }
                    if provider.get("items"):
                        payload["items"] = list(provider["items"])
            has_items = "items" in payload or "content" in payload
            group = normalize_ip_group_input(payload, target_id, now)
            if existing and not has_items:
                group = {**group, **preserve_ip_group_storage(existing)}
            else:
                group = self.prepare_ip_group_storage(group)
            groups = self._state()["ipGroups"]
            index = find_index(groups, group["id"])

            if index >= 0:
                group["createdAt"] = groups[index].get("createdAt", now)
                groups[index] = {**groups[index], **group, "updatedAt": now}
                saved = groups[index]
            else:
                group["createdAt"] = now
                group["updatedAt"] = now
                groups.append(group)
                saved = group

            self.persist()
            return deepcopy(saved)

    def delete_ip_group(self, group_id: str) -> None:
        with self.lock:
            existing = next((group for group in self._state()["ipGroups"] if group["id"] == group_id), None)
            if existing and existing.get("managed"):
                raise StoreError(400, "Managed IP groups cannot be deleted")
            before = len(self._state()["ipGroups"])
            self._state()["ipGroups"] = [group for group in self._state()["ipGroups"] if group["id"] != group_id]
            if len(self._state()["ipGroups"]) == before:
                raise StoreError(404, "IP group not found")
            if existing:
                self.remove_ip_group_file(existing)

            for rule in self._state()["accessRules"]:
                rule["ipGroupIds"] = [item for item in rule.get("ipGroupIds", []) if item != group_id]

            self.persist()

    def append_ip_group_items(self, group_id: str, items: list[str]) -> dict:
        with self.lock:
            group = next((item for item in self._state()["ipGroups"] if item["id"] == group_id), None)
            if not group:
                raise StoreError(404, "IP group not found")
            if group.get("managed"):
                raise StoreError(400, "Managed IP groups cannot be modified")
            current_items = list(group.get("items") or [])
            item_file = str(group.get("itemsFile") or "").strip()
            if item_file:
                path = Path(item_file)
                if path.exists() and path.is_file():
                    current_items.extend(line.strip() for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip())
            merged = normalize_ip_items([*current_items, *(items or [])])
            current_items = normalize_ip_items(current_items)
            if merged == current_items:
                return deepcopy(group)
            group["items"] = merged
            group["updatedAt"] = utc_now()
            prepared = self.prepare_ip_group_storage(group)
            group.clear()
            group.update(prepared)
            self.persist()
            return deepcopy(group)

    def upsert_access_rule(self, payload: dict, access_rule_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            rule = normalize_access_rule_input(payload, access_rule_id or payload.get("id"), now)
            rules = self._state()["accessRules"]
            index = find_index(rules, rule["id"])
            should_move = bool(payload.get("_moveAccessRule"))
            position = normalize_insert_position(payload.get("insertPosition"))

            if index >= 0:
                existing = rules.pop(index)
                rule["createdAt"] = existing.get("createdAt", now)
                saved = {**existing, **rule, "updatedAt": now}
                if should_move and position == "first":
                    rules.insert(0, saved)
                elif should_move and position == "last":
                    rules.append(saved)
                else:
                    rules.insert(index, saved)
            else:
                rule["createdAt"] = now
                rule["updatedAt"] = now
                saved = rule
                if position == "first":
                    rules.insert(0, saved)
                else:
                    rules.append(saved)

            self.persist()
            return deepcopy(saved)

    def delete_access_rule(self, access_rule_id: str) -> None:
        with self.lock:
            before = len(self._state()["accessRules"])
            self._state()["accessRules"] = [rule for rule in self._state()["accessRules"] if rule["id"] != access_rule_id]
            if len(self._state()["accessRules"]) == before:
                raise StoreError(404, "Access rule not found")
            self.persist()

    def set_blocked_ips(self, ips: list[str]) -> None:
        with self.lock:
            self._state()["blockedIps"] = list(dict.fromkeys(str(ip).strip() for ip in ips if str(ip).strip()))
            self.persist()

    def update_settings(self, payload: dict) -> dict:
        with self.lock:
            current = deepcopy(self._state()["settings"])
            incoming = payload or {}
            for key, value in incoming.items():
                if key == "applicationDefaults" and isinstance(value, dict):
                    current_defaults = current.get(key) if isinstance(current.get(key), dict) else {}
                    merged_defaults = {**current_defaults}
                    for group_key, group_value in value.items():
                        if isinstance(group_value, dict) and isinstance(merged_defaults.get(group_key), dict):
                            merged_defaults[group_key] = {**merged_defaults[group_key], **group_value}
                        else:
                            merged_defaults[group_key] = group_value
                    current[key] = merged_defaults
                elif key in {"panel", "rateLimit", "challengePage", "clientIp"} and isinstance(value, dict):
                    current[key] = {**(current.get(key) or {}), **value}
                else:
                    current[key] = value
            settings = normalize_settings(current)
            self._state()["settings"] = settings
            self.persist()
            return deepcopy(settings)

    def has_users(self) -> bool:
        with self.lock:
            return bool(self._state().get("users"))

    def upsert_user(self, payload: dict, user_id: str | None = None) -> dict:
        with self.lock:
            now = utc_now()
            users = self._state()["users"]
            existing = next((user for user in users if user["id"] == (user_id or payload.get("id"))), None)
            user = normalize_user_input(payload, user_id or payload.get("id"), now, existing)
            totp_secret_generated = bool(user.pop("_totpSecretGenerated", False))
            if any(item["id"] != user["id"] and item["username"].lower() == user["username"].lower() for item in users):
                raise StoreError(400, "Username already exists")

            index = find_index(users, user["id"])
            candidate_users = deepcopy(users)
            if index >= 0:
                user["createdAt"] = candidate_users[index].get("createdAt", now)
                saved = {**candidate_users[index], **user, "updatedAt": now}
                candidate_users[index] = saved
            else:
                user["createdAt"] = now
                user["updatedAt"] = now
                saved = user
                candidate_users.append(saved)

            self.ensure_admin_user(candidate_users)
            self._state()["users"] = candidate_users
            self.persist()
            result = deepcopy(saved)
            if totp_secret_generated:
                result["_totpSecretGenerated"] = True
            return result

    def delete_user(self, user_id: str) -> None:
        with self.lock:
            user = next((item for item in self._state()["users"] if item["id"] == user_id), None)
            if not user:
                raise StoreError(404, "User not found")
            remaining = [item for item in self._state()["users"] if item["id"] != user_id]
            if not any(item.get("enabled") and item.get("role") == "admin" for item in remaining):
                raise StoreError(400, "Cannot delete the last enabled admin user")
            self._state()["users"] = remaining
            self.persist()

    def change_user_password(self, user_id: str, password: str) -> dict:
        with self.lock:
            user = next((item for item in self._state()["users"] if item["id"] == user_id), None)
            if not user:
                raise StoreError(404, "User not found")
            password_fields = hash_password(validate_password(password))
            user.update(password_fields)
            user["updatedAt"] = utc_now()
            self.persist()
            return deepcopy(user)

    def authenticate_user(self, username: str, password: str, totp_code: str = "") -> dict:
        with self.lock:
            user = next((item for item in self._state()["users"] if item["username"].lower() == str(username or "").lower()), None)
            if not user or not user.get("enabled"):
                raise StoreError(401, "Invalid username or password")
            if not verify_password(password, user):
                raise StoreError(401, "Invalid username or password")
            if user.get("totpEnabled"):
                if not verify_totp(user.get("totpSecret", ""), totp_code):
                    raise StoreError(401, "Google Authenticator code is required")
            user["lastLoginAt"] = utc_now()
            self.persist()
            return deepcopy(user)

    def ensure_admin_user(self, users: list[dict] | None = None) -> None:
        source = users if users is not None else self._state().get("users", [])
        if not any(user.get("enabled") and user.get("role") == "admin" for user in source):
            raise StoreError(400, "At least one enabled admin user is required")

    def add_log(self, entry: dict) -> None:
        with self.lock:
            retention = int(self._state()["settings"].get("logRetention") or DEFAULT_SETTINGS["logRetention"])
            self._state()["logs"].insert(0, entry)
            del self._state()["logs"][retention:]
            self.persist()

    def get_logs(self, limit: int = 200) -> list[dict]:
        with self.lock:
            return deepcopy(self._state()["logs"][:limit])

    def clear_logs(self) -> None:
        with self.lock:
            self._state()["logs"] = []
            self.persist()

    def get_stats(self) -> dict:
        with self.lock:
            return build_stats(self._state())

    def _state(self) -> dict:
        if self.state is None:
            raise RuntimeError("Store.init() must be called before use")
        return self.state

    def prepare_ip_group_storage(self, group: dict) -> dict:
        items = normalize_ip_items(group.get("items"))
        if not items and group.get("itemsFile"):
            return {
                **group,
                "items": [],
                "itemsExternal": True,
                "itemCount": normalize_non_negative_int(group.get("itemCount"), len(group.get("itemsPreview") or [])),
                "itemsPreview": normalize_ip_items(group.get("itemsPreview"))[:8],
            }

        if should_externalize_ip_group(items, group):
            path = self.ip_group_items_file(group["id"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("\n".join(items) + ("\n" if items else ""), encoding="utf-8")
            return {
                **group,
                "items": [],
                "itemsFile": str(path).replace("\\", "/"),
                "itemsExternal": True,
                "itemCount": len(items),
                "itemsPreview": items[:8],
            }

        self.remove_ip_group_file(group)
        return {
            **group,
            "items": items,
            "itemsFile": "",
            "itemsExternal": False,
            "itemCount": len(items),
            "itemsPreview": items[:8],
        }

    def ip_group_items_file(self, group_id: str) -> Path:
        safe_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(group_id or "ipgroup")).strip("._") or "ipgroup"
        return self.file_path.parent / "ip-groups" / f"{safe_id}.txt"

    def remove_ip_group_file(self, group: dict) -> None:
        path = ip_group_file_path(group)
        if not path:
            return
        try:
            if path.exists() and is_relative_to(path.resolve(), (self.file_path.parent / "ip-groups").resolve()):
                path.unlink()
        except OSError:
            return


def resolve_data_file(root_dir: Path) -> Path:
    configured = Path(os.environ.get("DATA_FILE", "./data/state.json"))
    return configured if configured.is_absolute() else root_dir / configured


def normalize_state(state: dict) -> dict:
    settings = normalize_settings(state.get("settings") or {})
    return {
        "version": 1,
        "settings": settings,
        "sites": [normalize_stored_site(site) for site in state.get("sites", [])],
        "rules": [normalize_stored_rule(rule) for rule in state.get("rules", [])],
        "certificates": [normalize_stored_certificate(certificate) for certificate in state.get("certificates", [])],
        "ipGroups": [normalize_stored_ip_group(group) for group in state.get("ipGroups", [])],
        "accessRules": [normalize_stored_access_rule(rule) for rule in state.get("accessRules", [])],
        "blockedIps": [str(ip).strip() for ip in state.get("blockedIps", []) if str(ip).strip()] if isinstance(state.get("blockedIps"), list) else [],
        "users": [normalize_stored_user(user) for user in state.get("users", [])],
        "logs": state.get("logs", []) if isinstance(state.get("logs"), list) else [],
    }


def normalize_settings(settings: dict) -> dict:
    source = settings if isinstance(settings, dict) else {}
    return {
        **deepcopy(DEFAULT_SETTINGS),
        **source,
        "panel": normalize_panel_settings(source.get("panel") or {}),
        "rateLimit": {
            **DEFAULT_SETTINGS["rateLimit"],
            **(source.get("rateLimit") or {}),
        },
        "applicationDefaults": normalize_application_defaults(source.get("applicationDefaults") or source.get("application_defaults") or {}),
        "challengePage": normalize_challenge_page_settings(source.get("challengePage") or source.get("challenge_page") or {}),
        "clientIp": normalize_client_ip_settings(source.get("clientIp") or source.get("client_ip") or {}),
    }


def normalize_client_ip_settings(value) -> dict:
    source = value if isinstance(value, dict) else {}
    defaults = DEFAULT_SETTINGS["clientIp"]
    raw_source = re.sub(r"[\s-]+", "_", str(source.get("source") or defaults["source"]).strip().lower())
    client_source = CLIENT_IP_SOURCE_ALIASES.get(raw_source, raw_source)
    if client_source not in CLIENT_IP_SOURCES:
        client_source = defaults["source"]
    header_name = str(source.get("headerName") or source.get("header_name") or defaults["headerName"]).strip()
    if not HTTP_HEADER_NAME_RE.match(header_name):
        header_name = defaults["headerName"]
    return {
        "source": client_source,
        "headerName": header_name,
    }


def normalize_panel_settings(value) -> dict:
    source = value if isinstance(value, dict) else {}
    session_hours = normalize_positive_int(source.get("sessionHours") or source.get("session_hours"), DEFAULT_SETTINGS["panel"]["sessionHours"])
    return {
        "httpsEnabled": normalize_bool(source.get("httpsEnabled") if "httpsEnabled" in source else source.get("https_enabled"), False),
        "certificateId": str(source.get("certificateId") or source.get("certificate_id") or ""),
        "publicUrl": normalize_panel_url(source.get("publicUrl") or source.get("public_url") or ""),
        "faviconUrl": normalize_optional_https_url(source.get("faviconUrl") or source.get("favicon_url") or ""),
        "logoUrl": normalize_optional_https_url(source.get("logoUrl") or source.get("logo_url") or ""),
        "sessionHours": min(max(session_hours, 1), 168),
    }


def normalize_application_defaults(value) -> dict:
    source = value if isinstance(value, dict) else {}
    proxy = source.get("proxy") if isinstance(source.get("proxy"), dict) else {}
    modsecurity = source.get("modSecurity") or source.get("modsecurity")
    modsecurity = modsecurity if isinstance(modsecurity, dict) else {}
    proxy_defaults = DEFAULT_SETTINGS["applicationDefaults"]["proxy"]
    modsecurity_defaults = DEFAULT_SETTINGS["applicationDefaults"]["modSecurity"]
    return {
        "proxy": {
            "forceHttps": normalize_bool(proxy.get("forceHttps") if "forceHttps" in proxy else proxy.get("force_https"), proxy_defaults["forceHttps"]),
            "hsts": normalize_bool(proxy.get("hsts"), proxy_defaults["hsts"]),
            "hstsMaxAge": normalize_positive_int(proxy.get("hstsMaxAge") or proxy.get("hsts_max_age"), proxy_defaults["hstsMaxAge"]),
            "gzip": normalize_bool(proxy.get("gzip"), proxy_defaults["gzip"]),
            "brotli": normalize_bool(proxy.get("brotli"), proxy_defaults["brotli"]),
            "http2": normalize_bool(proxy.get("http2"), proxy_defaults["http2"]),
            "resetXff": normalize_bool(proxy.get("resetXff") if "resetXff" in proxy else proxy.get("reset_xff"), proxy_defaults["resetXff"]),
            "modifyHostHeader": normalize_bool(
                proxy.get("modifyHostHeader") if "modifyHostHeader" in proxy else proxy.get("modify_host_header"),
                proxy_defaults["modifyHostHeader"],
            ),
            "forwardedHeaders": normalize_bool(
                proxy.get("forwardedHeaders") if "forwardedHeaders" in proxy else proxy.get("forwarded_headers"),
                proxy_defaults["forwardedHeaders"],
            ),
            "hostHeader": normalize_proxy_header(proxy.get("hostHeader") or proxy.get("host_header") or proxy_defaults["hostHeader"]),
            "xForwardedProto": normalize_proxy_header(proxy.get("xForwardedProto") or proxy.get("xfp") or proxy_defaults["xForwardedProto"]),
            "xForwardedHost": normalize_proxy_header(proxy.get("xForwardedHost") or proxy.get("xfh") or proxy_defaults["xForwardedHost"]),
            "proxySslServerName": normalize_bool(
                proxy.get("proxySslServerName") if "proxySslServerName" in proxy else proxy.get("proxy_ssl_server_name"),
                proxy_defaults["proxySslServerName"],
            ),
        },
        "modSecurity": {
            "enabled": normalize_bool(modsecurity.get("enabled"), modsecurity_defaults["enabled"]),
            "mode": str(modsecurity.get("mode") or modsecurity_defaults["mode"]).lower()
            if str(modsecurity.get("mode") or modsecurity_defaults["mode"]).lower() in MODSECURITY_MODES
            else modsecurity_defaults["mode"],
            "ruleset": str(modsecurity.get("ruleset") or modsecurity_defaults["ruleset"]).lower()
            if str(modsecurity.get("ruleset") or modsecurity_defaults["ruleset"]).lower() in MODSECURITY_RULESETS
            else modsecurity_defaults["ruleset"],
            "requestBodyLimit": min(
                max(normalize_positive_int(modsecurity.get("requestBodyLimit") or modsecurity.get("request_body_limit"), modsecurity_defaults["requestBodyLimit"]), 131072),
                1073741824,
            ),
        },
    }


def normalize_challenge_page_settings(value) -> dict:
    source = value if isinstance(value, dict) else {}
    defaults = DEFAULT_SETTINGS["challengePage"]
    return {
        "brandName": normalize_display_text(source.get("brandName") or source.get("brand_name"), defaults["brandName"], 80),
        "title": normalize_display_text(source.get("title"), defaults["title"], 120),
        "message": normalize_display_text(source.get("message"), defaults["message"], 500),
        "logoUrl": normalize_optional_http_url(source.get("logoUrl") or source.get("logo_url")),
        "supportUrl": normalize_optional_http_url(source.get("supportUrl") or source.get("support_url")),
        "primaryColor": normalize_hex_color(source.get("primaryColor") or source.get("primary_color"), defaults["primaryColor"]),
        "backgroundColor": normalize_hex_color(source.get("backgroundColor") or source.get("background_color"), defaults["backgroundColor"]),
        "textColor": normalize_hex_color(source.get("textColor") or source.get("text_color"), defaults["textColor"]),
        "tokenTtlMinutes": min(
            max(normalize_positive_int(source.get("tokenTtlMinutes") or source.get("token_ttl_minutes"), defaults["tokenTtlMinutes"]), 1),
            1440,
        ),
        "waitSeconds": normalize_challenge_wait_seconds(source.get("waitSeconds") or source.get("wait_seconds"), defaults["waitSeconds"]),
        "powDifficulty": normalize_pow_difficulty(source.get("powDifficulty") or source.get("pow_difficulty"), defaults.get("powDifficulty", 16)),
    }


def normalize_pow_difficulty(value, default: int = 16) -> int:
    bits = normalize_positive_int(value, default)
    if bits < 0:
        return 0
    return min(bits, 24)


def normalize_challenge_wait_seconds(value, default: int = 5) -> int:
    seconds = normalize_positive_int(value, default)
    return seconds if seconds in {3, 5, 10} else default


def normalize_stored_site(site: dict) -> dict:
    now = utc_now()
    tls = normalize_tls(site.get("tls"))
    application_type = normalize_application_type(site.get("applicationType") or site.get("application_type"))
    upstreams = normalize_upstreams(
        site.get("upstreams") or site.get("origin") or ("http://127.0.0.1:9090" if application_type == "reverse_proxy" else ""),
        required=application_type == "reverse_proxy",
    )
    listen = normalize_listen(site.get("listen") or infer_listen_from_ports(site.get("ports"), tls))
    ports = normalize_ports(site.get("ports"), listen, tls)
    proxy = normalize_proxy_config(site.get("proxy"), tls, site.get("redirectStatusCode") or site.get("redirect_status_code"))
    enabled_value = site.get("enabled") if "enabled" in site else site.get("is_enabled")
    redirect = normalize_redirect_config(site.get("redirect"), proxy)
    features = normalize_site_features(site.get("features"))
    bot_protection = normalize_bot_protection_config(site.get("botProtection") or site.get("bot_protection"), features.get("botProtection"))
    geo_block = normalize_geo_block_config(site.get("geoBlock") or site.get("geo_block"), features.get("geoBlock"))
    under_attack = normalize_under_attack_config(site.get("underAttack") or site.get("under_attack"))
    mode = site.get("mode") if site.get("mode") in MODES else "block"
    modsecurity = normalize_modsecurity_config(site.get("modSecurity") or site.get("modsecurity"), mode)
    features["botProtection"] = bot_protection["enabled"]
    features["geoBlock"] = geo_block["enabled"]
    return {
        "id": str(site.get("id") or create_id("site")),
        "name": str(site.get("name") or site.get("comment") or "Untitled site"),
        "hostnames": normalize_hostnames(site.get("hostnames") or site.get("server_names") or ["*"]),
        "applicationType": application_type,
        "origin": upstreams[0] if upstreams else "",
        "upstreams": upstreams,
        "ports": ports,
        "listen": listen,
        "redirectStatusCode": proxy["redirectStatusCode"],
        "tls": tls,
        "proxy": proxy,
        "redirect": redirect,
        "static": normalize_static_config(site.get("static")),
        "acl": normalize_acl_config(site.get("acl"), site.get("acl_enabled")),
        "features": features,
        "botProtection": bot_protection,
        "geoBlock": geo_block,
        "underAttack": under_attack,
        "modSecurity": modsecurity,
        "mode": mode,
        "enabled": normalize_bool(enabled_value, False),
        "createdAt": site.get("createdAt") or now,
        "updatedAt": site.get("updatedAt") or now,
    }


def normalize_stored_rule(rule: dict) -> dict:
    now = utc_now()
    return {
        "id": str(rule.get("id") or create_id("rule")),
        "name": str(rule.get("name") or "Untitled rule"),
        "description": str(rule.get("description") or ""),
        "builtin": bool(rule.get("builtin")),
        "enabled": bool(rule.get("enabled")),
        "siteId": str(rule.get("siteId") or "*"),
        "matcher": rule.get("matcher") if rule.get("matcher") in MATCHERS else "regex",
        "target": rule.get("target") if rule.get("target") in TARGETS else "all",
        "pattern": str(rule.get("pattern") or ""),
        "action": rule.get("action") if rule.get("action") in ACTIONS else "block",
        "severity": rule.get("severity") if rule.get("severity") in SEVERITIES else "medium",
        "createdAt": rule.get("createdAt") or now,
        "updatedAt": rule.get("updatedAt") or now,
    }


def normalize_stored_certificate(certificate: dict) -> dict:
    now = utc_now()
    source = normalize_certificate_source(certificate.get("source"))
    last_message = str(certificate.get("lastMessage") or "")
    cert_file = normalize_file_reference(certificate.get("certFile") or certificate.get("cert_file") or "")
    key_file = normalize_file_reference(certificate.get("keyFile") or certificate.get("key_file") or "")
    if source in {"certbot", "cloudflare"}:
        parsed_cert_file, parsed_key_file = parse_certbot_paths(last_message)
        cert_file = parsed_cert_file or cert_file
        key_file = parsed_key_file or key_file

    return {
        "id": str(certificate.get("id") or create_id("cert")),
        "name": str(certificate.get("name") or "Untitled certificate"),
        "source": source,
        "domains": normalize_domain_list(certificate.get("domains")),
        "email": str(certificate.get("email") or ""),
        "autoRenew": certificate.get("autoRenew") is not False,
        "renewBeforeDays": normalize_positive_int(certificate.get("renewBeforeDays"), 30),
        "status": str(certificate.get("status") or "ready"),
        "lastMessage": last_message,
        "certFile": cert_file,
        "keyFile": key_file,
        "cloudflareCredentialsFile": normalize_file_reference(certificate.get("cloudflareCredentialsFile") or certificate.get("cloudflare_credentials_file") or ""),
        "cloudflarePropagationSeconds": normalize_positive_int(certificate.get("cloudflarePropagationSeconds") or certificate.get("cloudflare_propagation_seconds"), 60),
        "createdAt": certificate.get("createdAt") or now,
        "updatedAt": certificate.get("updatedAt") or now,
    }


def parse_certbot_paths(message: str) -> tuple[str, str]:
    cert_match = re.search(r"Certificate is saved at:\s*(\S+)", message or "")
    key_match = re.search(r"Key is saved at:\s*(\S+)", message or "")
    return (
        normalize_file_reference(cert_match.group(1)) if cert_match else "",
        normalize_file_reference(key_match.group(1)) if key_match else "",
    )


def normalize_stored_ip_group(group: dict) -> dict:
    now = utc_now()
    items = normalize_ip_items(group.get("items"))
    items_preview = normalize_ip_items(group.get("itemsPreview") or group.get("items_preview") or items[:8])[:8]
    item_count = normalize_non_negative_int(group.get("itemCount") or group.get("item_count"), len(items))
    items_file = normalize_file_reference(group.get("itemsFile") or group.get("items_file") or "")
    items_external = bool(items_file) or group.get("itemsExternal") is True
    return {
        "id": str(group.get("id") or create_id("ipgroup")),
        "name": str(group.get("name") or "Untitled IP group"),
        "description": str(group.get("description") or ""),
        "referenceUrl": normalize_reference_url(group.get("referenceUrl") or group.get("reference") or "", strict=False),
        "items": [] if items_external else items,
        "itemsFile": items_file,
        "itemsExternal": items_external,
        "itemCount": item_count if items_external else len(items),
        "itemsPreview": items_preview,
        "lastSyncedAt": str(group.get("lastSyncedAt") or ""),
        "lastSyncStatus": str(group.get("lastSyncStatus") or ""),
        "lastSyncMessage": str(group.get("lastSyncMessage") or ""),
        "enabled": group.get("enabled") is not False,
        "managed": bool(group.get("managed")),
        "provider": str(group.get("provider") or ""),
        "createdAt": group.get("createdAt") or now,
        "updatedAt": group.get("updatedAt") or now,
    }


def normalize_stored_access_rule(rule: dict) -> dict:
    now = utc_now()
    return {
        "id": str(rule.get("id") or create_id("access")),
        "name": str(rule.get("name") or "Untitled access rule"),
        "description": str(rule.get("description") or ""),
        "enabled": rule.get("enabled") is not False,
        "siteId": str(rule.get("siteId") or "*"),
        "action": normalize_access_action(rule.get("action")),
        "insertPosition": normalize_insert_position(rule.get("insertPosition")),
        "continueDetect": normalize_bool(rule.get("continueDetect"), False),
        "ipGroupIds": normalize_id_list(rule.get("ipGroupIds")),
        "ips": normalize_ip_items(rule.get("ips")),
        "methods": normalize_string_list(rule.get("methods"), uppercase=True),
        "uriPatterns": normalize_string_list(rule.get("uriPatterns")),
        "hostPatterns": normalize_string_list(rule.get("hostPatterns")),
        "userAgentPatterns": normalize_string_list(rule.get("userAgentPatterns")),
        "conditionGroups": normalize_access_condition_groups(rule.get("conditionGroups") or rule.get("condition_groups")),
        "createdAt": rule.get("createdAt") or now,
        "updatedAt": rule.get("updatedAt") or now,
    }


def normalize_stored_user(user: dict) -> dict:
    now = utc_now()
    username = normalize_username(user.get("username") or "admin")
    return {
        "id": str(user.get("id") or create_id("user")),
        "username": username,
        "displayName": str(user.get("displayName") or user.get("display_name") or username),
        "role": normalize_user_role(user.get("role")),
        "enabled": user.get("enabled") is not False,
        "passwordSalt": str(user.get("passwordSalt") or user.get("password_salt") or ""),
        "passwordHash": str(user.get("passwordHash") or user.get("password_hash") or ""),
        "passwordIterations": normalize_positive_int(user.get("passwordIterations") or user.get("password_iterations"), PASSWORD_ITERATIONS),
        "totpEnabled": normalize_bool(user.get("totpEnabled") if "totpEnabled" in user else user.get("totp_enabled"), False),
        "totpSecret": normalize_totp_secret(user.get("totpSecret") or user.get("totp_secret") or ""),
        "lastLoginAt": str(user.get("lastLoginAt") or user.get("last_login_at") or ""),
        "createdAt": user.get("createdAt") or now,
        "updatedAt": user.get("updatedAt") or now,
    }


def normalize_site_input(payload: dict, site_id: str | None, now: str) -> dict:
    name = str(payload.get("name") or "").strip()
    if not name:
        raise StoreError(400, "Site name is required")

    tls = normalize_tls(payload.get("tls"))
    application_type = normalize_application_type(payload.get("applicationType") or payload.get("application_type"))
    upstreams = normalize_upstreams(
        payload.get("upstreams") or payload.get("origin"),
        required=application_type == "reverse_proxy",
    )
    listen = normalize_listen(payload.get("listen") or infer_listen_from_ports(payload.get("ports"), tls))
    ports = normalize_ports(payload.get("ports"), listen, tls)
    proxy = normalize_proxy_config(payload.get("proxy"), tls, payload.get("redirectStatusCode"))
    redirect = normalize_redirect_config(payload.get("redirect"), proxy, required=application_type == "redirect")

    features = normalize_site_features(payload.get("features"))
    bot_protection = normalize_bot_protection_config(payload.get("botProtection") or payload.get("bot_protection"), features.get("botProtection"))
    geo_block = normalize_geo_block_config(payload.get("geoBlock") or payload.get("geo_block"), features.get("geoBlock"))
    under_attack = normalize_under_attack_config(payload.get("underAttack") or payload.get("under_attack"))
    mode = payload.get("mode") if payload.get("mode") in MODES else "block"
    modsecurity = normalize_modsecurity_config(payload.get("modSecurity") or payload.get("modsecurity"), mode)
    features["botProtection"] = bot_protection["enabled"]
    features["geoBlock"] = geo_block["enabled"]
    return {
        "id": site_id or create_id("site"),
        "name": name,
        "hostnames": normalize_hostnames(payload.get("hostnames")),
        "applicationType": application_type,
        "origin": upstreams[0] if upstreams else "",
        "upstreams": upstreams,
        "ports": ports,
        "listen": listen,
        "redirectStatusCode": proxy["redirectStatusCode"],
        "tls": tls,
        "proxy": proxy,
        "redirect": redirect,
        "static": normalize_static_config(payload.get("static")),
        "acl": normalize_acl_config(payload.get("acl")),
        "features": features,
        "botProtection": bot_protection,
        "geoBlock": geo_block,
        "underAttack": under_attack,
        "modSecurity": modsecurity,
        "mode": mode,
        "enabled": payload.get("enabled") is not False,
        "createdAt": now,
        "updatedAt": now,
    }


def normalize_certificate_input(payload: dict, certificate_id: str | None, now: str) -> dict:
    name = str(payload.get("name") or "").strip()
    source = normalize_certificate_source(payload.get("source"))
    cert_file = normalize_file_reference(payload.get("certFile") or payload.get("cert_file") or "")
    key_file = normalize_file_reference(payload.get("keyFile") or payload.get("key_file") or "")
    domains = normalize_domain_list(payload.get("domains"))
    email = str(payload.get("email") or "").strip()

    if not name:
        raise StoreError(400, "Certificate name is required")
    if not cert_file or not key_file:
        raise StoreError(400, "Certificate and key files are required")
    if source in {"certbot", "cloudflare"}:
        if not domains:
            raise StoreError(400, "At least one domain is required for certbot certificates")
        if "@" not in email:
            raise StoreError(400, "A valid email address is required for certbot certificates")

    return {
        "id": certificate_id or create_id("cert"),
        "name": name,
        "source": source,
        "domains": domains,
        "email": email,
        "autoRenew": payload.get("autoRenew") is not False,
        "renewBeforeDays": normalize_positive_int(payload.get("renewBeforeDays"), 30),
        "status": str(payload.get("status") or "ready"),
        "lastMessage": str(payload.get("lastMessage") or ""),
        "certFile": cert_file,
        "keyFile": key_file,
        "cloudflareCredentialsFile": normalize_file_reference(payload.get("cloudflareCredentialsFile") or payload.get("cloudflare_credentials_file") or ""),
        "cloudflarePropagationSeconds": normalize_positive_int(payload.get("cloudflarePropagationSeconds") or payload.get("cloudflare_propagation_seconds"), 60),
        "createdAt": now,
        "updatedAt": now,
    }


def normalize_ip_group_input(payload: dict, group_id: str | None, now: str) -> dict:
    name = str(payload.get("name") or "").strip()
    if not name:
        raise StoreError(400, "IP group name is required")
    items = payload.get("items")
    if items is None and "content" in payload:
        items = payload.get("content")

    return {
        "id": group_id or create_id("ipgroup"),
        "name": name,
        "description": str(payload.get("description") or ""),
        "referenceUrl": normalize_reference_url(payload.get("referenceUrl") or payload.get("reference") or ""),
        "items": normalize_ip_items(items),
        "lastSyncedAt": str(payload.get("lastSyncedAt") or ""),
        "lastSyncStatus": str(payload.get("lastSyncStatus") or ""),
        "lastSyncMessage": str(payload.get("lastSyncMessage") or ""),
        "enabled": payload.get("enabled") is not False,
        "managed": bool(payload.get("managed")),
        "provider": str(payload.get("provider") or ""),
        "createdAt": now,
        "updatedAt": now,
    }


def normalize_access_rule_input(payload: dict, rule_id: str | None, now: str) -> dict:
    name = str(payload.get("name") or "").strip()
    if not name:
        raise StoreError(400, "Access rule name is required")

    rule = {
        "id": rule_id or create_id("access"),
        "name": name,
        "description": str(payload.get("description") or ""),
        "enabled": payload.get("enabled") is not False,
        "siteId": str(payload.get("siteId") or "*"),
        "action": normalize_access_action(payload.get("action")),
        "insertPosition": normalize_insert_position(payload.get("insertPosition")),
        "continueDetect": normalize_bool(payload.get("continueDetect"), False),
        "ipGroupIds": normalize_id_list(payload.get("ipGroupIds")),
        "ips": normalize_ip_items(payload.get("ips")),
        "methods": normalize_string_list(payload.get("methods"), uppercase=True),
        "uriPatterns": normalize_string_list(payload.get("uriPatterns")),
        "hostPatterns": normalize_string_list(payload.get("hostPatterns")),
        "userAgentPatterns": normalize_string_list(payload.get("userAgentPatterns")),
        "conditionGroups": normalize_access_condition_groups(payload.get("conditionGroups") or payload.get("condition_groups")),
        "createdAt": now,
        "updatedAt": now,
    }

    if not any(
        [
            rule["ipGroupIds"],
            rule["ips"],
            rule["methods"],
            rule["uriPatterns"],
            rule["hostPatterns"],
            rule["userAgentPatterns"],
            rule["conditionGroups"],
        ]
    ):
        raise StoreError(400, "Access rule needs at least one condition")

    return rule


def normalize_user_input(payload: dict, user_id: str | None, now: str, existing: dict | None = None) -> dict:
    username = normalize_username(payload.get("username") or (existing or {}).get("username") or "")
    display_name = str(payload.get("displayName") or payload.get("display_name") or username).strip()
    role = normalize_user_role(payload.get("role") or (existing or {}).get("role"))
    enabled = normalize_bool(payload.get("enabled"), (existing or {}).get("enabled", True))

    user = {
        "id": user_id or create_id("user"),
        "username": username,
        "displayName": display_name or username,
        "role": role,
        "enabled": enabled,
        "passwordSalt": (existing or {}).get("passwordSalt", ""),
        "passwordHash": (existing or {}).get("passwordHash", ""),
        "passwordIterations": int((existing or {}).get("passwordIterations") or PASSWORD_ITERATIONS),
        "totpEnabled": normalize_bool(payload.get("totpEnabled"), (existing or {}).get("totpEnabled", False)),
        "totpSecret": (existing or {}).get("totpSecret", ""),
        "lastLoginAt": (existing or {}).get("lastLoginAt", ""),
        "createdAt": now,
        "updatedAt": now,
    }

    password = str(payload.get("password") or "")
    if password:
        user.update(hash_password(validate_password(password)))
    elif not existing:
        raise StoreError(400, "Password is required for new users")

    reset_totp = payload.get("resetTotp") is True or payload.get("reset_totp") is True
    if user["totpEnabled"] and (reset_totp or not user["totpSecret"]):
        user["totpSecret"] = generate_totp_secret()
        user["_totpSecretGenerated"] = True
    if not user["totpEnabled"]:
        user["totpSecret"] = ""

    return user


def normalize_rule_input(payload: dict, rule_id: str | None, now: str, existing: dict | None) -> dict:
    name = str(payload.get("name") or "").strip()
    matcher = payload.get("matcher") if payload.get("matcher") in MATCHERS else "regex"
    pattern = str(payload.get("pattern") or "").strip()

    if not name:
        raise StoreError(400, "Rule name is required")
    if not pattern:
        raise StoreError(400, "Rule pattern is required")
    if matcher == "regex":
        try:
            re.compile(pattern, re.IGNORECASE)
        except re.error:
            raise StoreError(400, "Rule regex pattern is invalid") from None

    return {
        "id": rule_id or create_id("rule"),
        "name": name,
        "description": str(payload.get("description") or ""),
        "builtin": bool((existing or {}).get("builtin") or payload.get("builtin")),
        "enabled": payload.get("enabled") is not False,
        "siteId": str(payload.get("siteId") or "*"),
        "matcher": matcher,
        "target": payload.get("target") if payload.get("target") in TARGETS else "all",
        "pattern": pattern,
        "action": payload.get("action") if payload.get("action") in ACTIONS else "block",
        "severity": payload.get("severity") if payload.get("severity") in SEVERITIES else "medium",
        "createdAt": now,
        "updatedAt": now,
    }


def normalize_hostnames(hostnames) -> list[str]:
    if isinstance(hostnames, list):
        values = hostnames
    else:
        values = re.split(r"[\s,]+", str(hostnames or ""))

    normalized = []
    for value in values:
        item = str(value).strip().lower()
        if not item:
            continue
        item = re.sub(r"^https?://", "", item).split("/")[0]
        if item.startswith("[") and "]" in item:
            item = item[1:].split("]")[0]
        else:
            item = item.split(":")[0]
        if item:
            normalized.append(item)

    return list(dict.fromkeys(normalized or ["*"]))


def normalize_origin(origin: str | None) -> str:
    parsed = urlparse(str(origin or "").strip())
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise StoreError(400, "Origin must be a valid http or https URL")
    return f"{parsed.scheme}://{parsed.netloc}"


def normalize_upstreams(upstreams, required: bool = True) -> list[str]:
    values = normalize_string_list(upstreams)
    normalized = [normalize_origin(value) for value in values]
    if required and not normalized:
        raise StoreError(400, "At least one upstream origin is required")
    return list(dict.fromkeys(normalized))


def normalize_application_type(value) -> str:
    item = str(value or "reverse_proxy").lower().replace("-", "_")
    if item in {"reverse", "proxy", "reverseproxy"}:
        item = "reverse_proxy"
    if item in {"static", "static_file", "staticfiles"}:
        item = "static_files"
    return item if item in APPLICATION_TYPES else "reverse_proxy"


def normalize_redirect_config(value, proxy: dict | None = None, required: bool = False) -> dict:
    source = value if isinstance(value, dict) else {}
    address = normalize_redirect_address(source.get("address") or source.get("url") or "", required=required)
    status_code = normalize_redirect_status(source.get("statusCode") or source.get("status_code") or (proxy or {}).get("redirectStatusCode") or 301)
    return {
        "statusCode": status_code,
        "address": address,
    }


def normalize_redirect_address(value, required: bool = False) -> str:
    raw = str(value or "").strip()
    if not raw:
        if required:
            raise StoreError(400, "Redirect address is required")
        return ""
    parsed = urlparse(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise StoreError(400, "Redirect address must be a valid http or https URL")
    return f"{parsed.scheme}://{parsed.netloc}"


def normalize_static_config(value) -> dict:
    source = value if isinstance(value, dict) else {}
    return {
        "root": normalize_file_reference(source.get("root") or source.get("path") or ""),
    }


def normalize_listen(value) -> int:
    try:
        listen = int(value or 8080)
    except (TypeError, ValueError):
        listen = 8080
    if listen < 1 or listen > 65535:
        raise StoreError(400, "Listen port must be between 1 and 65535")
    return listen


def normalize_tls(value) -> dict:
    source = value if isinstance(value, dict) else {}
    return {
        "enabled": normalize_bool(source.get("enabled"), False),
        "certificateId": str(source.get("certificateId") or ""),
        "redirectHttp": normalize_bool(source.get("redirectHttp"), False),
        "httpListen": normalize_listen(source.get("httpListen") or 80),
        "http2": normalize_bool(source.get("http2"), True),
    }


def infer_listen_from_ports(ports, tls: dict) -> int:
    preferred_ssl = normalize_bool(tls.get("enabled"), False)
    fallback = 443 if preferred_ssl else 8080
    values = normalize_string_list(ports)
    parsed_tokens = []
    for value in values:
        parsed = parse_port_token(value, strict=False)
        if parsed:
            parsed_tokens.append(parsed)
    for port, is_ssl in parsed_tokens:
        if is_ssl == preferred_ssl:
            return port
    return parsed_tokens[0][0] if parsed_tokens else fallback


def normalize_ports(ports, listen: int, tls: dict) -> list[str]:
    values = normalize_string_list(ports)
    if not values:
        if normalize_bool(tls.get("enabled"), False):
            if normalize_bool(tls.get("redirectHttp"), False):
                return [str(normalize_listen(tls.get("httpListen") or 80)), f"{listen}_ssl"]
            return [f"{listen}_ssl"]
        return [str(listen)]
    return list(dict.fromkeys(format_port_token(*parse_port_token(value)) for value in values))


def parse_port_token(value, strict: bool = True) -> tuple[int, bool] | None:
    item = str(value or "").strip().lower()
    if not item:
        return None
    is_ssl = item.endswith("_ssl")
    port_value = item[:-4] if is_ssl else item
    if not re.match(r"^\d+$", port_value):
        if strict:
            raise StoreError(400, f"Invalid port token: {value}")
        return None
    port = int(port_value)
    if port < 1 or port > 65535:
        if strict:
            raise StoreError(400, "Port must be between 1 and 65535")
        return None
    return port, is_ssl


def format_port_token(port: int, is_ssl: bool) -> str:
    return f"{port}_ssl" if is_ssl else str(port)


def normalize_proxy_config(value, tls: dict, redirect_status_code=None) -> dict:
    source = value if isinstance(value, dict) else {}
    force_https = normalize_bool(proxy_value(source, "forceHttps", "force_https"), normalize_bool(tls.get("redirectHttp"), False))
    return {
        "forceHttps": force_https,
        "redirectStatusCode": normalize_redirect_status(
            redirect_status_code if redirect_status_code is not None else proxy_value(source, "redirectStatusCode", "redirect_status_code")
        ),
        "hsts": normalize_bool(proxy_value(source, "hsts"), normalize_bool(tls.get("enabled"), False)),
        "hstsMaxAge": str(proxy_value(source, "hstsMaxAge", "hsts_max_age") or "15768000"),
        "gzip": normalize_bool(proxy_value(source, "gzip"), True),
        "brotli": normalize_bool(proxy_value(source, "brotli", "br"), False),
        "http2": normalize_bool(proxy_value(source, "http2"), normalize_bool(tls.get("http2"), True)),
        "ipv6": normalize_bool(proxy_value(source, "ipv6"), False),
        "resetXff": normalize_bool(proxy_value(source, "resetXff", "reset_xff"), True),
        "defaultServer": normalize_bool(proxy_value(source, "defaultServer", "default_server"), False),
        "strictHost": normalize_bool(proxy_value(source, "strictHost", "strict_host"), False),
        "accessLog": normalize_bool(proxy_value(source, "accessLog", "access_log"), True),
        "modifyHostHeader": normalize_bool(proxy_value(source, "modifyHostHeader", "modify_host_header"), True),
        "forwardedHeaders": normalize_bool(proxy_value(source, "forwardedHeaders", "forwarded_headers"), True),
        "hostHeader": normalize_proxy_header(proxy_value(source, "hostHeader", "host") or "$http_host"),
        "xForwardedProto": normalize_proxy_header(proxy_value(source, "xForwardedProto", "xfp") or "$scheme"),
        "xForwardedHost": normalize_proxy_header(proxy_value(source, "xForwardedHost", "xfh") or "$http_host"),
        "proxySslServerName": normalize_bool(proxy_value(source, "proxySslServerName", "proxy_ssl_server_name"), True),
    }


def normalize_modsecurity_config(value, site_mode: str = "block") -> dict:
    source = value if isinstance(value, dict) else {}
    mode = str(source.get("mode") or ("detection_only" if site_mode == "monitor" else "on")).lower()
    ruleset = str(source.get("ruleset") or "cms").lower()
    return {
        "enabled": normalize_bool(source.get("enabled"), False),
        "mode": mode if mode in MODSECURITY_MODES else "on",
        "ruleset": ruleset if ruleset in MODSECURITY_RULESETS else "cms",
        "requestBodyLimit": min(
            max(normalize_positive_int(source.get("requestBodyLimit") or source.get("request_body_limit"), 13107200), 131072),
            1073741824,
        ),
    }


def proxy_value(source: dict, *keys):
    for key in keys:
        if key not in source:
            continue
        value = source.get(key)
        if isinstance(value, dict) and "value" in value:
            return value.get("value")
        return value
    return None


def normalize_proxy_header(value) -> str:
    header = str(value or "").strip()
    if not header:
        return ""
    return header.replace("\x00", "").replace(";", "").replace("{", "").replace("}", "").replace("\n", " ")


def normalize_redirect_status(value) -> int:
    try:
        status = int(value or 301)
    except (TypeError, ValueError):
        status = 301
    if status == 0:
        return 0
    return status if status in {301, 302, 307, 308} else 301


def normalize_acl_config(value, enabled_value=None) -> dict:
    source = value if isinstance(value, dict) else {}
    enabled = normalize_bool(source.get("enabled"), normalize_bool(enabled_value, True))
    return {
        "enabled": enabled,
        "rateLimitMode": normalize_acl_rate_limit_mode(source.get("rateLimitMode") or source.get("rate_limit_mode") or source.get("rateMode")),
        "waitingRoom": normalize_bool(source.get("waitingRoom") if "waitingRoom" in source else source.get("waiting_room"), False),
        "accessLimit": normalize_acl_limit(
            source.get("accessLimit") or source.get("access_limit"),
            {"enabled": True, "period": 10, "count": 500, "blockCount": 1200, "action": "challenge_v1", "blockMin": 60},
        ),
        "attackLimit": normalize_acl_limit(
            source.get("attackLimit") or source.get("attack_limit"),
            {"enabled": True, "period": 60, "count": 10, "action": "block", "blockMin": 30},
        ),
        "errorLimit": normalize_acl_limit(
            source.get("errorLimit") or source.get("error_limit"),
            {"enabled": True, "period": 10, "count": 10, "action": "block", "blockMin": 30, "statusCodes": ["403", "404"]},
            include_status_codes=True,
        ),
    }


def normalize_acl_limit(value, defaults: dict, include_status_codes: bool = False) -> dict:
    source = value if isinstance(value, dict) else {}
    limit = {
        "enabled": normalize_bool(source.get("enabled"), defaults["enabled"]),
        "period": normalize_positive_int(source.get("period"), defaults["period"]),
        "count": normalize_positive_int(source.get("count"), defaults["count"]),
        "action": normalize_acl_action(source.get("action") or defaults["action"]),
        "blockMin": normalize_positive_int(source.get("blockMin") or source.get("block_min"), defaults["blockMin"]),
    }
    if "blockCount" in defaults:
        block_count = normalize_positive_int(source.get("blockCount") or source.get("block_count"), defaults["blockCount"])
        limit["blockCount"] = min(max(block_count, limit["count"] + 1), 1000000)
    if include_status_codes:
        limit["statusCodes"] = normalize_status_codes(source.get("statusCodes") or source.get("status_codes") or defaults["statusCodes"])
    return limit


def normalize_acl_action(value) -> str:
    action = str(value or "block").lower()
    return action if action in ACL_ACTIONS else "block"


def normalize_acl_rate_limit_mode(value) -> str:
    mode = str(value or "custom").lower()
    return mode if mode in ACL_RATE_LIMIT_MODES else "custom"


def normalize_status_codes(values) -> list[str]:
    codes = []
    for value in normalize_string_list(values):
        try:
            code = int(value)
        except (TypeError, ValueError):
            continue
        if 100 <= code <= 599:
            codes.append(str(code))
    return list(dict.fromkeys(codes or ["403", "404"]))


def normalize_bool(value, fallback: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return fallback
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        return fallback
    return bool(value)


def normalize_site_features(value) -> dict:
    source = value if isinstance(value, dict) else {}
    return {
        "httpFlood": normalize_bool(source.get("httpFlood"), True),
        "botProtection": normalize_bool(source.get("botProtection"), True),
        "geoBlock": normalize_bool(source.get("geoBlock"), False),
    }


def normalize_bot_protection_config(value, enabled_value=None) -> dict:
    source = value if isinstance(value, dict) else {}
    dynamic = source.get("dynamicProtection") or source.get("dynamic_protection")
    dynamic = dynamic if isinstance(dynamic, dict) else {}
    anti_replay = source.get("antiReplay") or source.get("anti_replay")
    anti_replay = anti_replay if isinstance(anti_replay, dict) else {}
    verified = source.get("verifiedSearchBots") or source.get("verified_search_bots")
    verified = verified if isinstance(verified, dict) else {}
    verified_ai = source.get("verifiedAIBots") or source.get("verified_ai_bots")
    verified_ai = verified_ai if isinstance(verified_ai, dict) else {}

    dynamic_html = normalize_bool(dynamic.get("html") if "html" in dynamic else source.get("htmlDynamicEncryption"), False)
    dynamic_js = normalize_bool(dynamic.get("js") if "js" in dynamic else source.get("jsDynamicEncryption"), False)
    dynamic_watermark = normalize_bool(dynamic.get("watermark") if "watermark" in dynamic else source.get("pictureDynamicWatermark"), False)
    dynamic_enabled = normalize_bool(dynamic.get("enabled") if "enabled" in dynamic else source.get("dynamicProtectionEnabled"), any([dynamic_html, dynamic_js, dynamic_watermark]))
    anti_bot = normalize_bool(source.get("antiBotChallenge") if "antiBotChallenge" in source else source.get("anti_bot_challenge"), normalize_bool(enabled_value, True))
    login_challenge = normalize_bot_login_challenge_config(
        source.get("loginChallenge") or source.get("login_challenge"),
        anti_bot,
    )
    rate_challenge = normalize_bot_rate_challenge_config(
        source.get("rateChallenge") or source.get("rate_challenge"),
        anti_bot,
    )
    replay_enabled = normalize_bool(anti_replay.get("enabled") if "enabled" in anti_replay else source.get("antiReplayEnabled"), False)
    enabled = normalize_bool(source.get("enabled"), normalize_bool(enabled_value, True))
    enabled = enabled and (anti_bot or dynamic_enabled or replay_enabled)
    verified_ai_enabled = normalize_bool(verified_ai.get("enabled"), False)
    provider_value = verified_ai.get("allowedProviders") if "allowedProviders" in verified_ai else verified_ai.get("allowed_providers")
    allowed_providers = normalize_verified_ai_provider_ids(provider_value)
    if verified_ai_enabled and provider_value is None:
        allowed_providers = list(VERIFIED_AI_BOT_PROVIDERS)
    if not anti_bot:
        login_challenge["enabled"] = False
        rate_challenge["enabled"] = False

    return {
        "enabled": enabled,
        "antiBotChallenge": anti_bot,
        "verifiedSearchBots": {
            "enabled": normalize_bool(verified.get("enabled"), True),
            "bypassChallenge": normalize_bool(verified.get("bypassChallenge") if "bypassChallenge" in verified else verified.get("bypass_challenge"), True),
            "bypassRateLimit": normalize_bool(verified.get("bypassRateLimit") if "bypassRateLimit" in verified else verified.get("bypass_rate_limit"), True),
        },
        "verifiedAIBots": {
            "enabled": verified_ai_enabled and bool(allowed_providers),
            "allowedProviders": allowed_providers,
            "bypassChallenge": normalize_bool(
                verified_ai.get("bypassChallenge") if "bypassChallenge" in verified_ai else verified_ai.get("bypass_challenge"),
                True,
            ),
            "bypassRateLimit": normalize_bool(
                verified_ai.get("bypassRateLimit") if "bypassRateLimit" in verified_ai else verified_ai.get("bypass_rate_limit"),
                True,
            ),
        },
        "loginChallenge": login_challenge,
        "rateChallenge": rate_challenge,
        "dynamicProtection": {
            "enabled": dynamic_enabled,
            "html": dynamic_html,
            "js": dynamic_js,
            "watermark": dynamic_watermark,
        },
        "antiReplay": {
            "enabled": replay_enabled,
        },
    }


def normalize_verified_ai_provider_ids(values) -> list[str]:
    return [item for item in normalize_string_list(values) if item in VERIFIED_AI_BOT_PROVIDERS]


def normalize_bot_login_challenge_config(value, anti_bot_enabled: bool) -> dict:
    source = value if isinstance(value, dict) else {}
    path_values = None
    for key in ("pathPatterns", "path_patterns", "loginPathPatterns", "paths"):
        if key in source:
            path_values = source.get(key)
            break
    patterns = normalize_string_list(path_values if path_values is not None else DEFAULT_BOT_LOGIN_PATH_PATTERNS)
    patterns = [pattern.replace("\x00", "").strip() for pattern in patterns if pattern.replace("\x00", "").strip()]
    patterns = [pattern for pattern in patterns if pattern not in LEGACY_WHMCS_LOGIN_PATH_PATTERNS]
    return {
        "enabled": normalize_bool(source.get("enabled"), anti_bot_enabled) and bool(patterns),
        "pathPatterns": patterns[:64],
    }


def normalize_bot_rate_challenge_config(value, anti_bot_enabled: bool) -> dict:
    source = value if isinstance(value, dict) else {}
    defaults = DEFAULT_BOT_RATE_CHALLENGE
    window = normalize_positive_int(source.get("windowSeconds") or source.get("window_seconds"), defaults["windowSeconds"])
    if window not in BOT_RATE_WINDOW_SECONDS:
        window = defaults["windowSeconds"]
    challenge_count = min(max(normalize_positive_int(source.get("challengeCount") or source.get("challenge_count"), defaults["challengeCount"]), 1), 1000000)
    block_count = min(max(normalize_positive_int(source.get("blockCount") or source.get("block_count"), defaults["blockCount"]), 1), 1000000)
    if block_count <= challenge_count:
        block_count = challenge_count + 1
    block_minutes = normalize_positive_int(source.get("blockMinutes") or source.get("block_minutes") or source.get("blockMin") or source.get("block_min"), defaults["blockMinutes"])
    if block_minutes not in BOT_RATE_BLOCK_MINUTES:
        block_minutes = defaults["blockMinutes"]
    return {
        "enabled": normalize_bool(source.get("enabled"), defaults["enabled"] if anti_bot_enabled else False),
        "windowSeconds": window,
        "challengeCount": challenge_count,
        "blockCount": block_count,
        "blockMinutes": block_minutes,
    }


def normalize_geo_block_config(value, enabled_value=None) -> dict:
    source = value if isinstance(value, dict) else {}
    countries = []
    for item in normalize_string_list(source.get("countries"), uppercase=True):
        code = item.strip().upper()
        if re.match(r"^[A-Z]{2}$", code) and code not in countries:
            countries.append(code)
    action = str(source.get("action") or "block").lower()
    if action not in {"block", "monitor"}:
        action = "block"
    enabled = normalize_bool(source.get("enabled"), normalize_bool(enabled_value, False))
    return {
        "enabled": enabled and bool(countries),
        "countries": countries[:64],
        "action": action,
    }


def normalize_under_attack_config(value) -> dict:
    source = value if isinstance(value, dict) else {}
    return {
        "enabled": normalize_bool(source.get("enabled"), False),
    }


def normalize_file_reference(value) -> str:
    item = str(value or "").strip().replace("\\", "/")
    item = item.replace("\x00", "").replace(";", "").replace("{", "").replace("}", "")
    return item


def normalize_certificate_source(value) -> str:
    source = str(value or "upload").lower()
    return source if source in {"upload", "certbot", "cloudflare"} else "upload"


def normalize_domain_list(values) -> list[str]:
    domains = []
    for item in normalize_string_list(values):
        domain = item.lower().strip().replace("https://", "").replace("http://", "").split("/")[0].split(":")[0]
        if not domain:
            continue
        if not re.match(r"^(\*\.)?[a-z0-9][a-z0-9.-]*[a-z0-9]$", domain):
            raise StoreError(400, f"Invalid domain: {item}") from None
        domains.append(domain)
    return list(dict.fromkeys(domains))


def normalize_positive_int(value, fallback: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = fallback
    return max(1, number)


def normalize_non_negative_int(value, fallback: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = fallback
    return max(0, number)


def normalize_ip_items(items) -> list[str]:
    values = ip_item_candidates(items)
    normalized = []
    for value in values:
        try:
            if "/" in value:
                item = str(ipaddress.ip_network(value, strict=False))
            else:
                item = str(ipaddress.ip_address(value))
        except ValueError:
            raise StoreError(400, f"Invalid IP/CIDR entry: {value}") from None
        normalized.append(item)
    return list(dict.fromkeys(normalized))


def ip_item_candidates(items) -> list[str]:
    if items is None:
        return []
    if isinstance(items, list):
        chunks = [str(item or "") for item in items]
    else:
        chunks = str(items or "").replace(",", "\n").replace(";", "\n").splitlines()

    candidates = []
    saw_content = False
    for chunk in chunks:
        line = chunk.split("#", 1)[0].strip()
        if not line:
            continue
        saw_content = True
        for token in re.split(r"\s+", line):
            candidate = normalize_ip_token(token)
            if not candidate:
                continue
            candidates.append(candidate)

    if saw_content and not candidates:
        raise StoreError(400, "No IP/CIDR entries found")
    return list(dict.fromkeys(candidates))


def normalize_ip_token(token: str) -> str:
    item = str(token or "").strip().strip("[](){}<>\"'`")
    item = item.rstrip(".,;")
    if not item or not re.search(r"\d", item):
        return ""

    if re.match(r"^\d{1,3}(?:\.\d{1,3}){3}:\d+$", item):
        item = item.rsplit(":", 1)[0]

    if "." not in item and ":" not in item and "/" not in item:
        return ""
    return item


def preserve_ip_group_storage(group: dict) -> dict:
    return {
        "items": list(group.get("items") or []),
        "itemsFile": str(group.get("itemsFile") or ""),
        "itemsExternal": bool(group.get("itemsExternal")),
        "itemCount": normalize_non_negative_int(group.get("itemCount"), len(group.get("items") or [])),
        "itemsPreview": list(group.get("itemsPreview") or (group.get("items") or [])[:8]),
    }


def should_externalize_ip_group(items: list[str], group: dict) -> bool:
    if not items:
        return False
    if group.get("itemsExternal"):
        return True
    count_threshold = normalize_non_negative_int(os.environ.get("IP_GROUP_EXTERNALIZE_COUNT"), 5000)
    bytes_threshold = normalize_non_negative_int(os.environ.get("IP_GROUP_EXTERNALIZE_BYTES"), 256 * 1024)
    payload_size = sum(len(item) + 1 for item in items)
    return len(items) > count_threshold or payload_size > bytes_threshold


def ip_group_file_path(group: dict) -> Path | None:
    item_file = str(group.get("itemsFile") or "").strip()
    if not item_file:
        return None
    return Path(item_file)


def is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def normalize_reference_url(value, strict: bool = True) -> str:
    item = str(value or "").strip().replace("\x00", "")
    if not item:
        return ""
    parsed = urlparse(item)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        if strict:
            raise StoreError(400, "Reference URL must be a valid http or https URL")
        return ""
    return item


def normalize_panel_url(value) -> str:
    item = str(value or "").strip().replace("\x00", "")
    if not item:
        return ""
    # Accept either a bare domain (e.g. "waf.example.com") or a full URL.
    # If a scheme is present, validate it; otherwise treat the value as a hostname/domain.
    if "://" in item:
        parsed = urlparse(item)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise StoreError(400, "Panel URL must be a valid http or https URL")
        host = parsed.netloc
    else:
        host = item.rstrip("/")
    # Strip optional port and path remnants for validation, then keep the user's normalized value.
    bare = host.split("/", 1)[0]
    hostname = bare.split(":", 1)[0]
    if not hostname or any(ch.isspace() for ch in hostname):
        raise StoreError(400, "Panel domain must be a valid hostname")
    if not all(ch.isalnum() or ch in "-._" for ch in hostname):
        raise StoreError(400, "Panel domain must be a valid hostname")
    return host.rstrip("/")


def normalize_optional_https_url(value, *, max_length: int = 1024) -> str:
    item = str(value or "").strip().replace("\x00", "")
    if not item:
        return ""
    if item.startswith("data:"):
        return item[:max_length]
    parsed = urlparse(item)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise StoreError(400, "URL must be a valid http or https URL")
    return item[:max_length]


def normalize_optional_http_url(value) -> str:
    item = str(value or "").strip().replace("\x00", "")
    if not item:
        return ""
    parsed = urlparse(item)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise StoreError(400, "URL must be a valid http or https URL")
    return item[:1000]


def normalize_display_text(value, fallback: str, maximum: int) -> str:
    item = str(value if value is not None else fallback).replace("\x00", "").strip()
    return (item or fallback)[:maximum]


def normalize_hex_color(value, fallback: str) -> str:
    item = str(value or "").strip()
    return item.lower() if re.match(r"^#[0-9a-fA-F]{6}$", item) else fallback


def normalize_string_list(values, uppercase: bool = False) -> list[str]:
    if isinstance(values, list):
        source = values
    else:
        source = re.split(r"[\n,]+", str(values or ""))
    normalized = []
    for value in source:
        item = str(value).strip()
        if not item:
            continue
        item = item.upper() if uppercase else item
        normalized.append(item)
    return list(dict.fromkeys(normalized))


def normalize_id_list(values) -> list[str]:
    return [item for item in normalize_string_list(values) if re.match(r"^[A-Za-z0-9_.:-]+$", item)]


def normalize_username(value) -> str:
    username = str(value or "").strip().lower()
    if not re.match(r"^[a-z0-9_.-]{3,64}$", username):
        raise StoreError(400, "Username must be 3-64 chars: letters, numbers, dot, dash, underscore")
    return username


def normalize_user_role(value) -> str:
    role = str(value or "admin").strip().lower()
    return role if role in USER_ROLES else "admin"


def validate_password(password: str) -> str:
    value = str(password or "")
    if len(value) < 10:
        raise StoreError(400, "Password must be at least 10 characters")
    return value


def hash_password(password: str) -> dict:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("ascii"), PASSWORD_ITERATIONS)
    return {
        "passwordSalt": salt,
        "passwordHash": digest.hex(),
        "passwordIterations": PASSWORD_ITERATIONS,
    }


def verify_password(password: str, user: dict) -> bool:
    salt = str(user.get("passwordSalt") or "")
    expected = str(user.get("passwordHash") or "")
    iterations = int(user.get("passwordIterations") or PASSWORD_ITERATIONS)
    if not salt or not expected:
        return False
    digest = hashlib.pbkdf2_hmac("sha256", str(password or "").encode("utf-8"), salt.encode("ascii"), iterations)
    return hmac.compare_digest(digest.hex(), expected)


def generate_totp_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def normalize_totp_secret(value) -> str:
    return re.sub(r"[^A-Z2-7]", "", str(value or "").upper())


def verify_totp(secret: str, code: str, timestamp: int | None = None) -> bool:
    normalized = normalize_totp_secret(secret)
    digits = re.sub(r"\D", "", str(code or ""))
    if not normalized or len(digits) != 6:
        return False
    current = int(timestamp or time.time()) // 30
    return any(hmac.compare_digest(totp_code(normalized, current + offset), digits) for offset in (-1, 0, 1))


def totp_code(secret: str, counter: int) -> str:
    padded = secret + "=" * ((8 - len(secret) % 8) % 8)
    key = base64.b32decode(padded, casefold=True)
    message = struct.pack(">Q", counter)
    digest = hmac.new(key, message, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    number = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return f"{number % 1_000_000:06d}"


def normalize_insert_position(value) -> str:
    position = str(value or "last").strip().lower()
    return position if position in ACCESS_INSERT_POSITIONS else "last"


def normalize_access_condition_groups(value) -> list[dict]:
    if not isinstance(value, list):
        return []

    groups = []
    for raw_group in value:
        raw_conditions = raw_group.get("conditions") if isinstance(raw_group, dict) else raw_group
        if not isinstance(raw_conditions, list):
            continue
        conditions = []
        for raw_condition in raw_conditions:
            condition = normalize_access_condition(raw_condition)
            if condition:
                conditions.append(condition)
        if conditions:
            groups.append({"conditions": conditions})
    return groups


def normalize_access_condition(value) -> dict | None:
    if not isinstance(value, dict):
        return None

    target = normalize_access_condition_target(value.get("target") or value.get("matchTarget"))
    operator = normalize_access_condition_operator(value.get("operator"), target)
    content = str(value.get("content") or value.get("value") or "").strip()
    if not content:
        return None

    return {
        "target": target,
        "operator": operator,
        "content": normalize_access_condition_content(target, operator, content),
    }


def normalize_access_condition_target(value) -> str:
    item = str(value or "source_ip").strip()
    snake = re.sub(r"(?<!^)([A-Z])", r"_\1", item).lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "ip": "source_ip",
        "source": "source_ip",
        "sourceip": "source_ip",
        "source_ip": "source_ip",
        "url": "uri",
        "path": "uri",
        "hostname": "host",
        "useragent": "user_agent",
        "user_agent": "user_agent",
        "ua": "user_agent",
    }
    target = aliases.get(snake, snake)
    return target if target in ACCESS_CONDITION_TARGETS else "source_ip"


def normalize_access_condition_operator(value, target: str) -> str:
    item = str(value or "equals").strip()
    snake = re.sub(r"(?<!^)([A-Z])", r"_\1", item).lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "equal": "equals",
        "does_not_equal": "not_equals",
        "not_equal": "not_equals",
        "does_not_match": "not_regex",
        "fuzzy_match": "contains",
        "fuzzy": "contains",
        "in_ip_group": "in_ip_group",
        "not_in_ip_group": "not_in_ip_group",
        "does_not_in_ip_group": "not_in_ip_group",
        "does_not_in_cidr": "not_cidr",
    }
    operator = aliases.get(snake, snake)
    if target == "source_ip" and operator not in {"equals", "not_equals", "cidr", "not_cidr", "in_ip_group", "not_in_ip_group"}:
        operator = "equals"
    if target == "method" and operator not in {"equals", "not_equals"}:
        operator = "equals"
    if target in {"uri", "host", "user_agent"} and operator not in {"equals", "not_equals", "contains", "not_contains", "regex", "not_regex"}:
        operator = "equals"
    return operator if operator in ACCESS_CONDITION_OPERATORS else "equals"


def normalize_access_condition_content(target: str, operator: str, content: str) -> str:
    item = content.replace("\x00", "").strip()
    if target == "source_ip":
        if operator in {"in_ip_group", "not_in_ip_group"}:
            ids = normalize_id_list([item])
            if not ids:
                raise StoreError(400, "Access condition needs a valid IP group")
            return ids[0]
        try:
            if operator in {"cidr", "not_cidr"}:
                return str(ipaddress.ip_network(item, strict=False))
            return str(ipaddress.ip_address(item))
        except ValueError:
            raise StoreError(400, f"Invalid access condition IP/CIDR: {content}") from None

    if target == "method":
        method = item.upper()
        if not re.match(r"^[A-Z][A-Z0-9_-]*$", method):
            raise StoreError(400, "Invalid access condition method")
        return method

    if operator in {"regex", "not_regex"}:
        try:
            re.compile(item, re.IGNORECASE)
        except re.error:
            raise StoreError(400, "Access condition regex is invalid") from None

    return item


def normalize_access_action(value) -> str:
    action = str(value or "deny").lower()
    if action == "block":
        action = "deny"
    return action if action in ACCESS_ACTIONS else "deny"


def entry_ip(entry: dict) -> str:
    return str(entry.get("ip") or entry.get("remote_addr") or "").strip()


def visitor_identity(entry: dict) -> str:
    ip = entry_ip(entry)
    if not ip:
        return ""
    user_agent = str(entry.get("userAgent") or entry.get("user_agent") or "").strip()
    return f"{ip}\0{user_agent}"


def hll_new() -> list[int]:
    return [0] * HLL_REGISTER_COUNT


def hll_add(registers: list[int], value: str) -> None:
    if not value:
        return
    digest = hashlib.blake2b(str(value).encode("utf-8"), digest_size=8).digest()
    hashed = int.from_bytes(digest, "big", signed=False)
    index = hashed & HLL_REGISTER_MASK
    remaining = hashed >> HLL_PRECISION
    rank = HLL_REMAINING_BITS + 1 if remaining == 0 else HLL_REMAINING_BITS - remaining.bit_length() + 1
    registers[index] = max(int(registers[index] or 0), rank)


def hll_merge(target: list[int], source) -> None:
    if not isinstance(source, list):
        return
    for index, value in enumerate(source[:HLL_REGISTER_COUNT]):
        target[index] = max(int(target[index] or 0), int(value or 0))


def hll_count(registers) -> int:
    if not isinstance(registers, list):
        return 0
    normalized = [int(value or 0) for value in registers[:HLL_REGISTER_COUNT]]
    if len(normalized) < HLL_REGISTER_COUNT:
        normalized.extend([0] * (HLL_REGISTER_COUNT - len(normalized)))
    zero_count = normalized.count(0)
    harmonic = sum(2 ** -value for value in normalized)
    alpha = 0.7213 / (1 + 1.079 / HLL_REGISTER_COUNT)
    estimate = alpha * HLL_REGISTER_COUNT * HLL_REGISTER_COUNT / harmonic
    if estimate <= 2.5 * HLL_REGISTER_COUNT and zero_count:
        estimate = HLL_REGISTER_COUNT * (math.log(HLL_REGISTER_COUNT / zero_count))
    return int(round(estimate))


def hll_from_values(values) -> list[int]:
    registers = hll_new()
    for value in values:
        hll_add(registers, value)
    return registers


def build_stats(state: dict, site_id: str = "") -> dict:
    source_logs = state.get("logs") or []
    sites = state.get("sites") or []
    selected_site_id = str(site_id or "")
    if sites:
        site_by_id = {str(site.get("id")): site for site in sites if site.get("id")}
        logs = []
        unmatched_total = 0
        for entry in source_logs:
            site = match_log_site(entry, sites, site_by_id)
            if not site:
                if not selected_site_id:
                    unmatched_total += 1
                continue
            if selected_site_id and str(site.get("id") or "") != selected_site_id:
                continue
            logs.append(entry)
    else:
        logs = source_logs
        unmatched_total = 0
    blocked = sum(1 for entry in logs if entry.get("verdict") == "block")
    challenged = sum(1 for entry in logs if entry.get("verdict") == "challenge")
    monitored = sum(1 for entry in logs if entry.get("verdict") == "monitor")
    protected = blocked + challenged
    total = len(logs)
    unique_ips = len({entry_ip(entry) for entry in logs if entry_ip(entry)})
    visitors = len({visitor_identity(entry) for entry in logs if visitor_identity(entry)})

    bot_types = summarize_bot_types(logs)
    user_client_os, user_client_browsers = summarize_user_clients(logs)
    countries = summarize_countries(logs)
    real_countries = [item for item in countries if is_real_country_code(item["code"])]
    blocked_countries = sorted(
        [item for item in real_countries if item["blocked"] > 0],
        key=lambda item: item["blocked"],
        reverse=True,
    )
    top_rules = Counter(
        rule.get("name") or rule.get("id")
        for entry in logs
        for rule in entry.get("matchedRules", [])
    )
    top_sites = Counter(entry.get("siteName") or "Unmatched" for entry in logs)
    site_stats = summarize_site_stats(logs, sites)
    status_groups = Counter(status_group(entry) for entry in logs)
    timeline = build_timeline(logs)
    status_timeline = build_status_timeline(logs)
    qps_timeline = build_qps_timeline(logs)

    return {
        "total": total,
        "scannedTotal": len(source_logs),
        "unmatchedTotal": unmatched_total,
        "blocked": blocked,
        "challenged": challenged,
        "protected": protected,
        "monitored": monitored,
        "allowed": max(total - protected - monitored, 0),
        "visitors": visitors,
        "uniqueIps": unique_ips,
        "blockRate": round((blocked / total) * 100, 1) if total else 0,
        "protectedRate": round((protected / total) * 100, 1) if total else 0,
        "botTypes": bot_types[:10],
        "botTypeCount": len(bot_types),
        "botRequestTotal": sum(item["count"] for item in bot_types),
        "botChallengeTotal": sum(item["challenged"] for item in bot_types),
        "userClientOs": user_client_os[:10],
        "userClientBrowsers": user_client_browsers[:10],
        "userClientTotal": total,
        "topCountries": countries[:10],
        "blockedCountries": blocked_countries[:10],
        "countryCount": len(real_countries),
        "blockedCountryCount": len(blocked_countries),
        "protectedCountryCount": sum(1 for item in real_countries if item["protected"] > 0),
        "geoAttribution": geoip_attribution(),
        "topRules": counter_items(top_rules),
        "topSites": counter_items(top_sites),
        "siteStats": site_stats,
        "statusGroups": counter_items(status_groups),
        "qps": qps_timeline[-1]["qps"] if qps_timeline else 0,
        "qpsTimeline": qps_timeline,
        "statusTimeline": status_timeline,
        "timeline": timeline,
    }


def build_stats_from_summary(state: dict, summary: dict, recent_logs: list[dict] | None = None, site_id: str = "") -> dict:
    sites = state.get("sites") or []
    site_by_id = {str(site.get("id")): site for site in sites if site.get("id")}
    selected_site_id = str(site_id or "")
    source_hosts = summary.get("hosts") if isinstance(summary.get("hosts"), dict) else {}
    aggregate = empty_stats_counts()
    source_total = 0
    unmatched_total = 0
    top_sites = Counter()
    site_totals = {
        str(site.get("id") or ""): {
            "siteId": str(site.get("id") or ""),
            "name": str(site.get("name") or "Untitled site"),
            **empty_stats_counts(),
        }
        for site in sites
        if site.get("id")
    }

    for host, counts in source_hosts.items():
        if not isinstance(counts, dict):
            continue
        total = int(counts.get("total") or 0)
        source_total += total
        site = match_log_site({"host": host, "siteName": host}, sites, site_by_id) if sites else None
        if sites and not site:
            if not selected_site_id:
                unmatched_total += total
            continue
        if selected_site_id and site and str(site.get("id") or "") != selected_site_id:
            continue

        merge_stats_counts(aggregate, counts)
        if site:
            merge_stats_counts(site_totals[str(site["id"])], counts)
            top_sites[site.get("name") or host or "Unmatched"] += total
        else:
            top_sites[str(host or "Unmatched")] += total

    recent_source = recent_logs or []
    if sites:
        recent = []
        for entry in recent_source:
            site = match_log_site(entry, sites, site_by_id)
            if not site:
                continue
            if selected_site_id and str(site.get("id") or "") != selected_site_id:
                continue
            recent.append(entry)
    else:
        recent = recent_source

    blocked = aggregate["blocked"]
    challenged = aggregate["challenged"]
    monitored = aggregate["monitored"]
    protected = blocked + challenged
    total = aggregate["total"]
    visitors = hll_count(aggregate["visitorSketch"])
    unique_ips = hll_count(aggregate["uniqueIpSketch"])
    countries = sorted(aggregate["countries"].values(), key=lambda item: item["count"], reverse=True)
    real_countries = [item for item in countries if is_real_country_code(item["code"])]
    blocked_countries = sorted(
        [item for item in real_countries if item["blocked"] > 0],
        key=lambda item: item["blocked"],
        reverse=True,
    )
    bot_types = sorted(aggregate["botTypes"].values(), key=lambda item: item["count"], reverse=True)
    user_client_os = sorted(aggregate["userClientOs"].values(), key=lambda item: item["count"], reverse=True)
    user_client_browsers = sorted(aggregate["userClientBrowsers"].values(), key=lambda item: item["count"], reverse=True)
    timeline = build_timeline(recent)
    status_timeline = build_status_timeline(recent)
    qps_timeline = build_qps_timeline(recent)
    site_stats = []
    for item in site_totals.values():
        site_total = item["total"]
        site_protected = item["blocked"] + item["challenged"]
        site_stats.append(
            {
                "siteId": item["siteId"],
                "name": item["name"],
                "requests": site_total,
                "blocked": item["blocked"],
                "challenged": item["challenged"],
                "protected": site_protected,
                "monitored": item["monitored"],
                "allowed": max(site_total - site_protected - item["monitored"], 0),
                "blockRate": round((item["blocked"] / site_total) * 100, 1) if site_total else 0,
                "protectedRate": round((site_protected / site_total) * 100, 1) if site_total else 0,
            }
        )

    return {
        "total": total,
        "scannedTotal": source_total,
        "unmatchedTotal": unmatched_total,
        "blocked": blocked,
        "challenged": challenged,
        "protected": protected,
        "monitored": monitored,
        "allowed": max(total - protected - monitored, 0),
        "visitors": visitors,
        "uniqueIps": unique_ips,
        "blockRate": round((blocked / total) * 100, 1) if total else 0,
        "protectedRate": round((protected / total) * 100, 1) if total else 0,
        "botTypes": bot_types[:10],
        "botTypeCount": len(bot_types),
        "botRequestTotal": sum(item["count"] for item in bot_types),
        "botChallengeTotal": sum(item["challenged"] for item in bot_types),
        "userClientOs": user_client_os[:10],
        "userClientBrowsers": user_client_browsers[:10],
        "userClientTotal": total,
        "topCountries": countries[:10],
        "blockedCountries": blocked_countries[:10],
        "countryCount": len(real_countries),
        "blockedCountryCount": len(blocked_countries),
        "protectedCountryCount": sum(1 for item in real_countries if item["protected"] > 0),
        "geoAttribution": geoip_attribution(),
        "topRules": counter_items(aggregate["topRules"]),
        "topSites": counter_items(top_sites),
        "siteStats": site_stats,
        "statusGroups": counter_items(aggregate["statusGroups"]),
        "qps": qps_timeline[-1]["qps"] if qps_timeline else 0,
        "qpsTimeline": qps_timeline,
        "statusTimeline": status_timeline,
        "timeline": timeline,
        "retentionDays": summary.get("retentionDays"),
    }


def empty_stats_counts() -> dict:
    return {
        "total": 0,
        "blocked": 0,
        "challenged": 0,
        "monitored": 0,
        "visitorSketch": hll_new(),
        "uniqueIpSketch": hll_new(),
        "botTypes": {},
        "userClientOs": {},
        "userClientBrowsers": {},
        "countries": {},
        "topRules": Counter(),
        "statusGroups": Counter(),
    }


def merge_stats_counts(target: dict, source: dict) -> None:
    target["total"] += int(source.get("total") or 0)
    target["blocked"] += int(source.get("blocked") or 0)
    target["challenged"] += int(source.get("challenged") or 0)
    target["monitored"] += int(source.get("monitored") or 0)
    hll_merge(target["visitorSketch"], source.get("visitorSketch") or [])
    hll_merge(target["uniqueIpSketch"], source.get("uniqueIpSketch") or [])
    merge_named_count_maps(target["botTypes"], source.get("botTypes") or {})
    merge_named_count_maps(target["userClientOs"], source.get("userClientOs") or {})
    merge_named_count_maps(target["userClientBrowsers"], source.get("userClientBrowsers") or {})
    merge_named_count_maps(target["countries"], source.get("countries") or {})
    target["topRules"].update(source.get("topRules") or {})
    target["statusGroups"].update(source.get("statusGroups") or {})


def merge_named_count_maps(target: dict, source: dict) -> None:
    for key, value in source.items():
        if not isinstance(value, dict):
            continue
        item = target.setdefault(key, {**value, "count": 0, "blocked": 0, "challenged": 0, "protected": 0})
        item["count"] += int(value.get("count") or 0)
        item["blocked"] += int(value.get("blocked") or 0)
        item["challenged"] += int(value.get("challenged") or 0)
        item["protected"] += int(value.get("protected") or 0)


def summarize_site_stats(logs: list[dict], sites: list[dict]) -> list[dict]:
    totals = {
        str(site.get("id") or ""): {
            "siteId": str(site.get("id") or ""),
            "name": str(site.get("name") or "Untitled site"),
            "requests": 0,
            "blocked": 0,
            "challenged": 0,
            "protected": 0,
            "monitored": 0,
        }
        for site in sites
        if site.get("id")
    }
    site_by_id = {str(site.get("id")): site for site in sites if site.get("id")}

    for entry in logs:
        site = match_log_site(entry, sites, site_by_id)
        if not site:
            continue
        item = totals[str(site["id"])]
        item["requests"] += 1
        verdict = entry.get("verdict")
        if verdict == "block":
            item["blocked"] += 1
            item["protected"] += 1
        elif verdict == "challenge":
            item["challenged"] += 1
            item["protected"] += 1
        elif verdict == "monitor":
            item["monitored"] += 1

    for item in totals.values():
        requests = item["requests"]
        item["allowed"] = max(requests - item["protected"] - item["monitored"], 0)
        item["blockRate"] = round((item["blocked"] / requests) * 100, 1) if requests else 0
        item["protectedRate"] = round((item["protected"] / requests) * 100, 1) if requests else 0
    return list(totals.values())


def match_log_site(entry: dict, sites: list[dict], site_by_id: dict[str, dict]) -> dict | None:
    site_id = str(entry.get("siteId") or "")
    if site_id and site_id in site_by_id:
        return site_by_id[site_id]

    host = str(entry.get("host") or entry.get("siteName") or "").strip().lower().split(":", 1)[0]
    if not host:
        return None
    for site in sites:
        for hostname in site.get("hostnames") or []:
            pattern = str(hostname or "").strip().lower().split(":", 1)[0]
            if pattern == host:
                return site
    for site in sites:
        for hostname in site.get("hostnames") or []:
            pattern = str(hostname or "").strip().lower().split(":", 1)[0]
            if pattern.startswith("*.") and (host == pattern[2:] or host.endswith(pattern[1:])):
                return site
    for site in sites:
        if any(str(hostname or "").strip() in {"*", "_"} for hostname in site.get("hostnames") or []):
            return site
    return None


def summarize_bot_types(logs: list[dict]) -> list[dict]:
    totals: dict[str, dict] = {}
    for entry in logs:
        bot_type = classify_bot_type(entry.get("userAgent") or entry.get("user_agent") or "")
        if not bot_type:
            continue
        item = totals.setdefault(bot_type, {"name": bot_type, "count": 0, "blocked": 0, "challenged": 0, "protected": 0})
        item["count"] += 1
        verdict = entry.get("verdict")
        if verdict == "block":
            item["blocked"] += 1
            item["protected"] += 1
        elif verdict == "challenge":
            item["challenged"] += 1
            item["protected"] += 1

    return sorted(totals.values(), key=lambda item: item["count"], reverse=True)


def summarize_user_clients(logs: list[dict]) -> tuple[list[dict], list[dict]]:
    os_totals: dict[str, dict] = {}
    browser_totals: dict[str, dict] = {}
    for entry in logs:
        user_agent = entry.get("userAgent") or entry.get("user_agent") or ""
        verdict = entry.get("verdict")
        os_name = classify_user_client_os(user_agent)
        browser_name = classify_user_client_browser(user_agent)
        increment_user_client(os_totals, os_name, "os", verdict)
        increment_user_client(browser_totals, browser_name, "browser", verdict)

    return (
        sorted(os_totals.values(), key=lambda item: item["count"], reverse=True),
        sorted(browser_totals.values(), key=lambda item: item["count"], reverse=True),
    )


def increment_user_client(target: dict, name: str, client_type: str, verdict: str) -> None:
    item = target.setdefault(
        name,
        {
            "name": name,
            "type": client_type,
            "count": 0,
            "blocked": 0,
            "challenged": 0,
            "protected": 0,
        },
    )
    item["count"] += 1
    if verdict == "block":
        item["blocked"] += 1
        item["protected"] += 1
    elif verdict == "challenge":
        item["challenged"] += 1
        item["protected"] += 1


def classify_user_client_os(user_agent: str) -> str:
    agent = str(user_agent or "")
    if not agent:
        return "Unknown OS"
    for name, pattern in USER_CLIENT_OS_REGEXES:
        if pattern.search(agent):
            return name
    return "Unknown OS"


def classify_user_client_browser(user_agent: str) -> str:
    agent = str(user_agent or "")
    if not agent:
        return "Unknown Client"
    automated_client = classify_bot_type(agent)
    if automated_client:
        return automated_client
    for name, pattern in USER_CLIENT_BROWSER_REGEXES:
        if pattern.search(agent):
            return name
    if re.search(r"version/[\d.]+.*mobile/.*safari", agent, re.IGNORECASE):
        return "Mobile Safari"
    if re.search(r"version/[\d.]+.*safari", agent, re.IGNORECASE):
        return "Safari"
    return "Other Client"


def classify_bot_type(user_agent: str) -> str | None:
    agent = str(user_agent or "").strip()
    if not agent:
        return None
    for name, pattern in BOT_TYPE_REGEXES:
        if pattern.search(agent):
            return name
    generic = GENERIC_BOT_TOKEN_REGEX.search(agent)
    if generic:
        name = generic.group(1).strip("._-")
        if name.lower() in {"bot", "crawler", "spider", "scraper", "fetcher", "extractor", "scanner", "probe", "verifier", "validator", "checker", "monitor", "externalagent"}:
            return f"Generic {name.title()}"
        return name
    return None


def summarize_countries(logs: list[dict]) -> list[dict]:
    countries: dict[tuple[str, str], dict] = {}
    cache: dict[str, dict] = {}
    for entry in logs:
        country = entry_country(entry, cache)
        key = (country["code"], country["name"])
        item = countries.setdefault(
            key,
            {
                "code": country["code"],
                "name": country["name"],
                "count": 0,
                "blocked": 0,
                "challenged": 0,
                "protected": 0,
            },
        )
        item["count"] += 1
        verdict = entry.get("verdict")
        if verdict == "block":
            item["blocked"] += 1
            item["protected"] += 1
        elif verdict == "challenge":
            item["challenged"] += 1
            item["protected"] += 1

    return sorted(countries.values(), key=lambda item: item["count"], reverse=True)


def entry_country(entry: dict, cache: dict[str, dict]) -> dict:
    country = entry.get("country") if isinstance(entry.get("country"), dict) else {}
    if country.get("name") or country.get("code"):
        return normalize_country(country.get("name"), country.get("code"))
    ip = str(entry.get("ip") or entry.get("remote_addr") or "").strip()
    if ip not in cache:
        cache[ip] = country_for_ip(ip)
    return cache[ip]


def country_for_ip(ip: str) -> dict:
    ip = str(ip or "").strip()
    if not ip:
        return normalize_country("Unknown", "ZZ")
    try:
        address = ipaddress.ip_address(ip)
    except ValueError:
        return normalize_country("Unknown", "ZZ")
    if address.is_loopback or address.is_private or address.is_link_local:
        return normalize_country("Local Network", "LO")

    reader = geoip_reader()
    if not reader:
        return normalize_country("Unknown", "ZZ")

    try:
        record = reader.get(ip) or {}
    except Exception:
        return normalize_country("Unknown", "ZZ")
    country = record.get("country") if isinstance(record.get("country"), dict) else {}
    names = country.get("names") if isinstance(country.get("names"), dict) else {}
    name = names.get("en") or country.get("name") or record.get("country_name")
    code = country.get("iso_code") or record.get("country_code")
    return normalize_country(name, code)


def normalize_country(name, code) -> dict:
    clean_code = str(code or "ZZ").strip().upper()[:3] or "ZZ"
    clean_name = str(name or "").strip() or ("Unknown" if clean_code == "ZZ" else clean_code)
    return {"code": clean_code, "name": clean_name}


def is_real_country_code(code: str) -> bool:
    return str(code or "").upper() not in {"", "ZZ", "LO"}


def geoip_reader():
    path = geoip_db_file()
    if not path.exists() or not path.is_file():
        return None
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return None

    global GEOIP_READER, GEOIP_READER_PATH, GEOIP_READER_MTIME
    with GEOIP_READER_LOCK:
        if GEOIP_READER and GEOIP_READER_PATH == str(path) and GEOIP_READER_MTIME == mtime:
            return GEOIP_READER
        reader = open_geoip_database(path)
        if not reader:
            return None
        if GEOIP_READER:
            try:
                GEOIP_READER.close()
            except Exception:
                pass
        GEOIP_READER = reader
        GEOIP_READER_PATH = str(path)
        GEOIP_READER_MTIME = mtime
        return GEOIP_READER


def open_geoip_database(path: Path):
    if path.name.lower().endswith(".csv.gz"):
        try:
            return DbIpCountryCsv(path)
        except (OSError, ValueError, csv.Error):
            return None

    try:
        import maxminddb
    except Exception:
        return None
    try:
        return maxminddb.open_database(str(path))
    except Exception:
        return None


class DbIpCountryCsv:
    def __init__(self, path: Path):
        self.path = path
        self.ranges = {4: [], 6: []}
        with gzip.open(path, "rt", encoding="utf-8", newline="") as source:
            for row in csv.reader(source):
                if len(row) < 3:
                    continue
                try:
                    start_address = ipaddress.ip_address(row[0].strip())
                    end_address = ipaddress.ip_address(row[1].strip())
                except ValueError:
                    continue
                if start_address.version != end_address.version:
                    continue
                code = str(row[2] or "ZZ").strip().upper()[:3] or "ZZ"
                self.ranges[start_address.version].append((int(start_address), int(end_address), code))
        for ranges in self.ranges.values():
            ranges.sort(key=lambda item: item[0])
        self.starts = {
            version: [item[0] for item in ranges]
            for version, ranges in self.ranges.items()
        }

    def get(self, ip: str) -> dict | None:
        try:
            address = ipaddress.ip_address(ip)
        except ValueError:
            return None
        ranges = self.ranges[address.version]
        starts = self.starts[address.version]
        index = bisect_right(starts, int(address)) - 1
        if index < 0:
            return None
        start, end, code = ranges[index]
        if int(address) < start or int(address) > end:
            return None
        return {"country": {"iso_code": code, "names": {"en": code}}}

    def close(self) -> None:
        return None


def geoip_db_file() -> Path:
    configured = Path(os.environ.get("GEOIP_DB_FILE", "/var/lib/freewaf/geoip/dbip-country-lite.csv.gz"))
    return configured


def geoip_attribution() -> dict:
    path = geoip_db_file()
    available = path.exists() and path.is_file()
    return {
        "available": available,
        "provider": "DB-IP",
        "url": "https://db-ip.com",
        "database": str(path),
    }


def build_timeline(logs: list[dict]) -> list[dict]:
    bucket_ms = 5 * 60 * 1000
    bucket_count = 24
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - bucket_ms * bucket_count
    buckets = []
    for index in range(bucket_count):
        at = start_ms + bucket_ms * index
        label = datetime.fromtimestamp(at / 1000).strftime("%H:%M")
        buckets.append({"at": at, "endAt": at + bucket_ms, "label": label, "total": 0, "blocked": 0, "challenged": 0, "protected": 0})

    for entry in logs:
        at_ms = entry_timestamp_ms(entry)
        if at_ms is None:
            continue
        if at_ms < start_ms:
            continue
        index = min(bucket_count - 1, max(0, (at_ms - start_ms) // bucket_ms))
        buckets[index]["total"] += 1
        if entry.get("verdict") == "block":
            buckets[index]["blocked"] += 1
            buckets[index]["protected"] += 1
        elif entry.get("verdict") == "challenge":
            buckets[index]["challenged"] += 1
            buckets[index]["protected"] += 1

    return buckets


def build_status_timeline(logs: list[dict]) -> list[dict]:
    bucket_ms = 5 * 60 * 1000
    bucket_count = 24
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - bucket_ms * bucket_count
    buckets = []
    for index in range(bucket_count):
        at = start_ms + bucket_ms * index
        label = datetime.fromtimestamp(at / 1000).strftime("%H:%M")
        buckets.append({"at": at, "endAt": at + bucket_ms, "label": label, "total": 0, "blocked": 0, "challenged": 0, "protected": 0})

    for entry in logs:
        at_ms = entry_timestamp_ms(entry)
        if at_ms is None or at_ms < start_ms:
            continue
        index = min(bucket_count - 1, max(0, (at_ms - start_ms) // bucket_ms))
        bucket = buckets[index]
        bucket["total"] += 1
        verdict = entry.get("verdict")
        if verdict == "block":
            bucket["blocked"] += 1
            bucket["protected"] += 1
        elif verdict == "challenge":
            bucket["challenged"] += 1
            bucket["protected"] += 1

    return buckets


def build_qps_timeline(logs: list[dict]) -> list[dict]:
    bucket_ms = 10 * 1000
    bucket_count = 30
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - bucket_ms * bucket_count
    buckets = []
    for index in range(bucket_count):
        at = start_ms + bucket_ms * index
        label = datetime.fromtimestamp(at / 1000).strftime("%H:%M:%S")
        buckets.append({"at": at, "endAt": at + bucket_ms, "label": label, "count": 0, "qps": 0})

    for entry in logs:
        at_ms = entry_timestamp_ms(entry)
        if at_ms is None or at_ms < start_ms:
            continue
        index = min(bucket_count - 1, max(0, (at_ms - start_ms) // bucket_ms))
        buckets[index]["count"] += 1

    seconds = bucket_ms / 1000
    for bucket in buckets:
        qps = bucket["count"] / seconds
        bucket["qps"] = round(qps, 1) if qps < 10 else round(qps)

    return buckets


def entry_timestamp_ms(entry: dict) -> int | None:
    try:
        return int(datetime.fromisoformat(str(entry.get("at")).replace("Z", "+00:00")).timestamp() * 1000)
    except (TypeError, ValueError):
        return None


def status_group(entry: dict) -> str:
    status = int(entry.get("upstreamStatus") or entry.get("statusCode") or 0)
    return f"{status // 100}xx" if status else "n/a"


def counter_items(counter: Counter) -> list[dict]:
    return [{"name": name, "count": count} for name, count in counter.most_common(8)]


def find_index(items: list[dict], item_id: str) -> int:
    for index, item in enumerate(items):
        if item.get("id") == item_id:
            return index
    return -1


def create_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"
